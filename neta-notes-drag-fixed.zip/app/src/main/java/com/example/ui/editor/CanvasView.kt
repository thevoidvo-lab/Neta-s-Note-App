package com.example.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.CanvasBackground
import com.example.data.NoteElement

@Composable
fun CanvasView(
    elements: List<NoteElement>,
    background: CanvasBackground,
    selectedElementId: String?,
    showGrid: Boolean,
    snapToGrid: Boolean,
    canvasPanX: Float,
    canvasPanY: Float,
    canvasZoom: Float,
    onCanvasTransform: (panX: Float, panY: Float, zoom: Float) -> Unit,
    onSelectElement: (String?) -> Unit,
    onEditElementText: (NoteElement) -> Unit,
    onLongPressElement: (NoteElement) -> Unit,
    onMoveElement: (id: String, dx: Float, dy: Float) -> Unit,
    onTransformElement: (id: String, scaleDelta: Float, rotationDelta: Float) -> Unit,
    onGestureEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onSelectElement(null) }
                )
            }
            // Do not install a second transform detector over child elements.
            // A parent detector competes with ElementView's detector and can
            // steal/duplicate drag deltas, making elements jump or snap back.
    ) {
        // Canvas Background layer
        CanvasBackgroundLayer(background = background)

        // Optional Grid layer
        if (showGrid) {
            GridOverlay(gridSize = 32.dp.value)
        }

        // Render sorted elements
        val sortedElements = elements.sortedBy { it.zIndex }
        for (elem in sortedElements) {
            val isSelected = elem.id == selectedElementId
            ElementView(
                element = elem,
                isSelected = isSelected,
                onSelect = { onSelectElement(elem.id) },
                onDoubleTap = { onEditElementText(elem) },
                onLongPress = { onLongPressElement(elem) },
                onMove = { dx, dy ->
                    // Keep movement smooth: never round each frame's delta.
                    // Snap the resulting position instead, so small finger
                    // movements accumulate rather than being discarded.
                    if (snapToGrid) {
                        val gridSize = 20f
                        val targetX = kotlin.math.round((elem.x + dx) / gridSize) * gridSize
                        val targetY = kotlin.math.round((elem.y + dy) / gridSize) * gridSize
                        onMoveElement(elem.id, targetX - elem.x, targetY - elem.y)
                    } else {
                        onMoveElement(elem.id, dx, dy)
                    }
                },
                onTransform = { scaleDelta, rotDelta ->
                    onTransformElement(elem.id, scaleDelta, rotDelta)
                },
                onGestureEnd = onGestureEnd
            )
        }
    }
}

@Composable
fun CanvasBackgroundLayer(background: CanvasBackground) {
    val baseModifier = Modifier
        .fillMaxSize()
        .alpha(background.opacity)
        .then(if (background.blurRadius > 0f) Modifier.blur(background.blurRadius.dp) else Modifier)

    when (background.type) {
        "IMAGE" -> {
            if (background.imageUri.isNotBlank()) {
                AsyncImage(
                    model = background.imageUri,
                    contentDescription = "Canvas Background Image",
                    contentScale = ContentScale.Crop,
                    modifier = baseModifier
                )
            } else {
                Box(modifier = baseModifier.background(parseHexColor(background.colorHex, Color(0xFF121212))))
            }
        }
        "GRADIENT" -> {
            val c1 = parseHexColor(background.colorHex, Color(0xFF121212))
            val c2 = parseHexColor(background.secondaryColorHex, Color(0xFF1E1E1E))
            Box(
                modifier = baseModifier.background(
                    brush = Brush.verticalGradient(colors = listOf(c1, c2))
                )
            )
        }
        else -> {
            Box(modifier = baseModifier.background(parseHexColor(background.colorHex, Color(0xFF121212))))
        }
    }
}

@Composable
fun GridOverlay(gridSize: Float) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val gridColor = Color.White.copy(alpha = 0.08f)

        var x = 0f
        while (x < w) {
            drawLine(
                color = gridColor,
                start = Offset(x, 0f),
                end = Offset(x, h),
                strokeWidth = 1f
            )
            x += gridSize
        }

        var y = 0f
        while (y < h) {
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
            )
            y += gridSize
        }
    }
}
