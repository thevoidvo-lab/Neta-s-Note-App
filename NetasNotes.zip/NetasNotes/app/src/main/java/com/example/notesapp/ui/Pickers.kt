package com.example.notesapp.ui

import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** Wrapper file picker (SAF). Harus dibuat sebagai field activity. */
class Pickers(a: ComponentActivity) {
    private var cb: ((Uri?) -> Unit)? = null
    private val open = a.registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> val f = cb; cb = null; f?.invoke(u) }
    private val create = a.registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u -> val f = cb; cb = null; f?.invoke(u) }

    fun image(onUri: (Uri?) -> Unit) { cb = onUri; open.launch(arrayOf("image/*")) }
    fun png(onUri: (Uri?) -> Unit) { cb = onUri; open.launch(arrayOf("image/png")) }
    fun font(onUri: (Uri?) -> Unit) { cb = onUri; open.launch(arrayOf("*/*")) }
    fun json(onUri: (Uri?) -> Unit) { cb = onUri; open.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }
    fun createJson(name: String, onUri: (Uri?) -> Unit) { cb = onUri; create.launch(name) }
}
