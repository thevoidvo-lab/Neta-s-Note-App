package com.example.notesapp.ui

import com.example.notesapp.data.NoteElement

/** Daftar elemen + operasi layer. */
class ElementManager {
    val items = mutableListOf<NoteElement>()

    fun sorted(): List<NoteElement> = items.sortedBy { it.zIndex }
    fun byId(id: String) = items.firstOrNull { it.id == id }
    private fun nextZ() = (items.maxOfOrNull { it.zIndex } ?: 0) + 1

    fun add(e: NoteElement): NoteElement { e.zIndex = nextZ(); items.add(e); return e }
    fun remove(id: String) { items.removeAll { it.id == id } }

    fun duplicate(id: String): NoteElement? {
        val src = byId(id) ?: return null
        val c = src.copyNew().also { it.x += 40f; it.y += 40f; it.locked = false }
        return add(c)
    }

    private fun normalize(list: List<NoteElement>) { list.forEachIndexed { i, e -> e.zIndex = i } }

    fun bringFront(id: String) { val l = sorted().toMutableList(); val e = l.firstOrNull { it.id == id } ?: return; l.remove(e); l.add(e); normalize(l) }
    fun sendBack(id: String) { val l = sorted().toMutableList(); val e = l.firstOrNull { it.id == id } ?: return; l.remove(e); l.add(0, e); normalize(l) }
    fun moveUp(id: String) { val l = sorted().toMutableList(); val i = l.indexOfFirst { it.id == id }; if (i in 0 until l.size - 1) { val e = l.removeAt(i); l.add(i + 1, e); normalize(l) } }
    fun moveDown(id: String) { val l = sorted().toMutableList(); val i = l.indexOfFirst { it.id == id }; if (i > 0) { val e = l.removeAt(i); l.add(i - 1, e); normalize(l) } }
}
