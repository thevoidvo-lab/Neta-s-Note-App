package com.example.notesapp.ui

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import com.example.notesapp.util.*

/** Color picker bebas: slider RGBA + hex + palet cepat. */
object ColorPicker {
    private val palette = listOf(
        "#FFFFFF", "#000000", "#F44336", "#E91E63", "#9C27B0", "#673AB7", "#3F51B5", "#2196F3",
        "#03A9F4", "#00BCD4", "#009688", "#4CAF50", "#8BC34A", "#FFEB3B", "#FF9800", "#795548", "#9E9E9E"
    )

    fun show(a: Activity, initial: Int, onPick: (Int) -> Unit) {
        val t = ThemeManager.current
        var color = initial
        val box = a.vbox()
        box.addView(a.tv("Pilih warna", 20f, t.text, true))
        val preview = View(a)
        box.addView(preview, box.lin(MATCH, a.dp(56), t = 12))
        val hexEt = EditText(a).apply {
            setTextColor(t.text); textSize = 15f; maxLines = 1
            background = a.rr(withAlpha(t.text, .07f), 12f); pad(14, 10)
        }
        val slidersBox = a.vbox()
        var rebuilding = false

        fun paint() {
            preview.background = a.rr(color, 14f, t.textSecondary, 1f)
            rebuilding = true
            hexEt.setText(String.format("#%06X", 0xFFFFFF and color))
            rebuilding = false
        }
        fun buildSliders() {
            slidersBox.removeAllViews()
            fun s(label: String, v: Int, f: (Int) -> Int) {
                slidersBox.addView(a.slider(label, 0f, 255f, v.toFloat(), { x -> color = f(x.toInt()); paint() }, {}))
            }
            s("R", Color.red(color)) { Color.argb(Color.alpha(color), it, Color.green(color), Color.blue(color)) }
            s("G", Color.green(color)) { Color.argb(Color.alpha(color), Color.red(color), it, Color.blue(color)) }
            s("B", Color.blue(color)) { Color.argb(Color.alpha(color), Color.red(color), Color.green(color), it) }
            s("Alpha", Color.alpha(color)) { Color.argb(it, Color.red(color), Color.green(color), Color.blue(color)) }
        }
        hexEt.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (rebuilding) return
                val txt = s?.toString() ?: return
                if (txt.length == 7 && txt.startsWith("#")) {
                    try {
                        val p = Color.parseColor(txt)
                        color = Color.argb(Color.alpha(color), Color.red(p), Color.green(p), Color.blue(p))
                        preview.background = a.rr(color, 14f, t.textSecondary, 1f); buildSliders()
                    } catch (e: Exception) { }
                }
            }
        })
        val row = a.hbox().apply { setPadding(0, a.dp(12), 0, a.dp(4)) }
        palette.forEach { hx ->
            val c = Color.parseColor(hx)
            val dot = View(a).apply {
                background = a.rr(c, 16f, t.textSecondary, 1f)
                setOnClickListener { color = Color.argb(Color.alpha(color), Color.red(c), Color.green(c), Color.blue(c)); paint(); buildSliders() }
            }
            row.addView(dot, LinearLayout.LayoutParams(a.dp(32), a.dp(32)).apply { marginEnd = a.dp(10) })
        }
        val hs = HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false; addView(row) }
        box.addView(hs, box.lin())
        box.addView(hexEt, box.lin(MATCH, WRAP, t = 4))
        box.addView(slidersBox, box.lin(t = 4))
        paint(); buildSliders()

        lateinit var d: Dialog
        val btns = a.hbox()
        val cancel = a.button("Batal", filled = false) { d.dismiss() }
        val ok = a.button("Pilih") { d.dismiss(); onPick(color) }
        btns.addView(cancel, LinearLayout.LayoutParams(0, a.dp(46), 1f).apply { marginEnd = a.dp(8) })
        btns.addView(ok, LinearLayout.LayoutParams(0, a.dp(46), 1f))
        box.addView(btns, box.lin(t = 12))
        d = a.sheetDialog(box)
    }
}
