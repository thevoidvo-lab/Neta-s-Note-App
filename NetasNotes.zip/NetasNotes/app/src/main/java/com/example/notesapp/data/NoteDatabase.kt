package com.example.notesapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Scope hidup selama proses, dipakai supaya save tidak batal saat activity ditutup. */
val dbScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

@Database(entities = [Note::class], version = 1, exportSchema = false)
abstract class NoteDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao

    companion object {
        @Volatile private var inst: NoteDatabase? = null
        fun get(c: Context): NoteDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, NoteDatabase::class.java, "notes.db")
                .fallbackToDestructiveMigration()
                .build().also { inst = it }
        }
    }
}
