package com.example.notesapp.ui

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import android.widget.FrameLayout
import com.example.notesapp.data.NoteElement
import com.example.notesapp.util.FontManager
import com.example.notesapp.util.ImageHelper
import com.example.notesapp.util.parseColor
import kotlin.math.max
import kotlin.math.min

/** Render satu elemen (teks / gambar / sticker / bentuk). Posisi & transform diambil dari NoteElement. */
class ElementView(ctx: Context, var el: NoteElement) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private var layout: StaticLayout? = null
    private var bmp: Bitmap? = null
    private var bmpPath: String? = null
    private val pad = 8
    private val path = Path()

    fun refresh() {
        visibility = if (el.hidden) GONE else VISIBLE
        alpha = el.opacity
        when (el.type) {
            "text" -> buildLayout()
            "image", "sticker" -> if (bmpPath != el.content) {
                bmpPath = el.content
                bmp = ImageHelper.decode(el.content, 1600)   // null -> placeholder
            }
        }
        val w = el.width.toInt().coerceAtLeast(1)
        val h = el.height.toInt().coerceAtLeast(1)
        val lp = layoutParams as? FrameLayout.LayoutParams
        if (lp == null || lp.width != w || lp.height != h) {
            layoutParams = (lp ?: FrameLayout.LayoutParams(w, h)).also { it.width = w; it.height = h }
        }
        pivotX = el.width / 2f; pivotY = el.height / 2f
        translationX = el.x; translationY = el.y
        rotation = el.rotation; scaleX = el.scale; scaleY = el.scale
        invalidate()
    }

    private fun buildLayout() {
        tp.textSize = el.fontSize ?: 64f
        tp.color = parseColor(el.color, Color.WHITE)
        tp.typeface = FontManager.load(context, el.fontFamily, el.bold, el.italic)
        tp.isUnderlineText = el.underline
        val w = (el.width - pad * 2).toInt().coerceAtLeast(10)
        val text = if (el.content.isEmpty()) " " else el.content
        val al = when (el.align) { 1 -> Layout.Alignment.ALIGN_CENTER; 2 -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_NORMAL }
        val l = StaticLayout.Builder.obtain(text, 0, text.length, tp, w)
            .setAlignment(al).setLineSpacing(0f, el.lineSpacing).setIncludePad(true).build()
        layout = l
        el.height = (l.height + pad * 2).toFloat()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        when (el.type) {
            "text" -> { c.save(); c.translate(pad.toFloat(), pad.toFloat()); layout?.draw(c); c.restore() }
            "shape" -> drawShape(c, w, h)
            else -> drawBitmap(c, w, h)
        }
    }

    private fun drawShape(c: Canvas, w: Float, h: Float) {
        val sw = el.strokeWidth
        val i = sw / 2f
        val r = RectF(i, i, w - i, h - i)
        val cr = el.cornerRadius
        fun drawIt() {
            when (el.content) {
                "oval" -> c.drawOval(r, paint)
                "round" -> c.drawRoundRect(r, cr, cr, paint)
                "triangle" -> { path.reset(); path.moveTo(w / 2f, i); path.lineTo(w - i, h - i); path.lineTo(i, h - i); path.close(); c.drawPath(path, paint) }
                else -> if (cr > 0f) c.drawRoundRect(r, cr, cr, paint) else c.drawRect(r, paint)
            }
        }
        paint.style = Paint.Style.FILL
        paint.color = parseColor(el.color, Color.LTGRAY)
        drawIt()
        if (sw > 0f) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = sw
            paint.color = parseColor(el.strokeColor, Color.WHITE)
            drawIt()
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawBitmap(c: Canvas, w: Float, h: Float) {
        val b = bmp
        val dst = RectF(0f, 0f, w, h)
        if (b == null) {   // gambar gagal load -> placeholder
            paint.style = Paint.Style.FILL; paint.color = 0xFF616161.toInt()
            c.drawRoundRect(dst, 16f, 16f, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 6f; paint.color = 0xFFBDBDBD.toInt()
            c.drawLine(w * .3f, h * .3f, w * .7f, h * .7f, paint); c.drawLine(w * .7f, h * .3f, w * .3f, h * .7f, paint)
            paint.style = Paint.Style.FILL
            return
        }
        paint.style = Paint.Style.FILL; paint.color = Color.WHITE
        if (el.type == "sticker") {
            val s = min(w / b.width, h / b.height)
            val dw = b.width * s; val dh = b.height * s
            c.drawBitmap(b, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), paint)
        } else {
            val s = max(w / b.width, h / b.height)
            val sw = w / s; val sh = h / s
            val src = Rect(((b.width - sw) / 2).toInt(), ((b.height - sh) / 2).toInt(), ((b.width + sw) / 2).toInt(), ((b.height + sh) / 2).toInt())
            c.save()
            path.reset(); path.addRoundRect(dst, el.cornerRadius, el.cornerRadius, Path.Direction.CW); c.clipPath(path)
            c.drawBitmap(b, src, dst, paint)
            c.restore()
        }
    }
}
