package com.example.notesapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.example.notesapp.ui.NoteListActivity

/** Pintu masuk (dipakai activity-alias ikon). Langsung lempar ke daftar catatan. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startActivity(Intent(this, NoteListActivity::class.java))
        finish()
    }
}
