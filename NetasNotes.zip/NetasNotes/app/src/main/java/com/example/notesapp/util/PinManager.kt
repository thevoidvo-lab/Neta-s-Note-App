package com.example.notesapp.util

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.SharedPreferences
import android.text.InputType
import android.widget.EditText
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object PinManager {
    private fun prefs(c: Context): SharedPreferences {
        val key = MasterKey.Builder(c.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            c.applicationContext, "secure_pin", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun hasPin(c: Context) = try { prefs(c).contains("pin") } catch (e: Exception) { false }
    fun setPin(c: Context, pin: String) { try { prefs(c).edit().putString("pin", pin).apply() } catch (e: Exception) { CrashHandler.log(c, "setPin", e) } }
    fun check(c: Context, pin: String) = try { prefs(c).getString("pin", null) == pin } catch (e: Exception) { false }

    private fun pinField(a: Activity, hint: String) = EditText(a).apply {
        val t = ThemeManager.current
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        this.hint = hint; setHintTextColor(t.textSecondary); setTextColor(t.text)
        background = a.rr(withAlpha(t.text, .07f), 14f); pad(16, 12)
    }

    /** Minta PIN. Salah 5x -> activity ditutup. Kalau belum ada PIN, suruh bikin dulu. */
    fun requirePin(a: Activity, onOk: () -> Unit) {
        if (!hasPin(a)) newPin(a, "Buat PIN dulu") { onOk() } else verify(a, "Masukkan PIN", onOk)
    }

    fun verify(a: Activity, title: String, onOk: () -> Unit) {
        val t = ThemeManager.current
        var tries = 0
        val box = a.vbox()
        box.addView(a.tv(title, 20f, t.text, true))
        val et = pinField(a, "PIN")
        box.addView(et, box.lin(MATCH, WRAP, t = 14))
        val err = a.tv("", 12f, 0xFFE57373.toInt())
        box.addView(err, box.lin(MATCH, WRAP, t = 6))
        lateinit var d: Dialog
        box.addView(a.button("Buka") {
            if (check(a, et.text.toString())) { d.dismiss(); onOk() }
            else {
                tries++; et.text.clear()
                if (tries >= 5) { d.dismiss(); a.toast("Terlalu banyak percobaan salah"); a.finish() }
                else err.text = "PIN salah ($tries/5)"
            }
        }, box.lin(MATCH, a.dp(46), t = 12))
        d = a.sheetDialog(box)
    }

    fun newPin(a: Activity, title: String, onDone: () -> Unit) {
        val t = ThemeManager.current
        val box = a.vbox()
        box.addView(a.tv(title, 20f, t.text, true))
        val p1 = pinField(a, "PIN baru (min. 4 angka)")
        val p2 = pinField(a, "Ulangi PIN")
        box.addView(p1, box.lin(MATCH, WRAP, t = 14))
        box.addView(p2, box.lin(MATCH, WRAP, t = 8))
        lateinit var d: Dialog
        box.addView(a.button("Simpan PIN") {
            val x = p1.text.toString()
            when {
                x.length < 4 -> a.toast("Minimal 4 angka")
                x != p2.text.toString() -> a.toast("PIN tidak sama")
                else -> { setPin(a, x); d.dismiss(); a.toast("PIN disimpan"); onDone() }
            }
        }, box.lin(MATCH, a.dp(46), t = 12))
        d = a.sheetDialog(box)
    }

    fun changePin(a: Activity) {
        if (hasPin(a)) verify(a, "PIN lama") { newPin(a, "PIN baru") { } } else newPin(a, "Buat PIN") { }
    }
}
