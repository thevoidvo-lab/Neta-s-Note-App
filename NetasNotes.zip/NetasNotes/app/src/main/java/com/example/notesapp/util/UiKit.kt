package com.example.notesapp.util

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.*

const val MATCH = -1
const val WRAP = -2

fun Context.dp(v: Number): Int = (v.toFloat() * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(v: Number): Int = context.dp(v)

fun hex(c: Int): String = String.format("#%08X", c)
fun parseColor(s: String?, def: Int): Int = try { if (s.isNullOrBlank()) def else Color.parseColor(s) } catch (e: Exception) { def }
fun withAlpha(c: Int, a: Float): Int = Color.argb((a * 255).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))
fun luminance(c: Int): Double = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
fun contrastOf(bg: Int): Int = if (luminance(bg) > 0.55) Color.parseColor("#111111") else Color.WHITE

/** Rounded rect drawable (r dalam dp). */
fun Context.rr(color: Int, r: Float, stroke: Int = 0, strokeDp: Float = 0f): GradientDrawable =
    GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (strokeDp > 0f) setStroke(dp(strokeDp), stroke)
    }

fun Context.topRr(color: Int, r: Float = 24f): GradientDrawable = GradientDrawable().apply {
    setColor(color); val p = dp(r).toFloat(); cornerRadii = floatArrayOf(p, p, p, p, 0f, 0f, 0f, 0f)
}

fun ripple(base: Drawable?, color: Int): Drawable =
    RippleDrawable(ColorStateList.valueOf(withAlpha(color, .2f)), base, if (base == null) ColorDrawable(Color.WHITE) else null)

fun Context.tv(s: CharSequence, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    text = s; textSize = sp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
}

fun Context.iv(res: Int, tint: Int, sizeDp: Int = 24) = ImageView(this).apply {
    setImageResource(res); setColorFilter(tint); layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
}

fun Context.vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
fun Context.hbox() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

fun View.pad(h: Int, v: Int = h) = setPadding(dp(h), dp(v), dp(h), dp(v))

/** LayoutParams untuk LinearLayout; margin dalam dp. */
fun View.lin(w: Int = MATCH, h: Int = WRAP, wt: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
    LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

fun Context.button(label: String, filled: Boolean = true, danger: Boolean = false, onClick: () -> Unit): TextView {
    val t = ThemeManager.current
    val base = if (danger) 0xFFE57373.toInt() else t.primary
    return TextView(this).apply {
        text = label; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(if (filled) contrastOf(base) else base)
        background = ripple(if (filled) rr(base, 16f) else rr(Color.TRANSPARENT, 16f, base, 1.5f), if (filled) contrastOf(base) else base)
        setPadding(dp(18), 0, dp(18), 0)
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(46))
        setOnClickListener { onClick() }
    }
}

fun Context.chip(label: String, active: Boolean, onClick: () -> Unit): TextView {
    val t = ThemeManager.current
    return TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (active) contrastOf(t.primary) else t.text)
        background = ripple(rr(if (active) t.primary else withAlpha(t.text, .08f), 20f), t.text)
        setPadding(dp(16), dp(9), dp(16), dp(9))
        layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) }
        setOnClickListener { onClick() }
    }
}

fun Context.slider(label: String, min: Float, max: Float, value: Float, onChange: (Float) -> Unit, onDone: () -> Unit): View {
    val t = ThemeManager.current
    val box = vbox().apply { setPadding(0, dp(6), 0, dp(6)) }
    val head = hbox()
    val num = tv("", 13f, t.text)
    head.addView(tv(label, 13f, t.textSecondary), LinearLayout.LayoutParams(0, WRAP, 1f))
    head.addView(num)
    fun show(v: Float) { num.text = if (max - min >= 20f) v.toInt().toString() else String.format("%.2f", v) }
    show(value)
    val sb = SeekBar(this).apply {
        this.max = 1000
        progress = ((value - min) / (max - min) * 1000f).toInt().coerceIn(0, 1000)
        progressTintList = ColorStateList.valueOf(t.primary)
        thumbTintList = ColorStateList.valueOf(t.primary)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) { val v = min + (max - min) * p / 1000f; show(v); onChange(v) }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { onDone() }
        })
    }
    box.addView(head); box.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP))
    return box
}

/** Dialog tengah, sudut 24dp, background surface, padding 24dp. */
fun Activity.sheetDialog(content: View): Dialog {
    val t = ThemeManager.current
    val d = Dialog(this)
    d.requestWindowFeature(Window.FEATURE_NO_TITLE)
    val sv = ScrollView(this).apply {
        background = rr(t.surface, 24f); setPadding(dp(24), dp(24), dp(24), dp(24)); isVerticalScrollBarEnabled = false
        addView(content)
    }
    d.setContentView(sv)
    d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    d.show()
    d.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), WRAP)
    return d
}

class Act(val label: String, val danger: Boolean = false, val fn: () -> Unit)

fun Activity.actionList(title: String?, items: List<Act>) {
    val t = ThemeManager.current
    val box = vbox()
    if (title != null) box.addView(tv(title, 18f, t.text, true), box.lin(MATCH, WRAP, b = 8))
    lateinit var d: Dialog
    items.forEach { a ->
        val v = tv(a.label, 16f, if (a.danger) 0xFFE57373.toInt() else t.text)
        v.pad(8, 14)
        v.background = ripple(null, t.text)
        v.setOnClickListener { d.dismiss(); a.fn() }
        box.addView(v, box.lin())
    }
    d = sheetDialog(box)
}
