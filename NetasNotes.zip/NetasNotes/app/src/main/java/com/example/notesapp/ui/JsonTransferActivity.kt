package com.example.notesapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.notesapp.data.NoteDatabase
import com.example.notesapp.data.noteFromJson
import com.example.notesapp.data.toJson
import com.example.notesapp.util.CrashHandler
import com.example.notesapp.util.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Activity tanpa UI: langsung buka file picker untuk ekspor / impor, lalu menutup diri. */
class JsonTransferActivity : AppCompatActivity() {
    private val pickers = Pickers(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent.getStringExtra("mode") == "import") doImport() else doExport()
    }

    private fun doExport() {
        pickers.createJson("netas-notes-${System.currentTimeMillis()}.json") { uri ->
            if (uri == null) { finish(); return@createJson }
            lifecycleScope.launch {
                try {
                    val json = withContext(Dispatchers.IO) {
                        val arr = JSONArray()
                        NoteDatabase.get(this@JsonTransferActivity).noteDao().getAll().forEach { arr.put(it.toJson()) }
                        JSONObject().put("version", 1).put("notes", arr).toString(2)
                    }
                    withContext(Dispatchers.IO) {
                        contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } ?: throw IllegalStateException("no stream")
                    }
                    toast("Ekspor berhasil")
                } catch (e: Exception) {
                    CrashHandler.log(this@JsonTransferActivity, "export", e); toast("Ekspor gagal")
                }
                finish()
            }
        }
    }

    private fun doImport() {
        pickers.json { uri ->
            if (uri == null) { finish(); return@json }
            lifecycleScope.launch {
                try {
                    val n = withContext(Dispatchers.IO) {
                        val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                        val arr = JSONObject(text).getJSONArray("notes")
                        val dao = NoteDatabase.get(this@JsonTransferActivity).noteDao()
                        var count = 0
                        for (i in 0 until arr.length()) { dao.insert(noteFromJson(arr.getJSONObject(i))); count++ }
                        count
                    }
                    toast("$n catatan diimpor")
                } catch (e: Exception) {
                    CrashHandler.log(this@JsonTransferActivity, "import", e); toast("File JSON tidak valid")
                }
                finish()
            }
        }
    }
}
