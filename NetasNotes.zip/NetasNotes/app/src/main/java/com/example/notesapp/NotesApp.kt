package com.example.notesapp

import android.app.Application
import com.example.notesapp.util.CrashHandler
import com.example.notesapp.util.ThemeManager

class NotesApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashHandler.install(this)
        ThemeManager.load(this)
    }
}
