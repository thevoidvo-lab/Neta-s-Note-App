package com.example.notesapp.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.notesapp.data.Note
import com.example.notesapp.data.NoteDatabase
import com.example.notesapp.util.CrashHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotesViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = NoteDatabase.get(app).noteDao()

    val all: LiveData<List<Note>> = dao.observeAll()
    val query = MutableLiveData("")
    val filter = MutableLiveData(0)               // 0 semua, 1 pinned, 2 locked, 3 kategori
    val category = MutableLiveData<String?>(null)

    val visible = MediatorLiveData<List<Note>>().apply {
        fun update() {
            val q = (query.value ?: "").trim().lowercase()
            val list = (all.value ?: emptyList()).filter { n ->
                val okFilter = when (filter.value) {
                    1 -> n.isPinned
                    2 -> n.isLocked
                    3 -> category.value == null || n.category == category.value
                    else -> true
                }
                // catatan terkunci: isi tidak ikut dicari
                val okQuery = q.isEmpty() || n.title.lowercase().contains(q) || (!n.isLocked && n.content.lowercase().contains(q))
                okFilter && okQuery
            }
            value = list
        }
        addSource(all) { update() }
        addSource(query) { update() }
        addSource(filter) { update() }
        addSource(category) { update() }
    }

    private fun io(block: suspend () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try { block() } catch (e: Exception) { CrashHandler.log(getApplication(), "db error", e) }
        }
    }

    fun togglePin(n: Note) { io { dao.update(n.copy(isPinned = !n.isPinned)) } }
    fun toggleLock(n: Note) { io { dao.update(n.copy(isLocked = !n.isLocked)) } }
    fun setCategory(n: Note, c: String?) { io { dao.update(n.copy(category = c?.ifBlank { null })) } }
    fun delete(n: Note) { io { dao.delete(n) } }
    fun restore(n: Note) { io { dao.insert(n) } }
    fun duplicate(n: Note) {
        io {
            val now = System.currentTimeMillis()
            dao.insert(n.copy(id = 0, title = n.title + " (salinan)", isPinned = false, createdAt = now, updatedAt = now))
        }
    }
}
