package com.example.notesapp.ui

import android.app.Dialog
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.notesapp.R
import com.example.notesapp.data.*
import com.example.notesapp.util.*
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class NoteEditActivity : AppCompatActivity(), CanvasView.Listener {
    private lateinit var canvas: CanvasView
    private lateinit var btnUndo: ImageView
    private lateinit var btnRedo: ImageView
    private lateinit var dao: NoteDao
    private val undo = UndoRedoManager(100)
    private val pickers = Pickers(this)
    private val handler = Handler(Looper.getMainLooper())
    private var note: Note? = null
    private var wasNew = false
    private var dirty = false
    private var sel: NoteElement? = null
    private var title = ""
    private var sheet: BottomSheetDialog? = null
    private val t get() = ThemeManager.current

    private val autosave = object : Runnable {
        override fun run() { if (dirty) saveNow(); handler.postDelayed(this, 5000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeManager.apply(this)
        dao = NoteDatabase.get(this).noteDao()
        buildUi()
        lifecycleScope.launch { loadNote(intent.getLongExtra("id", -1L)) }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { closeEditor() }
        })
    }

    override fun onPause() { super.onPause(); saveNow() }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    // ---------------- UI ----------------
    private fun buildUi() {
        val root = FrameLayout(this)
        canvas = CanvasView(this).also { it.listener = this }
        root.addView(canvas, FrameLayout.LayoutParams(MATCH, MATCH))

        fun ib(res: Int, click: () -> Unit) = iv(res, t.text).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10)); layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            background = ripple(rr(Color.TRANSPARENT, 22f), t.text); setOnClickListener { click() }
        }
        val top = hbox().apply {
            background = rr(withAlpha(t.surface, .94f), 28f); elevation = dp(8).toFloat(); setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        top.addView(ib(R.drawable.ic_arrow_back) { closeEditor() })
        btnUndo = ib(R.drawable.ic_undo) { doUndo() }; top.addView(btnUndo)
        btnRedo = ib(R.drawable.ic_redo) { doRedo() }; top.addView(btnRedo)
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(ib(R.drawable.ic_settings) { showCanvasSettings() })
        top.addView(ib(R.drawable.ic_check) { saveNow(); toast("Tersimpan") })
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), dp(8), dp(12), 0) })

        val barBox = vbox().apply { background = topRr(t.surface, 24f); elevation = dp(12).toFloat() }
        barBox.addView(View(this).apply { background = rr(withAlpha(t.textSecondary, .5f), 3f) },
            LinearLayout.LayoutParams(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
        val row = hbox().apply { setPadding(dp(12), dp(10), dp(12), dp(14)) }
        listOf(
            Act("+ Element") { showAddPanel() }, Act("Font") { showFontPanel() }, Act("Color") { showColorPanel() },
            Act("Background") { showBgPanel() }, Act("Sticker") { showStickerPanel() }, Act("Layer") { showLayerPanel() }
        ).forEach { a -> row.addView(chip(a.label, false) { a.fn() }) }
        barBox.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        root.addView(barBox, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        setContentView(root)
        canvas.fitToScreen(dp(72), dp(96))
    }

    private suspend fun loadNote(id: Long) {
        var n = if (id > 0) withContext(Dispatchers.IO) { dao.get(id) } else null
        if (n == null) {
            wasNew = true
            val bgPath = Prefs.get("defaultBg")?.takeIf { File(it).exists() }
            val meta = CanvasMeta(bgColor = hex(t.surface), bgType = if (bgPath != null) "image" else "solid", bgImage = bgPath)
            val fresh = Note(canvasMeta = meta.toJson().toString(), width = meta.width, height = meta.height,
                backgroundPath = bgPath, color = meta.bgColor)
            val newId = withContext(Dispatchers.IO) { dao.insert(fresh) }
            n = fresh.copy(id = newId)
        }
        note = n
        title = n.title
        val meta = CanvasMeta.parse(n.canvasMeta, n.width, n.height)
        canvas.load(NoteElement.parse(n.elements), meta)
        canvas.fitToScreen(dp(72), dp(96))
        undo.reset(snapshot()); updateUndoButtons()
        handler.postDelayed(autosave, 5000)
    }

    // ---------------- state / save ----------------
    private fun snapshot(): String = JSONObject().put("m", canvas.meta.toJson())
        .put("e", NoteElement.toJsonArray(canvas.manager.items)).put("t", title).toString()

    private fun restore(s: String) {
        try {
            val o = JSONObject(s)
            title = o.optString("t", "")
            canvas.load(NoteElement.parse(o.getJSONArray("e").toString()), CanvasMeta.fromJson(o.getJSONObject("m")))
        } catch (e: Exception) { CrashHandler.log(this, "restore", e) }
    }

    private fun commit() { undo.commit(snapshot()); dirty = true; updateUndoButtons(); saveNow() }
    private fun updateUndoButtons() { btnUndo.alpha = if (undo.canUndo) 1f else .35f; btnRedo.alpha = if (undo.canRedo) 1f else .35f }
    private fun doUndo() { undo.undo()?.let { restore(it); dirty = true; saveNow(); updateUndoButtons() } }
    private fun doRedo() { undo.redo()?.let { restore(it); dirty = true; saveNow(); updateUndoButtons() } }

    private fun saveNow() {
        val n = note ?: return
        val m = canvas.meta
        val items = canvas.manager.items
        val texts = items.filter { it.type == "text" && !it.hidden }.sortedBy { it.y }
        val derived = texts.firstOrNull()?.content?.lineSequence()?.firstOrNull()?.take(60) ?: ""
        val u = n.copy(
            title = title.ifBlank { derived.ifBlank { "Tanpa judul" } },
            content = texts.joinToString("\n") { it.content },
            elements = NoteElement.toJsonArray(items).toString(),
            backgroundPath = m.bgImage, color = m.bgColor, width = m.width, height = m.height,
            canvasMeta = m.toJson().toString(), updatedAt = System.currentTimeMillis()
        )
        note = u; dirty = false
        dbScope.launch {
            try { dao.update(u) } catch (e: Exception) {
                CrashHandler.log(this@NoteEditActivity, "save", e)
                withContext(Dispatchers.Main) { toast("Gagal menyimpan") }
            }
        }
    }

    private fun closeEditor() {
        val n = note
        if (n != null && wasNew && canvas.manager.items.isEmpty() && title.isBlank()) {
            dbScope.launch { try { dao.deleteById(n.id) } catch (e: Exception) { } }
        } else saveNow()
        finish()
    }

    // ---------------- CanvasView.Listener ----------------
    override fun onSelect(el: NoteElement?) { sel = el }
    override fun onGestureEnd() { commit() }
    override fun onEditText(el: NoteElement) { showEditText(el) }

    override fun onLongPress(el: NoteElement) {
        actionList(when (el.type) { "text" -> "Teks"; "shape" -> "Bentuk"; "sticker" -> "Sticker"; else -> "Gambar" }, listOf(
            Act("Duplikat") { duplicate(el) },
            Act(if (el.locked) "Buka kunci" else "Kunci") { el.locked = !el.locked; canvas.refreshEl(el); commit() },
            Act("Sembunyikan") { el.hidden = true; canvas.refreshEl(el); canvas.select(null); commit() },
            Act("Bawa ke depan") { canvas.manager.bringFront(el.id); canvas.reorder(); commit() },
            Act("Kirim ke belakang") { canvas.manager.sendBack(el.id); canvas.reorder(); commit() },
            Act("Hapus", true) { canvas.removeElement(el.id); commit() }
        ))
    }

    private fun duplicate(el: NoteElement) {
        val c = canvas.manager.duplicate(el.id) ?: return
        canvas.attach(c); canvas.select(c); commit()
    }

    // ---------------- helpers ----------------
    private fun needSel(): Boolean { if (sel == null) toast("Pilih elemen dulu"); return sel == null }

    private fun bottomSheet(build: LinearLayout.() -> Unit) {
        sheet?.dismiss()
        val d = BottomSheetDialog(this)
        val col = vbox().apply { setPadding(dp(24), dp(12), dp(24), dp(28)) }
        col.addView(View(this).apply { background = rr(withAlpha(t.textSecondary, .5f), 3f) },
            LinearLayout.LayoutParams(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(16) })
        col.build()
        d.setContentView(ScrollView(this).apply { addView(col) })
        d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.background = topRr(t.surface, 24f)
        d.window?.setDimAmount(0.25f)
        sheet = d; d.show()
    }

    private class Tile(val icon: Int, val label: String, val fn: () -> Unit)

    private fun tileGrid(tiles: List<Tile>, cols: Int = 4): LinearLayout {
        val g = vbox()
        tiles.chunked(cols).forEach { rowTiles ->
            val r = hbox()
            for (i in 0 until cols) {
                val tile = rowTiles.getOrNull(i)
                if (tile == null) { r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)); continue }
                val v = vbox().apply {
                    gravity = Gravity.CENTER; setPadding(dp(4), dp(12), dp(4), dp(10))
                    background = ripple(rr(withAlpha(t.text, .06f), 16f), t.text)
                    addView(iv(tile.icon, t.primary, 26)); addView(tv(tile.label, 11f, t.text).apply { gravity = Gravity.CENTER }, lin(WRAP, WRAP, t = 6))
                    setOnClickListener { sheet?.dismiss(); tile.fn() }
                }
                r.addView(v, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            g.addView(r)
        }
        return g
    }

    private fun colorRow(label: String, color: Int, onPick: (Int) -> Unit): View {
        val sw = View(this).apply { background = rr(color, 12f, t.textSecondary, 1f) }
        return hbox().apply {
            setPadding(0, dp(10), 0, dp(10)); background = ripple(null, t.text)
            addView(tv(label, 15f, t.text), LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(sw, LinearLayout.LayoutParams(dp(40), dp(40)))
            setOnClickListener { ColorPicker.show(this@NoteEditActivity, color) { c -> sw.background = rr(c, 12f, t.textSecondary, 1f); onPick(c) } }
        }
    }

    private fun toggle(label: String, init: Boolean, onToggle: (Boolean) -> Unit): TextView {
        var on = init
        lateinit var v: TextView
        fun style() { v.setTextColor(if (on) contrastOf(t.primary) else t.text); v.background = rr(if (on) t.primary else withAlpha(t.text, .08f), 14f) }
        v = tv(label, 15f, t.text, true).apply { gravity = Gravity.CENTER; setOnClickListener { on = !on; style(); onToggle(on) } }
        style(); return v
    }

    private fun addElement(el: NoteElement) {
        val c = canvas.viewportCenterBoard()
        el.x = c[0] - el.width / 2f; el.y = c[1] - 60f
        canvas.manager.add(el); canvas.attach(el); canvas.select(el); commit()
    }

    private fun textColor() = contrastOf(parseColor(canvas.meta.bgColor, Color.BLACK).let { if (canvas.meta.bgType == "solid") it else Color.BLACK })

    // ---------------- panels ----------------
    private fun showAddPanel() = bottomSheet {
        addView(tv("Tambah elemen", 18f, t.text, true), lin(b = 8))
        fun txt(title: Boolean) = addElement(NoteElement(type = "text", content = if (title) "Judul" else "Ketuk dua kali untuk edit",
            width = 720f, fontSize = if (title) 120f else 64f, bold = title, fontFamily = Prefs.get("defaultFont"),
            color = hex(textColor())))
        fun shape(kind: String) = addElement(NoteElement(type = "shape", content = kind, width = 360f, height = 360f,
            color = hex(t.primary), cornerRadius = if (kind == "round") 64f else 0f))
        addView(tileGrid(listOf(
            Tile(R.drawable.ic_text, "Teks") { txt(false) }, Tile(R.drawable.ic_text, "Judul") { txt(true) },
            Tile(R.drawable.ic_shapes, "Kotak") { shape("rect") }, Tile(R.drawable.ic_shapes, "Rounded") { shape("round") },
            Tile(R.drawable.ic_shapes, "Bulat") { shape("oval") }, Tile(R.drawable.ic_shapes, "Segitiga") { shape("triangle") },
            Tile(R.drawable.ic_image, "Gambar") { pickImageElement() }, Tile(R.drawable.ic_palette, "Sticker") { showStickerPanel() }
        )))
    }

    private fun pickImageElement() {
        pickers.image { uri ->
            if (uri == null) return@image
            val p = ImageHelper.importImage(this, uri, "images")
            val b = ImageHelper.decode(p, 1024)
            if (p == null || b == null) { toast("Gambar gagal dimuat"); return@image }
            val w = 640f
            addElement(NoteElement(type = "image", content = p, width = w, height = w * b.height / b.width))
        }
    }

    private fun buildStickerCell(f: File): ImageView {
        val img = ImageView(this)
        img.setImageBitmap(ImageHelper.decode(f.absolutePath, 256))
        img.background = rr(withAlpha(t.text, .06f), 12f)
        img.setPadding(dp(6), dp(6), dp(6), dp(6))
        img.setOnClickListener {
            sheet?.dismiss()
            val bitmap = ImageHelper.decode(f.absolutePath, 512)
            if (bitmap == null) {
                toast("Sticker gagal dimuat")
            } else {
                val width = 360f
                val height = width * bitmap.height.toFloat() / bitmap.width.toFloat()
                addElement(NoteElement(type = "sticker", content = f.absolutePath, width = width, height = height))
            }
        }
        img.setOnLongClickListener { onStickerLongPress(f) }
        return img
    }

    private fun buildStickerGrid(files: List<File>): LinearLayout {
        val grid: LinearLayout = vbox()
        files.chunked(4).forEach { chunk: List<File> ->
            val row: LinearLayout = hbox()
            for (i in 0 until 4) {
                val file: File? = chunk.getOrNull(i)
                if (file == null) {
                    row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                    continue
                }
                val cell: ImageView = buildStickerCell(file)
                val params = LinearLayout.LayoutParams(0, dp(76), 1f)
                params.setMargins(dp(4), dp(4), dp(4), dp(4))
                row.addView(cell, params)
            }
            grid.addView(row)
        }
        return grid
    }

    private fun showStickerPanel() {
        bottomSheet {
            addView(tv("Sticker", 18f, t.text, true), lin(b = 8))
            val dir = ImageHelper.dir(this@NoteEditActivity, "stickers")
            val files: List<File> = dir.listFiles()?.sortedBy { it.name } ?: emptyList()
            if (files.isEmpty()) {
                addView(tv("Belum ada sticker. Upload PNG kamu sendiri.", 13f, t.textSecondary), lin(b = 8))
            }
            addView(buildStickerGrid(files))
            if (files.isNotEmpty()) {
                addView(tv("Tahan lama sticker untuk menghapus dari koleksi", 11f, t.textSecondary), lin(t = 6))
            }
            addView(button("+ Upload Sticker PNG") {
                sheet?.dismiss()
                pickers.png { uri -> handleStickerUpload(uri) }
            }, lin(MATCH, dp(46), t = 12))
        }
    }

    private fun onStickerLongPress(file: File): Boolean {
        file.delete()
        sheet?.dismiss()
        showStickerPanel()
        return true
    }

    private fun handleStickerUpload(uri: android.net.Uri?) {
        if (uri != null && ImageHelper.importImage(this, uri, "stickers") == null) {
            toast("Sticker gagal dimuat")
        }
        showStickerPanel()
    }

    private fun showFontPanel() {
        val el = sel
        if (el == null || el.type != "text") { toast("Pilih elemen teks dulu"); return }
        bottomSheet {
            addView(tv("Font & teks", 18f, t.text, true), lin(b = 8))
            addView(button("Font: ${el.fontFamily?.substringBeforeLast('.') ?: "Default"}", filled = false) {
                sheet?.dismiss()
                FontManager.showPicker(this@NoteEditActivity, el.fontFamily, { done ->
                    pickers.font { uri ->
                        if (uri != null && FontManager.import(this@NoteEditActivity, uri) == null) toast("Font gagal dimuat (pakai .ttf / .otf)")
                        done()
                    }
                }) { f -> el.fontFamily = f; canvas.refreshEl(el); commit() }
            }, lin(MATCH, dp(46)))
            addView(slider("Ukuran", 12f, 400f, el.fontSize ?: 64f, { el.fontSize = it; canvas.refreshEl(el) }, { commit() }))
            val r = hbox()
            r.addView(toggle("B", el.bold) { el.bold = it; canvas.refreshEl(el); commit() }, lin(0, dp(44), 1f, r = 8))
            r.addView(toggle("I", el.italic) { el.italic = it; canvas.refreshEl(el); commit() }, lin(0, dp(44), 1f, r = 8))
            r.addView(toggle("U", el.underline) { el.underline = it; canvas.refreshEl(el); commit() }, lin(0, dp(44), 1f))
            addView(r, lin(t = 6))
            val ar = hbox()
            val labels = listOf("Kiri", "Tengah", "Kanan")
            val chips = mutableListOf<TextView>()
            fun styleAlign() = chips.forEachIndexed { i, v ->
                val on = el.align == i
                v.setTextColor(if (on) contrastOf(t.primary) else t.text); v.background = rr(if (on) t.primary else withAlpha(t.text, .08f), 14f)
            }
            labels.forEachIndexed { i, l ->
                val v = tv(l, 14f, t.text, true).apply { gravity = Gravity.CENTER; setOnClickListener { el.align = i; styleAlign(); canvas.refreshEl(el); commit() } }
                chips.add(v); ar.addView(v, lin(0, dp(44), 1f, r = if (i < 2) 8 else 0))
            }
            styleAlign(); addView(ar, lin(t = 8))
            addView(slider("Spasi baris", 0.8f, 3f, el.lineSpacing, { el.lineSpacing = it; canvas.refreshEl(el) }, { commit() }))
        }
    }

    private fun showColorPanel() {
        val el = sel ?: run { toast("Pilih elemen dulu"); return }
        bottomSheet {
            addView(tv("Warna", 18f, t.text, true), lin(b = 4))
            if (el.type == "text" || el.type == "shape") {
                addView(colorRow(if (el.type == "text") "Warna teks" else "Warna isi", parseColor(el.color, Color.WHITE)) { c ->
                    el.color = hex(c); canvas.refreshEl(el); commit()
                })
            }
            if (el.type == "shape") {
                addView(colorRow("Warna border", parseColor(el.strokeColor, Color.WHITE)) { c -> el.strokeColor = hex(c); canvas.refreshEl(el); commit() })
                addView(slider("Tebal border", 0f, 60f, el.strokeWidth, { el.strokeWidth = it; canvas.refreshEl(el) }, { commit() }))
            }
            if (el.type == "shape" || el.type == "image") {
                addView(slider("Corner radius", 0f, 240f, el.cornerRadius, { el.cornerRadius = it; canvas.refreshEl(el) }, { commit() }))
            }
            addView(slider("Opacity", 0.05f, 1f, el.opacity, { el.opacity = it; canvas.refreshEl(el) }, { commit() }))
        }
    }

    private fun showBgPanel() {
        val m = canvas.meta
        fun upd() { canvas.refreshBg() }
        bottomSheet {
            addView(tv("Background canvas", 18f, t.text, true), lin(b = 8))
            val r = hbox()
            listOf("solid" to "Solid", "gradient" to "Gradient", "image" to "Gambar").forEach { (k, l) ->
                r.addView(chip(l, m.bgType == k) { m.bgType = k; upd(); commit(); showBgPanel() })
            }
            addView(r)
            addView(colorRow("Warna dasar", parseColor(m.bgColor, Color.WHITE)) { c -> m.bgColor = hex(c); upd(); commit() })
            if (m.bgType == "gradient") {
                addView(colorRow("Gradient awal", parseColor(m.gradStart, Color.MAGENTA)) { c -> m.gradStart = hex(c); upd(); commit() })
                addView(colorRow("Gradient akhir", parseColor(m.gradEnd, Color.CYAN)) { c -> m.gradEnd = hex(c); upd(); commit() })
                addView(slider("Sudut", 0f, 360f, m.gradAngle, { m.gradAngle = it; upd() }, { commit() }))
            }
            if (m.bgType == "image") {
                addView(button(if (m.bgImage == null) "+ Pilih gambar dari galeri" else "Ganti gambar", filled = false) {
                    sheet?.dismiss()
                    pickers.image { uri ->
                        val p = uri?.let { ImageHelper.importImage(this@NoteEditActivity, it, "backgrounds") }
                        if (p != null) { m.bgImage = p; upd(); commit() } else if (uri != null) toast("Gambar gagal dimuat")
                        showBgPanel()
                    }
                }, lin(MATCH, dp(46), t = 8))
                if (m.bgImage != null) {
                    addView(slider("Scale", 0.2f, 4f, m.imgScale, { m.imgScale = it; upd() }, { commit() }))
                    addView(slider("Rotate", -180f, 180f, m.imgRotation, { m.imgRotation = it; upd() }, { commit() }))
                    addView(slider("Posisi X", -m.width, m.width, m.imgOffX, { m.imgOffX = it; upd() }, { commit() }))
                    addView(slider("Posisi Y", -m.height, m.height, m.imgOffY, { m.imgOffY = it; upd() }, { commit() }))
                    addView(slider("Opacity", 0f, 1f, m.imgOpacity, { m.imgOpacity = it; upd() }, { commit() }))
                    addView(slider("Blur", 0f, 12f, m.imgBlur, { m.imgBlur = it; upd() }, { commit() }))
                    addView(button("Hapus gambar", filled = false, danger = true) { m.bgImage = null; m.bgType = "solid"; upd(); commit(); showBgPanel() }, lin(MATCH, dp(46), t = 8))
                }
            }
        }
    }

    private fun showLayerPanel() {
        bottomSheet {
            addView(tv("Layer", 18f, t.text, true), lin(b = 8))
            val list: LinearLayout = vbox()
            addView(list)
            refreshLayerList(list)
        }
    }

    private fun refreshLayerList(list: LinearLayout) {
        list.removeAllViews()
        val items: List<NoteElement> = canvas.manager.sorted().asReversed()
        if (items.isEmpty()) {
            list.addView(tv("Belum ada elemen", 13f, t.textSecondary))
            return
        }
        items.forEach { element: NoteElement ->
            val name: String = when (element.type) {
                "text" -> "Teks: " + element.content.take(18)
                "shape" -> "Bentuk (${element.content})"
                "sticker" -> "Sticker"
                else -> "Gambar"
            }
            val row: LinearLayout = hbox()
            row.setPadding(dp(8), dp(6), dp(4), dp(6))
            row.background = if (element.id == sel?.id) rr(withAlpha(t.primary, .18f), 12f) else null

            val nameView: TextView = tv(name, 14f, if (element.hidden) t.textSecondary else t.text)
            nameView.maxLines = 1
            nameView.setOnClickListener {
                canvas.select(element)
                refreshLayerList(list)
            }
            row.addView(nameView, LinearLayout.LayoutParams(0, WRAP, 1f))

            row.addView(layerActionButton(R.drawable.ic_up) {
                canvas.manager.moveUp(element.id)
                canvas.reorder()
                commit()
                refreshLayerList(list)
            })
            row.addView(layerActionButton(R.drawable.ic_down) {
                canvas.manager.moveDown(element.id)
                canvas.reorder()
                commit()
                refreshLayerList(list)
            })
            row.addView(layerActionButton(R.drawable.ic_visibility, !element.hidden) {
                element.hidden = !element.hidden
                canvas.refreshEl(element)
                commit()
                refreshLayerList(list)
            })
            row.addView(layerActionButton(R.drawable.ic_lock, element.locked) {
                element.locked = !element.locked
                canvas.refreshEl(element)
                commit()
                refreshLayerList(list)
            })
            row.addView(layerActionButton(R.drawable.ic_copy) {
                duplicate(element)
                refreshLayerList(list)
            })
            row.addView(layerActionButton(R.drawable.ic_delete) {
                canvas.removeElement(element.id)
                commit()
                refreshLayerList(list)
            })
            list.addView(row)
        }
    }

    private fun layerActionButton(res: Int, enabled: Boolean = true, action: () -> Unit): ImageView {
        val image = iv(res, if (enabled) t.text else withAlpha(t.textSecondary, .5f), 20)
        image.setPadding(dp(8), dp(8), dp(8), dp(8))
        image.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
        image.setOnClickListener { action() }
        return image
    }

    // ---------------- dialogs ----------------
    private fun showEditText(el: NoteElement) {
        val box = vbox()
        box.addView(tv("Edit teks", 18f, t.text, true))
        val et = EditText(this).apply {
            setText(el.content); setTextColor(t.text); setHintTextColor(t.textSecondary)
            background = rr(withAlpha(t.text, .07f), 14f); pad(14, 12); minLines = 3; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSelection(text.length)
        }
        box.addView(et, box.lin(t = 12))
        lateinit var d: Dialog
        val row = hbox()
        row.addView(button("Batal", filled = false) { d.dismiss() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(8) })
        row.addView(button("Simpan") { el.content = et.text.toString(); canvas.refreshEl(el); d.dismiss(); commit() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        box.addView(row, box.lin(t = 12))
        d = sheetDialog(box)
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        et.requestFocus()
    }

    private fun showCanvasSettings() {
        val m = canvas.meta
        val box = vbox()
        box.addView(tv("Pengaturan canvas", 20f, t.text, true))
        fun field(hint: String, v: String, number: Boolean) = EditText(this).apply {
            setText(v); this.hint = hint; setTextColor(t.text); setHintTextColor(t.textSecondary); maxLines = 1
            background = rr(withAlpha(t.text, .07f), 14f); pad(14, 10)
            if (number) inputType = InputType.TYPE_CLASS_NUMBER
        }
        val titleEt = field("Judul catatan", title, false)
        val wEt = field("Lebar", m.width.toInt().toString(), true)
        val hEt = field("Tinggi", m.height.toInt().toString(), true)
        box.addView(titleEt, box.lin(t = 12))
        val sizeRow = hbox()
        sizeRow.addView(wEt, sizeRow.lin(0, WRAP, 1f, r = 8)); sizeRow.addView(hEt, sizeRow.lin(0, WRAP, 1f))
        box.addView(sizeRow, box.lin(t = 8))
        val presets = hbox()
        listOf("1080×1920" to (1080 to 1920), "1080×1080" to (1080 to 1080), "A4" to (2480 to 3508)).forEach { (l, s) ->
            presets.addView(chip(l, false) { wEt.setText(s.first.toString()); hEt.setText(s.second.toString()) })
        }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(presets) }, box.lin(t = 8))
        var grid = m.grid; var snap = m.snap
        val gs = Switch(this).apply { text = "Grid"; isChecked = grid; setTextColor(t.text); setOnCheckedChangeListener { _, c -> grid = c } }
        val ss = Switch(this).apply { text = "Snap"; isChecked = snap; setTextColor(t.text); setOnCheckedChangeListener { _, c -> snap = c } }
        box.addView(gs, box.lin(t = 10)); box.addView(ss, box.lin(t = 6))
        var gsize = m.gridSize
        box.addView(slider("Ukuran grid", 10f, 200f, m.gridSize, { gsize = it }, {}))
        lateinit var d: Dialog
        val row = hbox()
        row.addView(button("Reset zoom", filled = false) { canvas.fitToScreen(dp(72), dp(96)) }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(8) })
        row.addView(button("Terapkan") {
            title = titleEt.text.toString().trim()
            m.width = (wEt.text.toString().toFloatOrNull() ?: m.width).coerceIn(200f, 6000f)
            m.height = (hEt.text.toString().toFloatOrNull() ?: m.height).coerceIn(200f, 6000f)
            m.grid = grid; m.snap = snap; m.gridSize = gsize
            canvas.applyMeta(); canvas.fitToScreen(dp(72), dp(96)); d.dismiss(); commit()
        }, LinearLayout.LayoutParams(0, dp(46), 1f))
        box.addView(row, box.lin(t = 14))
        d = sheetDialog(box)
    }
}
