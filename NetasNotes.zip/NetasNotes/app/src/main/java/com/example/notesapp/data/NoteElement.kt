package com.example.notesapp.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Satu elemen di canvas: type = text | image | sticker | shape. */
data class NoteElement(
    var id: String = UUID.randomUUID().toString(),
    var type: String = "text",
    var content: String = "",
    var x: Float = 0f, var y: Float = 0f,
    var width: Float = 400f, var height: Float = 120f,
    var rotation: Float = 0f, var scale: Float = 1f,
    var zIndex: Int = 0,
    var fontFamily: String? = null,
    var fontSize: Float? = 64f,
    var color: String? = "#FFFFFFFF",
    var bold: Boolean = false, var italic: Boolean = false, var underline: Boolean = false,
    var align: Int = 0, var lineSpacing: Float = 1f,
    var opacity: Float = 1f,
    var strokeColor: String? = null, var strokeWidth: Float = 0f, var cornerRadius: Float = 0f,
    var locked: Boolean = false, var hidden: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("type", type); put("content", content)
        put("x", x.toDouble()); put("y", y.toDouble())
        put("width", width.toDouble()); put("height", height.toDouble())
        put("rotation", rotation.toDouble()); put("scale", scale.toDouble()); put("zIndex", zIndex)
        put("fontFamily", fontFamily ?: JSONObject.NULL)
        put("fontSize", (fontSize ?: 64f).toDouble())
        put("color", color ?: JSONObject.NULL)
        put("bold", bold); put("italic", italic); put("underline", underline)
        put("align", align); put("lineSpacing", lineSpacing.toDouble()); put("opacity", opacity.toDouble())
        put("strokeColor", strokeColor ?: JSONObject.NULL)
        put("strokeWidth", strokeWidth.toDouble()); put("cornerRadius", cornerRadius.toDouble())
        put("locked", locked); put("hidden", hidden)
    }

    fun copyNew(): NoteElement = copy(id = UUID.randomUUID().toString())

    companion object {
        fun fromJson(o: JSONObject): NoteElement = NoteElement(
            id = o.optString("id", UUID.randomUUID().toString()),
            type = o.optString("type", "text"),
            content = o.optString("content", ""),
            x = o.optDouble("x", 0.0).toFloat(), y = o.optDouble("y", 0.0).toFloat(),
            width = o.optDouble("width", 400.0).toFloat(), height = o.optDouble("height", 120.0).toFloat(),
            rotation = o.optDouble("rotation", 0.0).toFloat(), scale = o.optDouble("scale", 1.0).toFloat(),
            zIndex = o.optInt("zIndex", 0),
            fontFamily = if (o.isNull("fontFamily")) null else o.optString("fontFamily"),
            fontSize = o.optDouble("fontSize", 64.0).toFloat(),
            color = if (o.isNull("color")) null else o.optString("color"),
            bold = o.optBoolean("bold"), italic = o.optBoolean("italic"), underline = o.optBoolean("underline"),
            align = o.optInt("align", 0), lineSpacing = o.optDouble("lineSpacing", 1.0).toFloat(),
            opacity = o.optDouble("opacity", 1.0).toFloat(),
            strokeColor = if (o.isNull("strokeColor")) null else o.optString("strokeColor"),
            strokeWidth = o.optDouble("strokeWidth", 0.0).toFloat(),
            cornerRadius = o.optDouble("cornerRadius", 0.0).toFloat(),
            locked = o.optBoolean("locked"), hidden = o.optBoolean("hidden")
        )

        /** JSON corrupt -> list kosong (tidak crash). */
        fun parse(s: String?): MutableList<NoteElement> {
            val out = mutableListOf<NoteElement>()
            try {
                val a = JSONArray(s ?: "[]")
                for (i in 0 until a.length()) {
                    try { out.add(fromJson(a.getJSONObject(i))) } catch (e: Exception) { /* skip elemen rusak */ }
                }
            } catch (e: Exception) { /* fallback kosong */ }
            return out
        }

        fun toJsonArray(list: List<NoteElement>): JSONArray {
            val a = JSONArray(); list.forEach { a.put(it.toJson()) }; return a
        }
    }
}

/** Pengaturan canvas per catatan. */
data class CanvasMeta(
    var bgType: String = "solid",           // solid | gradient | image
    var bgColor: String = "#FF1E1E1E",
    var gradStart: String = "#FF7F5AF0",
    var gradEnd: String = "#FF2CB67D",
    var gradAngle: Float = 45f,
    var bgImage: String? = null,
    var imgScale: Float = 1f,
    var imgRotation: Float = 0f,
    var imgOffX: Float = 0f,
    var imgOffY: Float = 0f,
    var imgOpacity: Float = 1f,
    var imgBlur: Float = 0f,
    var grid: Boolean = false,              // default OFF
    var snap: Boolean = false,              // default OFF
    var gridSize: Float = 40f,
    var width: Float = 1080f,
    var height: Float = 1920f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("bgType", bgType); put("bgColor", bgColor)
        put("gradStart", gradStart); put("gradEnd", gradEnd); put("gradAngle", gradAngle.toDouble())
        put("bgImage", bgImage ?: JSONObject.NULL)
        put("imgScale", imgScale.toDouble()); put("imgRotation", imgRotation.toDouble())
        put("imgOffX", imgOffX.toDouble()); put("imgOffY", imgOffY.toDouble())
        put("imgOpacity", imgOpacity.toDouble()); put("imgBlur", imgBlur.toDouble())
        put("grid", grid); put("snap", snap); put("gridSize", gridSize.toDouble())
        put("width", width.toDouble()); put("height", height.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject): CanvasMeta = CanvasMeta(
            bgType = o.optString("bgType", "solid"),
            bgColor = o.optString("bgColor", "#FF1E1E1E"),
            gradStart = o.optString("gradStart", "#FF7F5AF0"),
            gradEnd = o.optString("gradEnd", "#FF2CB67D"),
            gradAngle = o.optDouble("gradAngle", 45.0).toFloat(),
            bgImage = if (o.isNull("bgImage")) null else o.optString("bgImage"),
            imgScale = o.optDouble("imgScale", 1.0).toFloat(),
            imgRotation = o.optDouble("imgRotation", 0.0).toFloat(),
            imgOffX = o.optDouble("imgOffX", 0.0).toFloat(),
            imgOffY = o.optDouble("imgOffY", 0.0).toFloat(),
            imgOpacity = o.optDouble("imgOpacity", 1.0).toFloat(),
            imgBlur = o.optDouble("imgBlur", 0.0).toFloat(),
            grid = o.optBoolean("grid"), snap = o.optBoolean("snap"),
            gridSize = o.optDouble("gridSize", 40.0).toFloat(),
            width = o.optDouble("width", 1080.0).toFloat(),
            height = o.optDouble("height", 1920.0).toFloat()
        )

        fun parse(s: String?, w: Float, h: Float): CanvasMeta = try {
            fromJson(JSONObject(s ?: "{}"))
        } catch (e: Exception) {
            CanvasMeta(width = w, height = h)
        }
    }
}
