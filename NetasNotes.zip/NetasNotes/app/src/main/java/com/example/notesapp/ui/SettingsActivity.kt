package com.example.notesapp.ui

import android.app.Dialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Color
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.notesapp.MainActivity
import com.example.notesapp.R
import com.example.notesapp.util.*
import java.io.File

class SettingsActivity : AppCompatActivity() {
    private val pickers = Pickers(this)
    private val t get() = ThemeManager.current
    private var themeVer = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        themeVer = ThemeManager.version
        ThemeManager.apply(this)
        val col = vbox().apply { setPadding(dp(8), dp(8), dp(8), dp(32)) }

        val header = hbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        header.addView(iv(R.drawable.ic_arrow_back, t.text).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10)); layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
            background = ripple(rr(Color.TRANSPARENT, 22f), t.text); setOnClickListener { finish() }
        })
        header.addView(tv("Pengaturan", 24f, t.text, true), header.lin(WRAP, WRAP, l = 8))
        col.addView(header)

        section(col, "Tampilan")
        card(col, R.drawable.ic_palette, "Tema", "Preset atau bikin tema sendiri dari nol") { themeDialog() }
        card(col, R.drawable.ic_text, "Font default", "Font untuk teks baru (bisa upload .ttf / .otf)") { defaultFont() }
        card(col, R.drawable.ic_image, "Background default", "Gambar latar untuk catatan baru") { defaultBg() }

        section(col, "Keamanan")
        card(col, R.drawable.ic_lock, "Ganti PIN", "PIN disimpan terenkripsi di perangkat") { PinManager.changePin(this) }
        card(col, R.drawable.ic_shapes, "Pilih ikon", "6 preset atau upload gambar sendiri") { iconDialog() }

        section(col, "Data")
        card(col, R.drawable.ic_download, "Ekspor JSON", "Simpan semua catatan ke file") {
            startActivity(Intent(this, JsonTransferActivity::class.java).putExtra("mode", "export"))
        }
        card(col, R.drawable.ic_upload, "Impor JSON", "Muat catatan dari file ekspor") {
            startActivity(Intent(this, JsonTransferActivity::class.java).putExtra("mode", "import"))
        }

        section(col, "Tentang")
        card(col, R.drawable.ic_info, "Versi", "Neta's Notes 1.0.0") { }
        card(col, R.drawable.ic_person, "Developer", "Dibuat untuk Neta") { toast("Terima kasih sudah pakai Neta's Notes!") }

        setContentView(ScrollView(this).apply { addView(col); isVerticalScrollBarEnabled = false })
    }

    override fun onResume() { super.onResume(); if (themeVer != ThemeManager.version) recreate() }

    private fun section(p: LinearLayout, label: String) {
        p.addView(tv(label.uppercase(), 11f, t.textSecondary, true).apply { letterSpacing = .1f }, p.lin(l = 16, t = 20, b = 6))
    }

    private fun card(p: LinearLayout, icon: Int, title: String, desc: String, onClick: () -> Unit) {
        val c = hbox().apply {
            background = ripple(rr(t.surface, 16f), t.text); elevation = dp(4).toFloat(); setPadding(dp(16), dp(16), dp(16), dp(16))
            setOnClickListener { onClick() }
        }
        c.addView(iv(icon, t.primary, 24))
        val txt = vbox()
        txt.addView(tv(title, 16f, t.text, true))
        txt.addView(tv(desc, 12f, t.textSecondary), txt.lin(t = 2))
        c.addView(txt, c.lin(0, WRAP, 1f, l = 16, r = 8))
        c.addView(iv(R.drawable.ic_chevron, t.textSecondary, 20))
        p.addView(c, p.lin(l = 8, t = 4, r = 8, b = 4))
    }

    // ---------- tema ----------
    private fun themeDialog() {
        val box = vbox()
        box.addView(tv("Tema", 20f, t.text, true))
        lateinit var d: Dialog
        ThemeManager.presets.forEach { p ->
            val row = hbox().apply {
                setPadding(dp(8), dp(10), dp(8), dp(10))
                background = if (p.name == t.name) rr(withAlpha(t.primary, .18f), 12f) else null
                listOf(p.bg, p.surface, p.primary, p.secondary).forEach { c ->
                    addView(View(this@SettingsActivity).apply { background = rr(c, 12f, t.textSecondary, 1f) },
                        LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(6) })
                }
                addView(tv(p.name, 16f, t.text), lin(WRAP, WRAP, l = 8))
                setOnClickListener { d.dismiss(); ThemeManager.set(this@SettingsActivity, p); recreate() }
            }
            box.addView(row, box.lin(t = 2))
        }
        box.addView(button("Buat tema sendiri") { d.dismiss(); customTheme() }, box.lin(MATCH, dp(46), t = 14))
        d = sheetDialog(box)
    }

    private fun customTheme() {
        val cur = t
        val names = listOf("Primary", "Secondary", "Background", "Surface", "Teks", "Teks sekunder", "Accent")
        val colors = intArrayOf(cur.primary, cur.secondary, cur.bg, cur.surface, cur.text, cur.textSecondary, cur.accent)
        val box = vbox()
        box.addView(tv("Tema sendiri", 20f, t.text, true))
        box.addView(tv("Tap warna untuk mengubah. Semua warna bebas.", 12f, t.textSecondary), box.lin(t = 4, b = 8))
        names.forEachIndexed { i, n ->
            val sw = View(this).apply { background = rr(colors[i], 12f, t.textSecondary, 1f) }
            val row = hbox().apply {
                setPadding(dp(8), dp(10), dp(8), dp(10)); background = ripple(null, t.text)
                addView(tv(n, 16f, t.text), LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(sw, LinearLayout.LayoutParams(dp(36), dp(36)))
                setOnClickListener { ColorPicker.show(this@SettingsActivity, colors[i]) { c -> colors[i] = c; sw.background = rr(c, 12f, t.textSecondary, 1f) } }
            }
            box.addView(row)
        }
        lateinit var d: Dialog
        box.addView(button("Simpan & terapkan") {
            d.dismiss()
            val theme = AppTheme("Custom", colors[2], colors[3], colors[0], colors[1], colors[4], colors[5], colors[6], luminance(colors[2]) < 0.5)
            ThemeManager.set(this, theme); recreate()
        }, box.lin(MATCH, dp(46), t = 14))
        d = sheetDialog(box)
    }

    // ---------- default font / background ----------
    private fun defaultFont() {
        FontManager.showPicker(this, Prefs.get("defaultFont"), { done ->
            pickers.font { uri ->
                if (uri != null && FontManager.import(this, uri) == null) toast("Font gagal dimuat (pakai .ttf / .otf)")
                done()
            }
        }) { f -> Prefs.put(this, "defaultFont", f); toast("Font default diatur") }
    }

    private fun defaultBg() {
        actionList("Background default", listOf(
            Act("Pilih gambar dari galeri") {
                pickers.image { uri ->
                    val p = uri?.let { ImageHelper.importImage(this, it, "backgrounds") }
                    if (p != null) { Prefs.put(this, "defaultBg", p); toast("Background default diatur") } else if (uri != null) toast("Gambar gagal dimuat")
                }
            },
            Act("Hapus background default", true) { Prefs.put(this, "defaultBg", null); toast("Dihapus") }
        ))
    }

    // ---------- ikon aplikasi ----------
    private fun iconDialog() {
        val box = vbox()
        box.addView(tv("Ikon aplikasi", 20f, t.text, true))
        lateinit var d: Dialog
        val res = listOf(R.mipmap.ic_icon_1, R.mipmap.ic_icon_2, R.mipmap.ic_icon_3, R.mipmap.ic_icon_4, R.mipmap.ic_icon_5, R.mipmap.ic_icon_6)
        val grid = hbox().apply { setPadding(0, dp(12), 0, dp(4)) }
        val grid2 = hbox()
        res.forEachIndexed { i, r ->
            val img = ImageView(this).apply { setImageResource(r); setOnClickListener { d.dismiss(); setAlias(i + 1) } }
            (if (i < 3) grid else grid2).addView(img, LinearLayout.LayoutParams(dp(64), dp(64)).apply { marginEnd = dp(16); bottomMargin = dp(8) })
        }
        box.addView(grid); box.addView(grid2)
        box.addView(button("Upload gambar sendiri", filled = false) { d.dismiss(); customIcon() }, box.lin(MATCH, dp(46), t = 12))
        box.addView(tv("Catatan: Android hanya mengizinkan ikon launcher utama berganti ke ikon yang sudah dibundel di dalam APK. " +
            "Karena itu gambar upload dibuat menjadi shortcut ikon custom di home screen (Android 8+).", 11f, t.textSecondary), box.lin(t = 10))
        d = sheetDialog(box)
    }

    private fun setAlias(n: Int) {
        try {
            for (i in 1..6) packageManager.setComponentEnabledSetting(
                ComponentName(packageName, "$packageName.Alias$i"),
                if (i == n) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP)
            Prefs.put(this, "icon", n.toString())
            toast("Ikon diganti. Launcher mungkin butuh beberapa detik.")
        } catch (e: Exception) { CrashHandler.log(this, "alias", e); toast("Gagal mengganti ikon") }
    }

    private fun customIcon() {
        if (Build.VERSION.SDK_INT < 26) { toast("Ikon custom butuh Android 8+"); return }
        pickers.image { uri ->
            val path = uri?.let { ImageHelper.importImage(this, it, "icons") }
            val bmp = ImageHelper.decode(path, 512)
            if (bmp == null) { if (uri != null) toast("Gambar gagal dimuat"); return@image }
            try {
                val sm = getSystemService(ShortcutManager::class.java)
                if (!sm.isRequestPinShortcutSupported) { toast("Launcher tidak mendukung pin shortcut"); return@image }
                val s = ShortcutInfo.Builder(this, "custom_icon_${System.currentTimeMillis()}")
                    .setShortLabel("Neta's Notes")
                    .setIcon(Icon.createWithBitmap(ImageHelper.makeIcon(bmp)))
                    .setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
                    .build()
                sm.requestPinShortcut(s, null)
            } catch (e: Exception) { CrashHandler.log(this, "shortcut", e); toast("Gagal membuat shortcut") }
        }
    }
}
