package com.example.notesapp.util

import android.app.Activity
import android.content.Context
import android.graphics.Color
import androidx.core.view.WindowCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import org.json.JSONObject

val Context.appDataStore by preferencesDataStore(name = "settings")

/** Wrapper DataStore dengan cache memori supaya bisa dibaca sinkron di UI. */
object Prefs {
    private val cache = HashMap<String, String>()
    private var ready = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(c: Context) {
        if (ready) return
        try {
            val p = runBlocking { c.applicationContext.appDataStore.data.first() }
            p.asMap().forEach { (k, v) -> cache[k.name] = v.toString() }
        } catch (e: Exception) { CrashHandler.log(c, "prefs init", e) }
        ready = true
    }

    fun get(k: String): String? = cache[k]

    fun put(c: Context, k: String, v: String?) {
        val app = c.applicationContext
        if (v == null) cache.remove(k) else cache[k] = v
        scope.launch {
            try {
                app.appDataStore.edit { p ->
                    val key = stringPreferencesKey(k)
                    if (v == null) p.remove(key) else p[key] = v
                }
            } catch (e: Exception) { CrashHandler.log(app, "prefs put", e) }
        }
    }
}

data class AppTheme(
    val name: String, val bg: Int, val surface: Int, val primary: Int, val secondary: Int,
    val text: Int, val textSecondary: Int, val accent: Int, val dark: Boolean
) {
    fun toJson(): JSONObject = JSONObject().put("name", name).put("bg", bg).put("surface", surface)
        .put("primary", primary).put("secondary", secondary).put("text", text)
        .put("textSecondary", textSecondary).put("accent", accent).put("dark", dark)

    companion object {
        fun fromJson(s: String): AppTheme {
            val o = JSONObject(s)
            return AppTheme(o.getString("name"), o.getInt("bg"), o.getInt("surface"), o.getInt("primary"),
                o.getInt("secondary"), o.getInt("text"), o.getInt("textSecondary"), o.getInt("accent"), o.getBoolean("dark"))
        }
    }
}

object ThemeManager {
    private fun c(s: String) = Color.parseColor(s)

    val LIGHT = AppTheme("Light", c("#FAFAFA"), c("#FFFFFF"), c("#6200EE"), c("#018786"), c("#000000"), c("#606060"), c("#6200EE"), false)
    val DARK = AppTheme("Dark", c("#121212"), c("#1E1E1E"), c("#BB86FC"), c("#03DAC6"), c("#FFFFFF"), c("#B0B0B0"), c("#BB86FC"), true)
    val OCEAN = AppTheme("Ocean", c("#0B1D2E"), c("#12304A"), c("#4FC3F7"), c("#26C6DA"), c("#E8F4FD"), c("#8FB3CC"), c("#4FC3F7"), true)
    val FOREST = AppTheme("Forest", c("#0F1F14"), c("#1A3322"), c("#81C784"), c("#AED581"), c("#E8F5E9"), c("#9DBBA3"), c("#81C784"), true)
    val SUNSET = AppTheme("Sunset", c("#2A1420"), c("#3D1E2E"), c("#FF8A65"), c("#FFD54F"), c("#FFF3E9"), c("#D1A89B"), c("#FF8A65"), true)
    val NEON = AppTheme("Neon", c("#0A0A12"), c("#151525"), c("#FF2EC4"), c("#00F0FF"), c("#FFFFFF"), c("#9AA0C0"), c("#00F0FF"), true)
    val MINIMAL = AppTheme("Minimal", c("#FFFFFF"), c("#F2F2F2"), c("#111111"), c("#555555"), c("#111111"), c("#777777"), c("#111111"), false)
    val presets = listOf(LIGHT, DARK, OCEAN, FOREST, SUNSET, NEON, MINIMAL)

    var current: AppTheme = DARK
    var version = 0

    fun load(ctx: Context) {
        Prefs.init(ctx)
        try {
            Prefs.get("theme")?.let { current = AppTheme.fromJson(it) }
        } catch (e: Exception) {
            current = LIGHT   // theme gagal apply -> fallback Light
            CrashHandler.log(ctx, "theme load", e)
        }
    }

    fun set(ctx: Context, t: AppTheme) {
        current = t; version++
        Prefs.put(ctx, "theme", t.toJson().toString())
    }

    /** Warnai window + status bar sesuai tema aktif. */
    fun apply(a: Activity) {
        try {
            val t = current
            a.window.decorView.setBackgroundColor(t.bg)
            a.window.statusBarColor = t.bg
            a.window.navigationBarColor = t.bg
            val ctl = WindowCompat.getInsetsController(a.window, a.window.decorView)
            ctl.isAppearanceLightStatusBars = !t.dark
            ctl.isAppearanceLightNavigationBars = !t.dark
        } catch (e: Exception) {
            current = LIGHT
        }
    }
}
