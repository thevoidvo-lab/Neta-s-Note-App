package com.example.notesapp.util

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

object FontManager {
    val system = listOf("sans-serif", "sans-serif-medium", "sans-serif-light", "serif", "monospace", "cursive", "casual")
    private val cache = HashMap<String, Typeface>()

    fun dir(c: Context): File = File(c.filesDir, "fonts").apply { mkdirs() }
    fun list(c: Context): List<String> = dir(c).listFiles()?.map { it.name }?.sorted() ?: emptyList()

    /** Copy .ttf/.otf ke filesDir/fonts. Return nama file atau null kalau gagal. */
    fun import(c: Context, uri: Uri): String? {
        return try {
            var name = "font_${System.currentTimeMillis()}.ttf"
            c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cur.moveToFirst() && i >= 0) name = cur.getString(i)
            }
            val ext = name.substringAfterLast('.', "").lowercase()
            if (ext != "ttf" && ext != "otf") return null
            val out = File(dir(c), name)
            c.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            try { Typeface.createFromFile(out) } catch (e: Throwable) { out.delete(); return null }
            name
        } catch (e: Throwable) { CrashHandler.log(c, "import font", e); null }
    }

    /** Font gagal load -> fallback ke default. */
    fun load(c: Context, family: String?, bold: Boolean, italic: Boolean): Typeface {
        val style = when { bold && italic -> Typeface.BOLD_ITALIC; bold -> Typeface.BOLD; italic -> Typeface.ITALIC; else -> Typeface.NORMAL }
        return try {
            if (family == null) return Typeface.create(Typeface.DEFAULT, style)
            val base = cache.getOrPut(family) {
                val f = File(dir(c), family)
                if (f.exists()) Typeface.createFromFile(f) else Typeface.create(family, Typeface.NORMAL)
            }
            Typeface.create(base, style)
        } catch (e: Throwable) { Typeface.create(Typeface.DEFAULT, style) }
    }

    fun showPicker(a: Activity, current: String?, requestUpload: (done: () -> Unit) -> Unit, onPick: (String?) -> Unit) {
        val t = ThemeManager.current
        val box = a.vbox()
        box.addView(a.tv("Pilih font", 20f, t.text, true))
        lateinit var dlg: Dialog
        fun row(label: String, family: String?) {
            val v = a.tv("$label  —  Aa 123 Catatan", 16f, t.text)
            v.typeface = load(a, family, false, false)
            v.pad(12, 12)
            if (family == current) v.background = a.rr(withAlpha(t.primary, .18f), 12f)
            v.setOnClickListener { dlg.dismiss(); onPick(family) }
            box.addView(v)
        }
        row("Default", null)
        system.forEach { row(it, it) }
        list(a).forEach { row(it.substringBeforeLast('.'), it) }
        val up = a.button("+ Upload Font") { dlg.dismiss(); requestUpload { showPicker(a, current, requestUpload, onPick) } }
        box.addView(up, box.lin(MATCH, a.dp(46), t = 12))
        dlg = a.sheetDialog(box)
    }
}
