package com.example.notesapp.ui

/** Undo/redo berbasis snapshot JSON, maksimal 100 langkah. */
class UndoRedoManager(private val max: Int = 100) {
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()
    private var current = ""

    val canUndo get() = undoStack.isNotEmpty()
    val canRedo get() = redoStack.isNotEmpty()

    fun reset(initial: String) { undoStack.clear(); redoStack.clear(); current = initial }

    fun commit(state: String) {
        if (state == current) return
        undoStack.addLast(current)
        if (undoStack.size > max) undoStack.removeFirst()
        redoStack.clear()
        current = state
    }

    fun undo(): String? {
        if (undoStack.isEmpty()) return null
        redoStack.addLast(current)
        current = undoStack.removeLast()
        return current
    }

    fun redo(): String? {
        if (redoStack.isEmpty()) return null
        undoStack.addLast(current)
        current = redoStack.removeLast()
        return current
    }
}
