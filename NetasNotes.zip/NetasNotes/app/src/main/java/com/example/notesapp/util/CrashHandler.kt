package com.example.notesapp.util

import android.app.Application
import android.content.Context
import android.util.Log
import android.widget.Toast
import java.io.File
import java.util.Date

object CrashHandler {
    fun install(app: Application) {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { log(app, "CRASH", e) } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }

    fun log(c: Context, msg: String, e: Throwable?) {
        Log.e("NetasNotes", msg, e)
        try {
            File(c.filesDir, "crash.log").appendText("${Date()} $msg ${e?.stackTraceToString() ?: ""}\n")
        } catch (x: Throwable) { }
    }
}

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
