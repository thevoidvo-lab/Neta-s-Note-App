package com.example.notesapp.ui

import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.notesapp.R
import com.example.notesapp.data.Note
import com.example.notesapp.util.*
import com.google.android.material.snackbar.Snackbar

class NoteListActivity : AppCompatActivity() {
    private val vm: NotesViewModel by viewModels()
    private lateinit var adapter: NoteAdapter
    private lateinit var rv: RecyclerView
    private lateinit var empty: View
    private lateinit var chips: LinearLayout
    private lateinit var searchEt: EditText
    private lateinit var titleTv: TextView
    private lateinit var root: FrameLayout
    private lateinit var navItems: List<LinearLayout>
    private var themeVer = 0
    private val t get() = ThemeManager.current

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        themeVer = ThemeManager.version
        ThemeManager.apply(this)
        buildUi()
        vm.visible.observe(this) { list ->
            adapter.submitList(list)
            empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
        vm.all.observe(this) { renderChips() }
        vm.filter.observe(this) { renderChips() }
        vm.category.observe(this) { renderChips() }
    }

    override fun onResume() {
        super.onResume()
        if (themeVer != ThemeManager.version) { recreate(); return }
        titleTv.text = headerTitle()
        selectNav(0)
    }

    private fun headerTitle() = "${Prefs.get("profileName") ?: "Neta"}'s Notes"

    private fun headerIcon(res: Int, onClick: () -> Unit) = iv(res, t.text).apply {
        setPadding(dp(10), dp(10), dp(10), dp(10))
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        background = ripple(rr(Color.TRANSPARENT, 22f), t.text)
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        root = FrameLayout(this)
        val col = vbox()

        val header = hbox().apply { setPadding(dp(20), dp(14), dp(10), dp(6)) }
        titleTv = tv(headerTitle(), 24f, t.text, true)
        header.addView(titleTv, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(headerIcon(R.drawable.ic_search) { focusSearch() })
        header.addView(headerIcon(R.drawable.ic_more) { showMenu() })
        col.addView(header)

        val sb = hbox().apply { background = rr(t.surface, 24f); setPadding(dp(16), 0, dp(16), 0) }
        sb.addView(iv(R.drawable.ic_search, t.textSecondary, 20))
        searchEt = EditText(this).apply {
            hint = "Cari catatan..."; setHintTextColor(t.textSecondary); setTextColor(t.text); textSize = 15f
            background = null; maxLines = 1; inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { vm.query.value = s?.toString() ?: "" }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        sb.addView(searchEt, sb.lin(0, MATCH, 1f, l = 12))
        col.addView(sb, col.lin(MATCH, dp(48), l = 16, r = 16, t = 4))

        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        chips = hbox().apply { setPadding(dp(16), dp(12), dp(16), dp(8)) }
        hs.addView(chips)
        col.addView(hs)

        adapter = NoteAdapter(onClick = { open(it) }, onLong = { noteMenu(it) })
        rv = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@NoteListActivity)
            adapter = this@NoteListActivity.adapter
            clipToPadding = false; setPadding(0, dp(4), 0, dp(130))
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        attachSwipe()
        col.addView(rv, col.lin(MATCH, 0, 1f))
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        // empty state
        empty = vbox().apply {
            gravity = Gravity.CENTER; visibility = View.GONE
            val ic = iv(R.drawable.ic_notes, t.primary, 96); ic.alpha = .45f
            addView(ic)
            addView(tv("Belum ada catatan.\nTap + buat mulai", 15f, t.textSecondary).apply { gravity = Gravity.CENTER }, lin(WRAP, WRAP, t = 16))
        }
        root.addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        // FAB 56dp, elevation 8dp
        val fab = ImageView(this).apply {
            setImageResource(R.drawable.ic_add); setColorFilter(contrastOf(t.primary)); scaleType = ImageView.ScaleType.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(t.primary) }
            elevation = dp(8).toFloat()
            setOnClickListener { startActivity(Intent(this@NoteListActivity, NoteEditActivity::class.java)) }
        }
        root.addView(fab, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(20), dp(104)) })

        // floating pill nav
        val pill = hbox().apply {
            background = rr(blend(t.surface, t.text, .06f), 32f); elevation = dp(12).toFloat(); setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val items = listOf(Triple(R.drawable.ic_notes, "Notes", 0), Triple(R.drawable.ic_search, "Search", 1),
            Triple(R.drawable.ic_settings, "Settings", 2), Triple(R.drawable.ic_person, "Profile", 3))
        navItems = items.map { (icon, label, idx) ->
            vbox().apply {
                gravity = Gravity.CENTER; setPadding(dp(14), dp(8), dp(14), dp(6))
                addView(iv(icon, t.textSecondary, 24)); addView(tv(label, 11f, t.textSecondary, true))
                setOnClickListener { onNav(idx) }
                pill.addView(this, LinearLayout.LayoutParams(dp(78), WRAP).apply { marginStart = dp(2); marginEnd = dp(2) })
            }
        }
        root.addView(pill, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(16) })
        setContentView(root)
        selectNav(0)
    }

    private fun blend(a: Int, b: Int, f: Float): Int {
        fun m(x: Int, y: Int) = (x + (y - x) * f).toInt()
        return Color.rgb(m(Color.red(a), Color.red(b)), m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b)))
    }

    private fun selectNav(sel: Int) {
        navItems.forEachIndexed { i, v ->
            val on = i == sel
            v.background = if (on) rr(withAlpha(t.primary, .2f), 24f) else null
            val c = if (on) t.primary else t.textSecondary
            ((v.getChildAt(0)) as ImageView).setColorFilter(c)
            ((v.getChildAt(1)) as TextView).setTextColor(c)
        }
    }

    private fun onNav(i: Int) {
        when (i) {
            0 -> { vm.filter.value = 0; vm.category.value = null; searchEt.setText(""); rv.smoothScrollToPosition(0); selectNav(0) }
            1 -> { selectNav(1); focusSearch() }
            2 -> startActivity(Intent(this, SettingsActivity::class.java))
            3 -> profileDialog()
        }
    }

    private fun focusSearch() {
        searchEt.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchEt, 0)
    }

    private fun renderChips() {
        chips.removeAllViews()
        val all = vm.all.value ?: emptyList()
        val f = vm.filter.value ?: 0
        val defs = listOf(
            Triple("Semua", all.size, 0), Triple("Pinned", all.count { it.isPinned }, 1),
            Triple("Locked", all.count { it.isLocked }, 2),
            Triple(vm.category.value ?: "Kategori", all.mapNotNull { it.category }.distinct().size, 3)
        )
        defs.forEach { (label, count, idx) ->
            val on = f == idx
            val c = hbox().apply {
                setPadding(dp(14), dp(8), dp(10), dp(8))
                background = ripple(rr(if (on) withAlpha(t.primary, .2f) else withAlpha(t.text, .06f), 20f), t.text)
                addView(tv(label, 14f, if (on) t.primary else t.textSecondary, true))
                if (count > 0) addView(tv(count.toString(), 11f, contrastOf(if (on) t.primary else t.textSecondary), true).apply {
                    gravity = Gravity.CENTER; setPadding(dp(6), dp(1), dp(6), dp(1))
                    background = rr(if (on) t.primary else withAlpha(t.textSecondary, .6f), 10f)
                }, lin(WRAP, WRAP, l = 8))
                else setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { if (idx == 3) pickCategory() else { vm.filter.value = idx; vm.category.value = null } }
            }
            chips.addView(c, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) })
        }
    }

    private fun pickCategory() {
        val cats = (vm.all.value ?: emptyList()).mapNotNull { it.category }.distinct().sorted()
        if (cats.isEmpty()) { toast("Belum ada kategori. Long press catatan > Atur kategori"); return }
        val items = cats.map { c -> Act(c) { vm.category.value = c; vm.filter.value = 3 } } +
            Act("Semua kategori") { vm.category.value = null; vm.filter.value = 3 }
        actionList("Kategori", items)
    }

    private fun open(n: Note) {
        val go = { startActivity(Intent(this, NoteEditActivity::class.java).putExtra("id", n.id)) }
        if (n.isLocked) PinManager.requirePin(this) { go() } else go()
    }

    private fun noteMenu(n: Note) {
        actionList(n.title.ifBlank { "Catatan" }, listOf(
            Act(if (n.isPinned) "Lepas pin" else "Pin") { vm.togglePin(n) },
            Act(if (n.isLocked) "Buka kunci" else "Kunci") { PinManager.requirePin(this) { vm.toggleLock(n) } },
            Act("Duplikat") { vm.duplicate(n) },
            Act("Atur kategori") { categoryInput(n) },
            Act("Hapus", true) { deleteWithUndo(n) }
        ))
    }

    private fun categoryInput(n: Note) {
        val box = vbox()
        box.addView(tv("Kategori", 20f, t.text, true))
        val et = EditText(this).apply {
            setText(n.category ?: ""); hint = "Contoh: Kerja"; setHintTextColor(t.textSecondary); setTextColor(t.text)
            background = rr(withAlpha(t.text, .07f), 14f); pad(16, 12); maxLines = 1
        }
        box.addView(et, box.lin(t = 12))
        lateinit var d: android.app.Dialog
        box.addView(button("Simpan") { vm.setCategory(n, et.text.toString().trim()); d.dismiss() }, box.lin(MATCH, dp(46), t = 12))
        d = sheetDialog(box)
    }

    private fun deleteWithUndo(n: Note) {
        vm.delete(n)
        Snackbar.make(root, "Catatan dihapus", Snackbar.LENGTH_LONG).setAction("Urungkan") { vm.restore(n) }
            .setBackgroundTint(t.surface).setTextColor(t.text).setActionTextColor(t.primary)
            .setAnchorView(root.getChildAt(root.childCount - 1)).show()
    }

    private fun showMenu() {
        actionList(null, listOf(
            Act("Pengaturan") { startActivity(Intent(this, SettingsActivity::class.java)) },
            Act("Ekspor JSON") { startActivity(Intent(this, JsonTransferActivity::class.java).putExtra("mode", "export")) },
            Act("Impor JSON") { startActivity(Intent(this, JsonTransferActivity::class.java).putExtra("mode", "import")) }
        ))
    }

    private fun profileDialog() {
        val all = vm.all.value ?: emptyList()
        val box = vbox()
        box.addView(tv("Profil", 20f, t.text, true))
        box.addView(tv("${all.size} catatan • ${all.count { it.isPinned }} pinned • ${all.count { it.isLocked }} terkunci", 13f, t.textSecondary), box.lin(t = 6))
        val et = EditText(this).apply {
            setText(Prefs.get("profileName") ?: "Neta"); setTextColor(t.text); hint = "Nama"; setHintTextColor(t.textSecondary)
            background = rr(withAlpha(t.text, .07f), 14f); pad(16, 12); maxLines = 1
        }
        box.addView(et, box.lin(t = 14))
        lateinit var d: android.app.Dialog
        box.addView(button("Simpan") {
            Prefs.put(this, "profileName", et.text.toString().trim().ifBlank { "Neta" })
            titleTv.text = headerTitle(); d.dismiss()
        }, box.lin(MATCH, dp(46), t = 12))
        d = sheetDialog(box)
    }

    // ---------- swipe: kiri = hapus, kanan = pin ----------
    private fun attachSwipe() {
        val cb = object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(r: RecyclerView, v: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder) = false
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {
                val pos = vh.bindingAdapterPosition
                val n = adapter.currentList.getOrNull(pos) ?: return
                if (dir == ItemTouchHelper.LEFT) deleteWithUndo(n)
                else { vm.togglePin(n); adapter.notifyItemChanged(pos) }
            }
            override fun onChildDraw(c: Canvas, r: RecyclerView, vh: RecyclerView.ViewHolder, dX: Float, dY: Float, state: Int, active: Boolean) {
                val v = vh.itemView
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                if (dX > 0) {
                    p.color = withAlpha(this@NoteListActivity.t.primary, .85f)
                    c.drawRect(v.left.toFloat(), v.top.toFloat(), v.left + dX, v.bottom.toFloat(), p)
                    drawIcon(c, R.drawable.ic_pin, v.left + dp(32), (v.top + v.bottom) / 2, contrastOf(this@NoteListActivity.t.primary))
                } else if (dX < 0) {
                    p.color = 0xFFE57373.toInt()
                    c.drawRect(v.right + dX, v.top.toFloat(), v.right.toFloat(), v.bottom.toFloat(), p)
                    drawIcon(c, R.drawable.ic_delete, v.right - dp(32), (v.top + v.bottom) / 2, Color.WHITE)
                }
                super.onChildDraw(c, r, vh, dX, dY, state, active)
            }
        }
        ItemTouchHelper(cb).attachToRecyclerView(rv)
    }

    private fun drawIcon(c: Canvas, res: Int, cx: Int, cy: Int, color: Int) {
        val d = ContextCompat.getDrawable(this, res)?.mutate() ?: return
        d.setTint(color)
        val h = dp(12)
        d.setBounds(cx - h, cy - h, cx + h, cy + h)
        d.draw(c)
    }
}
