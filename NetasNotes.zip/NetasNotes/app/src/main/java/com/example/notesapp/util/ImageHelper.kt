package com.example.notesapp.util

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.webkit.MimeTypeMap
import java.io.File
import kotlin.math.max

object ImageHelper {
    fun dir(c: Context, sub: String): File = File(c.filesDir, sub).apply { mkdirs() }

    /** Copy gambar dari galeri ke filesDir/<sub>/. Return path absolut, null kalau gagal. */
    fun importImage(c: Context, uri: Uri, sub: String): String? = try {
        val mime = c.contentResolver.getType(uri)
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "png"
        val out = File(dir(c, sub), "${System.currentTimeMillis()}.$ext")
        c.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        if (decode(out.absolutePath, 64) == null) { out.delete(); null } else out.absolutePath
    } catch (e: Throwable) { CrashHandler.log(c, "import image", e); null }

    fun decode(path: String?, maxDim: Int = 2048): Bitmap? {
        if (path == null) return null
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            if (o.outWidth <= 0) return null
            var s = 1
            while (o.outWidth / s > maxDim || o.outHeight / s > maxDim) s *= 2
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
        } catch (e: Throwable) { null }
    }

    /** Blur ringan: kecilkan lalu besarkan lagi (cepat, aman di semua API). */
    fun blur(src: Bitmap, radius: Float): Bitmap {
        if (radius <= 0.5f) return src
        val f = 1f / (1f + radius)
        val w = max(2, (src.width * f).toInt()); val h = max(2, (src.height * f).toInt())
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        return Bitmap.createScaledBitmap(small, src.width, src.height, true)
    }

    /** Bikin ikon persegi 192px dengan sudut membulat dari gambar bebas. */
    fun makeIcon(src: Bitmap): Bitmap {
        val size = 192
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), 44f, 44f, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        val s = minOf(src.width, src.height)
        val r = Rect((src.width - s) / 2, (src.height - s) / 2, (src.width + s) / 2, (src.height + s) / 2)
        c.drawBitmap(src, r, Rect(0, 0, size, size), p)
        return out
    }
}
