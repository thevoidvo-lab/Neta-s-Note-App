package com.example.notesapp.ui

import android.content.Context
import android.graphics.*
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import com.example.notesapp.data.CanvasMeta
import com.example.notesapp.data.NoteElement
import com.example.notesapp.util.*
import kotlin.math.*

/**
 * Canvas bebas. Gesture:
 *  - 1 jari di elemen: pilih + geser | 2 jari di elemen: pinch scale + rotate
 *  - 2 jari di area kosong: pan + zoom canvas | tap 2x teks: edit | long press: menu
 *  - handle bulat di pojok kanan bawah elemen terpilih: resize lebar/tinggi
 */
class CanvasView(ctx: Context) : FrameLayout(ctx) {
    interface Listener {
        fun onSelect(el: NoteElement?)
        fun onGestureEnd()
        fun onEditText(el: NoteElement)
        fun onLongPress(el: NoteElement)
    }

    var listener: Listener? = null
    val manager = ElementManager()
    var meta = CanvasMeta()
    var selected: NoteElement? = null
        private set

    private val board = FrameLayout(ctx)
    private val bg = BgView(ctx)
    private val overlay = Overlay(ctx)
    private val views = HashMap<String, ElementView>()
    var zoom = 1f; private set
    var panX = 0f; private set
    var panY = 0f; private set
    private var fitted = false
    private var fitTop = 0; private var fitBottom = 0

    private var mode = 0 // 0 idle, 1 drag, 2 resize, 3 pinch element, 4 pan/zoom canvas
    private var lastX = 0f; private var lastY = 0f; private var downX = 0f; private var downY = 0f
    private var dragX = 0f; private var dragY = 0f
    private var d0 = 1f; private var a0 = 0f; private var s0 = 1f; private var r0 = 0f
    private var z0 = 1f; private var pan0x = 0f; private var pan0y = 0f; private var m0x = 0f; private var m0y = 0f
    private var startedOnEl = false; private var changed = false; private var slopped = false
    private var anchor = FloatArray(2)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    init {
        board.pivotX = 0f; board.pivotY = 0f
        board.addView(bg, LayoutParams(MATCH, MATCH))
        addView(board, LayoutParams(1080, 1920))
        addView(overlay, LayoutParams(MATCH, MATCH))
    }

    // ---------- public API ----------
    fun load(list: List<NoteElement>, m: CanvasMeta) {
        board.removeAllViews(); board.addView(bg, LayoutParams(MATCH, MATCH))
        views.clear(); manager.items.clear(); manager.items.addAll(list)
        meta = m; applyMeta()
        manager.sorted().forEach { attach(it, false) }
        select(null)
    }

    fun applyMeta() {
        val lp = board.layoutParams as LayoutParams
        lp.width = meta.width.toInt(); lp.height = meta.height.toInt()
        board.layoutParams = lp
        bg.meta = meta; bg.invalidate()
        applyTransform()
    }

    fun refreshBg() { bg.meta = meta; bg.invalidate() }

    fun attach(el: NoteElement, reorder: Boolean = true) {
        val v = ElementView(context, el)
        views[el.id] = v
        board.addView(v)
        v.refresh()
        if (reorder) reorder()
    }

    fun reorder() {
        board.removeAllViews(); board.addView(bg, LayoutParams(MATCH, MATCH))
        manager.sorted().forEach { e -> views[e.id]?.let { board.addView(it) } }
    }

    fun refreshEl(el: NoteElement) { views[el.id]?.refresh(); overlay.invalidate() }

    fun removeElement(id: String) {
        manager.remove(id)
        views.remove(id)?.let { board.removeView(it) }
        if (selected?.id == id) select(null)
    }

    fun select(el: NoteElement?) {
        selected = el
        overlay.invalidate()
        listener?.onSelect(el)
    }

    fun viewportCenterBoard(): FloatArray = toBoard(width / 2f, height / 2f)

    fun fitToScreen(topPx: Int = fitTop, bottomPx: Int = fitBottom) {
        fitTop = topPx; fitBottom = bottomPx
        if (width == 0 || height == 0) { fitted = false; return }
        val availH = (height - topPx - bottomPx).toFloat()
        zoom = min(width / meta.width, availH / meta.height) * 0.94f
        panX = (width - meta.width * zoom) / 2f
        panY = topPx + (availH - meta.height * zoom) / 2f
        fitted = true
        applyTransform()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (!fitted) fitToScreen()
    }

    // ---------- transform ----------
    private fun applyTransform() {
        board.scaleX = zoom; board.scaleY = zoom
        board.translationX = panX; board.translationY = panY
        overlay.invalidate()
    }

    private fun toBoard(sx: Float, sy: Float) = floatArrayOf((sx - panX) / zoom, (sy - panY) / zoom)
    private fun toScreen(p: FloatArray) = floatArrayOf(p[0] * zoom + panX, p[1] * zoom + panY)

    /** Sudut elemen (sx,sy = -1/+1) dalam koordinat board, memperhitungkan rotasi + scale. */
    private fun corner(el: NoteElement, sx: Float, sy: Float): FloatArray {
        val cx = el.x + el.width / 2f; val cy = el.y + el.height / 2f
        val r = Math.toRadians(el.rotation.toDouble()); val co = cos(r).toFloat(); val si = sin(r).toFloat()
        val lx = sx * el.width / 2f * el.scale; val ly = sy * el.height / 2f * el.scale
        return floatArrayOf(cx + lx * co - ly * si, cy + lx * si + ly * co)
    }

    private fun hitTest(sx: Float, sy: Float): NoteElement? {
        val b = toBoard(sx, sy)
        for (el in manager.sorted().asReversed()) {
            if (el.hidden) continue
            val cx = el.x + el.width / 2f; val cy = el.y + el.height / 2f
            val dx = b[0] - cx; val dy = b[1] - cy
            val r = Math.toRadians(el.rotation.toDouble()); val co = cos(r).toFloat(); val si = sin(r).toFloat()
            val lx = (dx * co + dy * si) / el.scale; val ly = (-dx * si + dy * co) / el.scale
            if (abs(lx) <= el.width / 2f && abs(ly) <= el.height / 2f) return el
        }
        return null
    }

    private fun handleHit(el: NoteElement, sx: Float, sy: Float): Boolean {
        val h = toScreen(corner(el, 1f, 1f))
        return hypot(h[0] - sx, h[1] - sy) <= dp(28)
    }

    private fun dist(e: MotionEvent) = max(1f, hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)))
    private fun angle(e: MotionEvent) = atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0))

    // ---------- touch ----------
    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val h = hitTest(e.x, e.y)
            if (h != null && h.type == "text") listener?.onEditText(h)
            return true
        }
        override fun onLongPress(e: MotionEvent) {
            val h = hitTest(e.x, e.y)
            if (h != null && !slopped && mode <= 1) listener?.onLongPress(h)
        }
    })

    override fun onInterceptTouchEvent(ev: MotionEvent) = true

    private fun endGesture() { if (changed) { changed = false; listener?.onGestureEnd() } }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        gd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y; downX = e.x; downY = e.y
                changed = false; slopped = false; mode = 0; startedOnEl = false
                val sel = selected
                if (sel != null && !sel.locked && handleHit(sel, e.x, e.y)) {
                    mode = 2; anchor = corner(sel, -1f, -1f); startedOnEl = true
                } else {
                    val hit = hitTest(e.x, e.y)
                    if (hit != null) {
                        if (hit.id != sel?.id) select(hit)
                        startedOnEl = true
                        if (!hit.locked) { mode = 1; dragX = hit.x; dragY = hit.y }
                    } else select(null)
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) {
                val sel = selected
                d0 = dist(e); a0 = angle(e)
                if (sel != null && startedOnEl && !sel.locked) { mode = 3; s0 = sel.scale; r0 = sel.rotation }
                else {
                    mode = 4; z0 = zoom; pan0x = panX; pan0y = panY
                    m0x = (e.getX(0) + e.getX(1)) / 2f; m0y = (e.getY(0) + e.getY(1)) / 2f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!slopped && hypot(e.x - downX, e.y - downY) > slop) slopped = true
                when (mode) {
                    1 -> if (slopped) {
                        val sel = selected ?: return true
                        dragX += (e.x - lastX) / zoom; dragY += (e.y - lastY) / zoom
                        lastX = e.x; lastY = e.y
                        sel.x = if (meta.snap) SnapHelper.snap(dragX, meta.gridSize) else dragX
                        sel.y = if (meta.snap) SnapHelper.snap(dragY, meta.gridSize) else dragY
                        refreshEl(sel); changed = true
                    }
                    2 -> resizeTo(e.x, e.y)
                    3 -> if (e.pointerCount >= 2) {
                        val sel = selected ?: return true
                        sel.scale = (s0 * dist(e) / d0).coerceIn(0.1f, 10f)
                        var rot = r0 + Math.toDegrees((angle(e) - a0).toDouble()).toFloat()
                        if (meta.snap) rot = SnapHelper.snapAngle(rot)
                        sel.rotation = rot
                        refreshEl(sel); changed = true
                    }
                    4 -> if (e.pointerCount >= 2) {
                        zoom = (z0 * dist(e) / d0).coerceIn(0.05f, 8f)
                        val mx = (e.getX(0) + e.getX(1)) / 2f; val my = (e.getY(0) + e.getY(1)) / 2f
                        val bx = (m0x - pan0x) / z0; val by = (m0y - pan0y) / z0
                        panX = mx - bx * zoom; panY = my - by * zoom
                        applyTransform()
                    }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> { if (mode == 3 || mode == 4) { mode = 0; endGesture() } }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { endGesture(); mode = 0 }
        }
        return true
    }

    private fun resizeTo(sx: Float, sy: Float) {
        val sel = selected ?: return
        val b = toBoard(sx, sy)
        val dx = b[0] - anchor[0]; val dy = b[1] - anchor[1]
        val r = Math.toRadians(sel.rotation.toDouble()); val co = cos(r).toFloat(); val si = sin(r).toFloat()
        val lw = max(40f, (dx * co + dy * si) / sel.scale)
        val lh = max(40f, (-dx * si + dy * co) / sel.scale)
        sel.width = lw
        if (sel.type != "text") sel.height = lh
        views[sel.id]?.refresh()                       // teks: tinggi dihitung otomatis
        // jaga pojok kiri-atas tetap di tempat
        val cx = anchor[0] + (sel.width / 2f * co - sel.height / 2f * si) * sel.scale
        val cy = anchor[1] + (sel.width / 2f * si + sel.height / 2f * co) * sel.scale
        sel.x = cx - sel.width / 2f; sel.y = cy - sel.height / 2f
        refreshEl(sel); changed = true
    }

    // ---------- overlay seleksi ----------
    private inner class Overlay(ctx: Context) : View(ctx) {
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dp(2).toFloat() }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        override fun onDraw(c: Canvas) {
            val el = selected ?: return
            if (el.hidden) return
            val pts = listOf(corner(el, -1f, -1f), corner(el, 1f, -1f), corner(el, 1f, 1f), corner(el, -1f, 1f)).map { toScreen(it) }
            val primary = ThemeManager.current.primary
            stroke.color = if (el.locked) 0xFF9E9E9E.toInt() else primary
            path.reset(); path.moveTo(pts[0][0], pts[0][1])
            for (i in 1..3) path.lineTo(pts[i][0], pts[i][1])
            path.close(); c.drawPath(path, stroke)
            if (!el.locked) {
                fill.color = primary; c.drawCircle(pts[2][0], pts[2][1], dp(10).toFloat(), fill)
                fill.color = Color.WHITE; c.drawCircle(pts[2][0], pts[2][1], dp(4).toFloat(), fill)
            }
        }
    }
}

/** Background canvas: warna, gradient, gambar (posisi/scale/rotate/opacity/blur) + grid. */
class BgView(ctx: Context) : View(ctx) {
    var meta = CanvasMeta()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var origPath: String? = null; private var orig: Bitmap? = null
    private var blurVal = -1f; private var blurred: Bitmap? = null

    private fun bitmap(): Bitmap? {
        val path = meta.bgImage ?: return null
        if (path != origPath) { origPath = path; orig = ImageHelper.decode(path, 2048); blurVal = -1f }
        val o = orig ?: return null
        if (blurVal != meta.imgBlur) { blurVal = meta.imgBlur; blurred = ImageHelper.blur(o, meta.imgBlur) }
        return blurred
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val base = parseColor(meta.bgColor, Color.WHITE)
        p.shader = null; p.style = Paint.Style.FILL; p.alpha = 255; p.color = base
        c.drawRect(0f, 0f, w, h, p)
        if (meta.bgType == "gradient") {
            val r = hypot(w, h) / 2f; val a = Math.toRadians(meta.gradAngle.toDouble())
            val dx = (cos(a) * r).toFloat(); val dy = (sin(a) * r).toFloat()
            p.shader = LinearGradient(w / 2 - dx, h / 2 - dy, w / 2 + dx, h / 2 + dy,
                parseColor(meta.gradStart, Color.MAGENTA), parseColor(meta.gradEnd, Color.CYAN), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p); p.shader = null
        }
        if (meta.bgType == "image") {
            val b = bitmap()
            if (b != null) {
                val s = max(w / b.width, h / b.height) * meta.imgScale
                p.color = Color.WHITE; p.alpha = (meta.imgOpacity * 255).toInt().coerceIn(0, 255)
                c.save(); c.clipRect(0f, 0f, w, h)
                c.translate(w / 2f + meta.imgOffX, h / 2f + meta.imgOffY)
                c.rotate(meta.imgRotation); c.scale(s, s)
                c.drawBitmap(b, -b.width / 2f, -b.height / 2f, p)
                c.restore(); p.alpha = 255
            }
        }
        if (meta.grid) {
            p.color = withAlpha(contrastOf(base), .22f); p.strokeWidth = 2f; p.style = Paint.Style.STROKE
            var x = 0f; while (x <= w) { c.drawLine(x, 0f, x, h, p); x += meta.gridSize }
            var y = 0f; while (y <= h) { c.drawLine(0f, y, w, y, p); y += meta.gridSize }
            p.style = Paint.Style.FILL
        }
    }
}
