package com.example.notesapp.ui

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.notesapp.R
import com.example.notesapp.data.Note
import com.example.notesapp.util.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class NoteAdapter(
    private val onClick: (Note) -> Unit,
    private val onLong: (Note) -> Unit
) : ListAdapter<Note, NoteAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<Note>() {
        override fun areItemsTheSame(a: Note, b: Note) = a.id == b.id
        override fun areContentsTheSame(a: Note, b: Note) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: TextView = v.findViewById(R.id.avatar)
        val title: TextView = v.findViewById(R.id.title)
        val preview: TextView = v.findViewById(R.id.preview)
        val date: TextView = v.findViewById(R.id.date)
        val pin: ImageView = v.findViewById(R.id.pin)
        val lock: ImageView = v.findViewById(R.id.lock)
        val datePill: LinearLayout = v.findViewById(R.id.datePill)
    }

    private val avatarColors = intArrayOf(0xFF7C4DFF.toInt(), 0xFF00BFA5.toInt(), 0xFFFF7043.toInt(), 0xFFEC407A.toInt(), 0xFF42A5F5.toInt(), 0xFF8D6E63.toInt(), 0xFF26A69A.toInt())

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(LayoutInflater.from(p.context).inflate(R.layout.item_note, p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val n = getItem(pos)
        val t = ThemeManager.current
        val ctx = h.itemView.context
        h.itemView.background = ripple(null, t.text)
        h.avatar.background = ctx.rr(avatarColors[(n.id % avatarColors.size).toInt()], 28f)
        h.avatar.text = n.title.trim().take(1).uppercase().ifEmpty { "N" }
        h.title.text = n.title.ifBlank { "Tanpa judul" }
        h.title.setTextColor(t.text)
        h.preview.setTextColor(t.textSecondary)
        h.lock.setColorFilter(t.textSecondary)
        h.lock.visibility = if (n.isLocked) View.VISIBLE else View.GONE
        // locked: isi di-blur (API 31+) atau disamarkan
        if (n.isLocked) {
            h.preview.text = if (Build.VERSION.SDK_INT >= 31) n.content.ifBlank { "Catatan terkunci" } else "••••••••••••"
            if (Build.VERSION.SDK_INT >= 31) h.preview.setRenderEffect(RenderEffect.createBlurEffect(14f, 14f, Shader.TileMode.CLAMP))
        } else {
            h.preview.text = n.content.ifBlank { "Belum ada isi" }
            if (Build.VERSION.SDK_INT >= 31) h.preview.setRenderEffect(null)
        }
        h.date.text = formatDate(n.updatedAt)
        h.date.setTextColor(t.textSecondary)
        h.pin.setColorFilter(t.primary)
        h.pin.visibility = if (n.isPinned) View.VISIBLE else View.GONE
        h.datePill.background = if (n.isPinned) ctx.rr(withAlpha(t.text, .1f), 10f) else null

        h.itemView.setOnClickListener { onClick(n) }
        h.itemView.setOnLongClickListener { onLong(n); true }
        // animasi fade + slide up
        h.itemView.alpha = 0f; h.itemView.translationY = ctx.dp(14).toFloat()
        h.itemView.animate().alpha(1f).translationY(0f).setDuration(240).start()
    }

    private fun formatDate(ts: Long): String {
        val now = Calendar.getInstance(); val c = Calendar.getInstance().apply { timeInMillis = ts }
        val fmt = when {
            now.get(Calendar.YEAR) == c.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR) -> "HH:mm"
            now.get(Calendar.YEAR) == c.get(Calendar.YEAR) -> "dd MMM"
            else -> "dd/MM/yy"
        }
        return SimpleDateFormat(fmt, Locale.getDefault()).format(Date(ts))
    }
}
