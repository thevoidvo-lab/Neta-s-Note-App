package com.example.notesapp.ui

import kotlin.math.abs
import kotlin.math.round

object SnapHelper {
    fun snap(v: Float, grid: Float): Float = if (grid <= 1f) v else round(v / grid) * grid

    /** Rotasi nempel ke kelipatan 15° kalau dekat (<5°). */
    fun snapAngle(deg: Float): Float {
        val n = round(deg / 15f) * 15f
        return if (abs(n - deg) < 5f) n else deg
    }
}
