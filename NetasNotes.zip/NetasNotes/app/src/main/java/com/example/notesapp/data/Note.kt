package com.example.notesapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONObject

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val elements: String = "[]",
    val backgroundPath: String? = null,
    val fontFamily: String? = null,
    val fontSize: Float? = null,
    val color: String? = null,
    val isPinned: Boolean = false,
    val isLocked: Boolean = false,
    val category: String? = null,
    val x: Float = 0f,
    val y: Float = 0f,
    val width: Float = 1080f,
    val height: Float = 1920f,
    val rotation: Float = 0f,
    val zIndex: Int = 0,
    /** JSON pengaturan canvas: gradient, opacity/blur gambar, grid, snap, dll. */
    val canvasMeta: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

fun Note.toJson(): JSONObject = JSONObject().apply {
    put("id", id); put("title", title); put("content", content); put("elements", elements)
    put("backgroundPath", backgroundPath ?: JSONObject.NULL)
    put("fontFamily", fontFamily ?: JSONObject.NULL)
    put("fontSize", fontSize?.toDouble() ?: JSONObject.NULL)
    put("color", color ?: JSONObject.NULL)
    put("isPinned", isPinned); put("isLocked", isLocked)
    put("category", category ?: JSONObject.NULL)
    put("x", x.toDouble()); put("y", y.toDouble())
    put("width", width.toDouble()); put("height", height.toDouble())
    put("rotation", rotation.toDouble()); put("zIndex", zIndex)
    put("canvasMeta", canvasMeta ?: JSONObject.NULL)
    put("createdAt", createdAt); put("updatedAt", updatedAt)
}

fun noteFromJson(o: JSONObject): Note {
    fun s(k: String): String? = if (o.isNull(k)) null else o.optString(k)
    return Note(
        id = 0,
        title = o.optString("title", ""),
        content = o.optString("content", ""),
        elements = o.optString("elements", "[]"),
        backgroundPath = s("backgroundPath"),
        fontFamily = s("fontFamily"),
        fontSize = if (o.isNull("fontSize")) null else o.optDouble("fontSize").toFloat(),
        color = s("color"),
        isPinned = o.optBoolean("isPinned", false),
        isLocked = o.optBoolean("isLocked", false),
        category = s("category"),
        x = o.optDouble("x", 0.0).toFloat(), y = o.optDouble("y", 0.0).toFloat(),
        width = o.optDouble("width", 1080.0).toFloat(), height = o.optDouble("height", 1920.0).toFloat(),
        rotation = o.optDouble("rotation", 0.0).toFloat(), zIndex = o.optInt("zIndex", 0),
        canvasMeta = s("canvasMeta"),
        createdAt = o.optLong("createdAt", System.currentTimeMillis()),
        updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
    )
}
