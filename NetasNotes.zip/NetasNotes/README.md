# Neta's Notes

Android (Kotlin, Room, Material 3). Build: push ke GitHub -> Actions -> artifact `netas-notes-apk`.

Catatan:
- Workflow pakai `gradle/actions/setup-gradle` (Gradle 8.0), jadi tidak butuh `gradle-wrapper.jar`.
- Mau pakai `./gradlew` lokal? Jalankan `gradle wrapper --gradle-version 8.0` sekali.
- Font Poppins/Inter: taruh file .ttf lewat fitur Upload Font di app (atau bundel sendiri di res/font).
