# NotesApp

Project Kotlin Android dengan Room, Material 3, DataStore, Glide, EncryptedSharedPreferences, catatan, lock PIN, kanvas gambar, JSON import/export, editor elemen bebas, dan workflow GitHub Actions.

Build lokal: Android Studio, JDK 17, Android SDK 34. Jalankan `./gradlew assembleDebug`. `gradlew` membangun Gradle 8.0 secara otomatis jika belum ada di mesin.

Batasan yang perlu diketahui: PIN per-catatan diverifikasi sebelum editor dibuka; PIN global disimpan terenkripsi namun saat ini hanya disediakan untuk pengaturan PIN aplikasi. Gestur editor mencakup tap pilih, double-tap edit teks, drag, pinch scale, long-press menu. Rotasi gestur dua jari dan snap ke elemen tetangga belum tersedia; toggle snap tersimpan pada sesi editor. Ekspor menyertakan gambar yang URI-nya dapat dibaca saat ekspor, namun beberapa provider galeri dapat menolak pembacaan ulang. Tema Ocean/Forest/Sunset menyediakan palet warna pada ThemeManager, sedangkan komponen tema XML saat ini memakai warna dasar Material 3; mode Dark aktif penuh. Icon preset memakai launcher vector drawables sederhana dalam mipmap, bukan bitmap raster.
