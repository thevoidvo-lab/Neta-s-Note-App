# Neta's Notes

Android notes app project (Kotlin, Room, Material 3, minSdk 24 / targetSdk 34, Java 17).

## Build APK

Run `./gradlew assembleDebug`, or push to GitHub and open **Actions → Build Neta's Notes APK**. Download `netas-notes-apk` from the successful run's Artifacts section.

## Redesigned interface

The home and notes list now use a dark Material 3 visual system, purple/teal accents, rounded search, filter chips, elevated note cards, empty state, bottom navigation, floating create button, contextual long-press actions, and swipe-to-delete/pin. The current UI uses system sans-serif fallback; custom font files can be placed in `app/src/main/res/font/`.
