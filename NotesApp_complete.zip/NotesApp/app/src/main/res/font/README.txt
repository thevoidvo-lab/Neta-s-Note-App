Taruh font .ttf/.otf berlisensi di folder ini.
