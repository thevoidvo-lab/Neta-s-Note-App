package com.example.notesapp.util
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.themeStore by preferencesDataStore(name = "settings")
object ThemeManager {
    val names = listOf("Light", "Dark", "Ocean", "Forest", "Sunset")
    private val KEY = intPreferencesKey("theme_index")
    data class Palette(val primary: Int, val secondary: Int, val background: Int, val surface: Int)
    fun palette(index: Int): Palette = when(index) {
        1 -> Palette(0xFFB8A6FF.toInt(), 0xFFCCC2DC.toInt(), 0xFF141218.toInt(), 0xFF211F26.toInt())
        2 -> Palette(0xFF1565C0.toInt(), 0xFF00ACC1.toInt(), 0xFFEAF4FF.toInt(), 0xFFFFFFFF.toInt())
        3 -> Palette(0xFF2E7D32.toInt(), 0xFF81C784.toInt(), 0xFFEDF7ED.toInt(), 0xFFFFFFFF.toInt())
        4 -> Palette(0xFFE65100.toInt(), 0xFFFFB74D.toInt(), 0xFFFFF3E0.toInt(), 0xFFFFFFFF.toInt())
        else -> Palette(0xFF6750A4.toInt(), 0xFF625B71.toInt(), 0xFFFFFBFE.toInt(), 0xFFFFFBFE.toInt())
    }
    suspend fun get(context: Context): Int = runCatching { context.themeStore.data.first()[KEY] ?: 1 }.getOrDefault(0)
    suspend fun set(context: Context, value: Int) { context.themeStore.edit { it[KEY] = value.coerceIn(0, names.lastIndex) } }
    fun apply(index: Int) {
        runCatching { AppCompatDelegate.setDefaultNightMode(if (index == 1) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO) }
            .onFailure { AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO) }
    }
}
