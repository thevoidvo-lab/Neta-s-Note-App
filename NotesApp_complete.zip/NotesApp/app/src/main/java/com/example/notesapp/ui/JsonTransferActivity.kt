package com.example.notesapp.ui
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.notesapp.data.Note
import com.example.notesapp.util.CrashHandler
import com.example.notesapp.util.ImageHelper
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class JsonTransferActivity : AppCompatActivity() {
    private lateinit var vm: NotesViewModel
    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importJson(uri) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); vm = ViewModelProvider(this, NotesViewModel.Factory(application))[NotesViewModel::class.java]
        val root = LinearLayout(this).apply { orientation = 1; setPadding(32,32,32,32) }
        root.addView(Button(this).apply { text = if (intent.getStringExtra("mode") == "export") "Ekspor ke Downloads" else "Pilih JSON untuk diimpor"; setOnClickListener { if (intent.getStringExtra("mode") == "export") exportJson() else importPicker.launch(arrayOf("application/json","text/*")) } })
        setContentView(root)
    }
    private fun exportJson() = lifecycleScope.launch {
        runCatching {
            val array = JSONArray()
            vm.exportAll().forEach { n ->
                val imageArray = JSONArray()
                runCatching { JSONArray(n.imageUrisJson) }.getOrNull()?.let { src ->
                    for (i in 0 until src.length()) {
                        val uriText = src.optString(i)
                        val base64 = ImageHelper.uriToBase64(this@JsonTransferActivity, runCatching { Uri.parse(uriText) }.getOrNull())
                        imageArray.put(JSONObject().put("uri", uriText).put("base64", base64))
                    }
                }
                val canvas64 = n.canvasPath?.let { path -> runCatching { android.util.Base64.encodeToString(FileInputStream(path).use { it.readBytes() }, android.util.Base64.NO_WRAP) }.getOrNull() }
                val bg64 = n.backgroundUri?.let { ImageHelper.uriToBase64(this@JsonTransferActivity, Uri.parse(it)) }
                array.put(JSONObject().put("id",n.id).put("title",n.title).put("content",n.content).put("updatedAt",n.updatedAt)
                    .put("category",n.category).put("fontName",n.fontName).put("backgroundUri",n.backgroundUri).put("backgroundBase64",bg64)
                    .put("images",imageArray).put("canvasBase64",canvas64).put("isPinned",n.isPinned).put("isLocked",n.isLocked)
                    .put("pinHash",n.pinHash).put("elements",n.elements).put("backgroundPath",n.backgroundPath))
            }
            val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, "notes_export.json"); put(MediaStore.Downloads.MIME_TYPE, "application/json"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.IS_PENDING, 1) }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Gagal membuat file di Downloads")
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(array.toString(2)) } ?: error("Gagal membuka file ekspor")
            if (Build.VERSION.SDK_INT >= 29) contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            Toast.makeText(this@JsonTransferActivity, "Ekspor berhasil ke Downloads", Toast.LENGTH_LONG).show()
        }.onFailure { CrashHandler.log(this@JsonTransferActivity, "JSON/export", it); Toast.makeText(this@JsonTransferActivity, "Ekspor gagal: ${it.message}", Toast.LENGTH_LONG).show() }
    }
    private fun importJson(uri: Uri) = lifecycleScope.launch {
        runCatching {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("File tidak dapat dibaca")
            val arr = JSONArray(raw)
            val notes = mutableListOf<Note>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val importedCanvas = o.optString("canvasBase64").takeIf { it.isNotBlank() && it != "null" }?.let { encoded ->
                    runCatching {
                        val dir = File(filesDir, "canvas").apply { mkdirs() }; val file = File(dir, "import_${System.currentTimeMillis()}_$i.png")
                        FileOutputStream(file).use { it.write(android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)) }; file.absolutePath
                    }.getOrNull()
                }
                val bg = o.optString("backgroundBase64").takeIf { it.isNotBlank() && it != "null" }?.let { ImageHelper.base64ToFile(this@JsonTransferActivity, it, "bg_${System.currentTimeMillis()}_$i.png") }
                val imageUris = JSONArray()
                val imgs = o.optJSONArray("images") ?: JSONArray()
                for (j in 0 until imgs.length()) {
                    val img = imgs.optJSONObject(j) ?: continue
                    val saved = ImageHelper.base64ToFile(this@JsonTransferActivity, img.optString("base64"), "img_${System.currentTimeMillis()}_${i}_$j.png")
                    if (saved != null) imageUris.put(Uri.fromFile(File(saved)).toString()) else imageUris.put(img.optString("uri"))
                }
                notes.add(Note(title=o.optString("title"), content=o.optString("content"), updatedAt=o.optLong("updatedAt",System.currentTimeMillis()),
                    category=o.optString("category","Umum"), fontName=o.optString("fontName","sans-serif"),
                    backgroundUri=bg?.let { Uri.fromFile(File(it)).toString() } ?: o.optString("backgroundUri").takeIf { it.isNotBlank() && it != "null" },
                    imageUrisJson=imageUris.toString(), canvasPath=importedCanvas, isPinned=o.optBoolean("isPinned"), isLocked=o.optBoolean("isLocked"),
                    pinHash=o.optString("pinHash").takeIf { it.isNotBlank() && it != "null" }, elements=runCatching { o.optString("elements","[]").also { JSONArray(it) } }.getOrDefault("[]"),
                    backgroundPath=o.optString("backgroundPath").takeIf { it.isNotBlank() && it != "null" }))
            }
            vm.importAll(notes)
            Toast.makeText(this@JsonTransferActivity, "Impor ${notes.size} catatan selesai", Toast.LENGTH_LONG).show()
        }.onFailure { CrashHandler.log(this@JsonTransferActivity, "JSON/import", it); Toast.makeText(this@JsonTransferActivity, "JSON rusak atau format tidak valid", Toast.LENGTH_LONG).show() }
    }
}
