package com.example.notesapp.ui
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import java.io.File
import java.io.FileOutputStream

class CanvasView(context: Context) : View(context) {
    private val paths = mutableListOf<Pair<Path, Paint>>()
    private val undone = mutableListOf<Pair<Path, Paint>>()
    private var activePath: Path? = null
    var inkColor: Int = Color.BLACK
    var eraser: Boolean = false
    var strokeWidth: Float = 7f
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); canvas.drawColor(Color.WHITE)
        paths.forEach { canvas.drawPath(it.first, it.second) }
        activePath?.let { canvas.drawPath(it, currentPaint()) }
    }
    private fun currentPaint() = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (eraser) Color.WHITE else inkColor; this.strokeWidth = this@CanvasView.strokeWidth; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    override fun onTouchEvent(event: MotionEvent): Boolean = runCatching {
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { activePath = Path().apply { moveTo(event.x, event.y) }; undone.clear(); invalidate() }
            MotionEvent.ACTION_MOVE -> { activePath?.lineTo(event.x, event.y); invalidate() }
            MotionEvent.ACTION_UP -> { activePath?.let { paths.add(it to currentPaint()) }; activePath = null; invalidate() }
        }; true
    }.getOrDefault(false)
    fun undo() { if (paths.isNotEmpty()) undone.add(paths.removeAt(paths.lastIndex)); invalidate() }
    fun redo() { if (undone.isNotEmpty()) paths.add(undone.removeAt(undone.lastIndex)); invalidate() }
    fun clearCanvas() { paths.clear(); undone.clear(); activePath = null; invalidate() }
    fun saveTo(file: File): Boolean = runCatching {
        val w = width.coerceAtLeast(1); val h = height.coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap); c.drawColor(Color.WHITE); paths.forEach { c.drawPath(it.first, it.second) }
        activePath?.let { c.drawPath(it, currentPaint()) }
        file.parentFile?.mkdirs(); FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }; bitmap.recycle(); true
    }.getOrDefault(false)
}
