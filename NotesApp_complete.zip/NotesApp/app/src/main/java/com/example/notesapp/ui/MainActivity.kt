package com.example.notesapp.ui
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.notesapp.databinding.ActivityMainBinding
import com.example.notesapp.util.ThemeManager
import kotlinx.coroutines.launch
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch { ThemeManager.apply(ThemeManager.get(this@MainActivity)) }
        val b = ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        b.btnNotes.setOnClickListener { startActivity(Intent(this, NoteListActivity::class.java)) }
        b.btnNew.setOnClickListener { startActivity(Intent(this, NoteEditActivity::class.java)) }
        b.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }
}
