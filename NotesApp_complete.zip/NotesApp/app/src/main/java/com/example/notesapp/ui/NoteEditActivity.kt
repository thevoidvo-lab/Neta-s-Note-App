package com.example.notesapp.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Vibrator
import android.content.Context
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.notesapp.data.Note
import com.example.notesapp.data.NoteElement
import com.example.notesapp.databinding.ActivityNoteEditBinding
import com.example.notesapp.util.CrashHandler
import com.example.notesapp.util.FontManager
import com.example.notesapp.util.ImageHelper
import com.example.notesapp.util.PinManager
import kotlinx.coroutines.launch
import java.io.File
import java.security.MessageDigest

class NoteEditActivity : AppCompatActivity() {
    private lateinit var b: ActivityNoteEditBinding
    private lateinit var vm: NotesViewModel
    private var note = Note()
    private var unlocked = false
    private var wrongPins = 0
    private var elements = mutableListOf<NoteElement>()
    private val history = UndoRedoManager<List<NoteElement>>()
    private var snapEnabled = false
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { addImageElement(it) } }
    private val pickBackground = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { note = note.copy(backgroundUri = it.toString(), backgroundPath = it.toString()); ImageHelper.show(this, it, b.backgroundPreview); saveNow() }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNoteEditBinding.inflate(layoutInflater); setContentView(b.root)
        vm = ViewModelProvider(this, NotesViewModel.Factory(application))[NotesViewModel::class.java]
        b.category.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Umum","Pribadi","Kerja","Ide","Belajar"))
        b.fontPicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, FontManager.names)
        val id = intent.getLongExtra("note_id", 0L)
        if (id > 0L) vm.get(id) { loaded -> runOnUiThread { loaded?.let { note = it; if (it.isLocked) askUnlock() else { unlocked = true; populate(it) } } } }
        else { unlocked = true; setupEditor() }
        b.pickBackground.setOnClickListener { guard { pickBackground.launch("image/*") } }
        b.addImage.setOnClickListener { guard { pickImage.launch("image/*") } }
        b.addText.setOnClickListener { guard { addElement("text") } }
        b.addTitle.setOnClickListener { guard { addElement("title") } }
        b.addShape.setOnClickListener { guard { addElement("shape") } }
        b.undoButton.setOnClickListener { val prev = history.undo(elements.toList()); if (prev != null) { elements = prev.toMutableList(); renderElements(); updateHistoryButtons() } }
        b.redoButton.setOnClickListener { val next = history.redo(elements.toList()); if (next != null) { elements = next.toMutableList(); renderElements(); updateHistoryButtons() } }
        b.saveButton.setOnClickListener { guard { saveNow() } }
        b.backButton.setOnClickListener { finish() }
        b.settingsButton.setOnClickListener { guard { editorSettings() } }
        b.pinToggle.setOnClickListener { guard { note = note.copy(isPinned = !note.isPinned); b.pinToggle.text = if(note.isPinned) "📌 Tersemat" else "Sematkan"; saveNow() } }
        b.lockButton.setOnClickListener { guard { setNotePin() } }
        b.pickCanvas.setOnClickListener { guard { showCanvas() } }
        b.clearCanvas.setOnClickListener { guard { note.canvasPath?.let { runCatching { File(it).delete() } }; note = note.copy(canvasPath = null); b.canvasPreview.setImageDrawable(null); saveNow() } }
        b.deleteButton.setOnClickListener { guard { if (note.id > 0) AlertDialog.Builder(this).setMessage("Hapus catatan?").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> vm.delete(note); finish() }.show() else finish() } }
    }
    private inline fun guard(block: () -> Unit) { if (unlocked) runCatching(block).onFailure { CrashHandler.log(this, "NoteEditActivity", it); Toast.makeText(this, "Operasi gagal", Toast.LENGTH_SHORT).show() } }
    private fun askUnlock() {
        val input = EditText(this).apply { hint = "PIN catatan"; inputType = 2 }
        val dialog = AlertDialog.Builder(this).setTitle("Catatan terkunci").setMessage("Masukkan PIN untuk melanjutkan.").setView(input)
            .setCancelable(false).setNegativeButton("Keluar") { _, _ -> finish() }.setPositiveButton("Buka", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (PinManager.verifyNotePin(note.pinHash, input.text.toString())) { unlocked = true; dialog.dismiss(); populate(note) }
                else { wrongPins++; runCatching { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(120) }; Toast.makeText(this, "PIN salah ($wrongPins/5)", Toast.LENGTH_SHORT).show(); input.text.clear(); if (wrongPins >= 5) { dialog.dismiss(); finish() } }
            }
        }; dialog.show()
    }
    private fun populate(n: Note) {
        b.titleInput.setText(n.title); b.contentInput.setText(n.content); b.category.setSelection(listOf("Umum","Pribadi","Kerja","Ide","Belajar").indexOf(n.category).coerceAtLeast(0))
        b.fontPicker.setSelection(FontManager.names.indexOf(n.fontName).coerceAtLeast(0)); b.pinToggle.text = if(n.isPinned) "📌 Tersemat" else "Sematkan"
        n.backgroundUri?.let { runCatching { ImageHelper.show(this, Uri.parse(it), b.backgroundPreview) } }
        n.canvasPath?.let { path -> runCatching { ImageHelper.show(this, Uri.fromFile(File(path)), b.canvasPreview) } }
        elements = ElementManager.parse(n.elements); setupEditor()
    }
    private fun setupEditor() {
        if (history.canUndo().not()) history.push(elements.toList())
        renderElements(); updateHistoryButtons()
    }
    private fun addElement(type: String) {
        val content = when(type) { "title" -> "Judul catatan"; "shape" -> "Kotak"; else -> "Teks baru" }
        val element = ElementManager.new(type, content)
        elements.add(element); history.push(elements.toList()); renderElements(); updateHistoryButtons(); saveNow()
    }
    private fun addImageElement(uri: Uri) {
        val el = ElementManager.new("image", uri.toString()).copy(width = 180f, height = 140f)
        elements.add(el); history.push(elements.toList()); renderElements(); saveNow()
    }
    private fun renderElements() {
        b.editorCanvas.removeAllViews()
        elements.sortedBy { it.zIndex }.forEach { e ->
            val view = ElementView(this, e, { changed ->
                val idx = elements.indexOfFirst { it.id == changed.id }
                if (idx >= 0) elements[idx] = changed else elements.add(changed)
                saveNow()
            }, { selected -> selected.setBackgroundColor(0x223F51B5); selected.postDelayed({ selected.setBackgroundColor(Color.TRANSPARENT) }, 180) })
            val lp = FrameLayout.LayoutParams(e.width.toInt().coerceAtLeast(40), e.height.toInt().coerceAtLeast(32))
            b.editorCanvas.addView(view, lp); view.x = e.x; view.y = e.y
        }
    }
    private fun updateHistoryButtons() { b.undoButton.isEnabled = history.canUndo(); b.redoButton.isEnabled = history.canRedo() }
    private fun editorSettings() {
        val choices = arrayOf("Ganti background dari galeri", "Snap to grid: ${if(snapEnabled) "ON" else "OFF"}", "Tampilkan grid", "Ubah warna teks")
        AlertDialog.Builder(this).setTitle("Editor").setItems(choices) { _, which ->
            when(which) { 0 -> pickBackground.launch("image/*"); 1 -> { snapEnabled = !snapEnabled; Toast.makeText(this, "Snap ${if(snapEnabled) "aktif" else "nonaktif"}", Toast.LENGTH_SHORT).show() }; 2 -> { b.editorCanvas.setBackgroundColor(if(b.editorCanvas.tag == "grid") Color.WHITE else 0xFFEFEFEF.toInt()); b.editorCanvas.tag = if(b.editorCanvas.tag == "grid") null else "grid" }; 3 -> { val input = EditText(this); input.setText("#222222"); AlertDialog.Builder(this).setTitle("Warna HEX").setView(input).setPositiveButton("Terapkan") { _, _ -> elements.lastOrNull()?.let { e -> elements[elements.lastIndex] = e.copy(color = input.text.toString()); renderElements(); saveNow() } }.setNegativeButton("Batal",null).show() }
            }
        }.show()
    }
    private fun setNotePin() {
        val input = EditText(this).apply { hint = "PIN baru (4-12 digit)"; inputType = 2 }
        AlertDialog.Builder(this).setTitle("Atur PIN catatan").setView(input).setNegativeButton("Batal",null).setPositiveButton("Simpan") { _, _ ->
            val pin = input.text.toString()
            if (pin.length !in 4..12 || !pin.all(Char::isDigit)) Toast.makeText(this, "PIN harus 4–12 digit", Toast.LENGTH_SHORT).show()
            else { note = note.copy(isLocked = true, pinHash = PinManager.hash(pin)); Toast.makeText(this, "PIN catatan disimpan", Toast.LENGTH_SHORT).show(); saveNow() }
        }.show()
    }
    private fun showCanvas() {
        val canvas = CanvasView(this)
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(canvas, LinearLayout.LayoutParams(-1, 520)) }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(Button(this).apply { text = "Undo"; setOnClickListener { canvas.undo() } })
        tools.addView(Button(this).apply { text = "Eraser"; setOnClickListener { canvas.eraser = !canvas.eraser } })
        tools.addView(Button(this).apply { text = "Merah"; setOnClickListener { canvas.inkColor = Color.RED; canvas.eraser = false } })
        tools.addView(Button(this).apply { text = "Biru"; setOnClickListener { canvas.inkColor = Color.BLUE; canvas.eraser = false } })
        tools.addView(Button(this).apply { text = "Clear"; setOnClickListener { canvas.clearCanvas() } })
        container.addView(tools)
        AlertDialog.Builder(this).setTitle("Kanvas gambar").setView(container).setNegativeButton("Batal",null).setPositiveButton("Simpan") { _, _ ->
            val dir = File(filesDir, "canvas").apply { mkdirs() }; val id = if(note.id > 0) note.id else System.currentTimeMillis()
            val file = File(dir, "note_${id}.png")
            if (canvas.saveTo(file)) { note = note.copy(canvasPath = file.absolutePath); ImageHelper.show(this, Uri.fromFile(file), b.canvasPreview); saveNow() }
            else Toast.makeText(this, "Gagal menyimpan kanvas", Toast.LENGTH_LONG).show()
        }.show()
    }
    private fun saveNow() {
        val n = note.copy(title = b.titleInput.text.toString(), content = b.contentInput.text.toString(), category = b.category.selectedItem?.toString() ?: "Umum",
            fontName = b.fontPicker.selectedItem?.toString() ?: "sans-serif", elements = ElementManager.encode(elements), updatedAt = System.currentTimeMillis())
        vm.save(n) { id -> note = n.copy(id = if(n.id == 0L) id else n.id) }
    }
}
