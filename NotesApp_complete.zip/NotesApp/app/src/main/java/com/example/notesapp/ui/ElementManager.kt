package com.example.notesapp.ui
import com.example.notesapp.data.NoteElement
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object ElementManager {
    fun parse(json: String?): MutableList<NoteElement> = runCatching {
        val array = JSONArray(json ?: "[]")
        MutableList(array.length()) { i ->
            val o = array.getJSONObject(i)
            NoteElement(o.optString("id", UUID.randomUUID().toString()), o.optString("type", "text"), o.optString("content"),
                o.optDouble("x", 24.0).toFloat(), o.optDouble("y", 24.0).toFloat(), o.optDouble("width", 220.0).toFloat(),
                o.optDouble("height", 80.0).toFloat(), o.optDouble("rotation", 0.0).toFloat(), o.optDouble("scale", 1.0).toFloat(),
                o.optInt("zIndex", i), o.optString("fontFamily").takeIf { it.isNotBlank() && it != "null" },
                if (o.has("fontSize") && !o.isNull("fontSize")) o.optDouble("fontSize").toFloat() else null,
                o.optString("color").takeIf { it.isNotBlank() && it != "null" })
        }
    }.getOrDefault(mutableListOf())
    fun encode(elements: List<NoteElement>): String = JSONArray().apply {
        elements.forEach { e -> put(JSONObject().put("id",e.id).put("type",e.type).put("content",e.content).put("x",e.x).put("y",e.y)
            .put("width",e.width).put("height",e.height).put("rotation",e.rotation).put("scale",e.scale).put("zIndex",e.zIndex)
            .put("fontFamily",e.fontFamily).put("fontSize",e.fontSize).put("color",e.color)) }
    }.toString()
    fun new(type: String, content: String = "") = NoteElement(UUID.randomUUID().toString(), type, content, 24f, 24f, 220f, 80f, zIndex = System.currentTimeMillis().toInt(), fontFamily = "sans-serif", fontSize = 24f, color = "#222222")
}
