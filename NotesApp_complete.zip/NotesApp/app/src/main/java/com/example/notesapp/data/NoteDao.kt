package com.example.notesapp.data
import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY isPinned DESC, updatedAt DESC")
    fun observeAll(): LiveData<List<Note>>
    @Query("SELECT * FROM notes WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Note?
    @Query("SELECT * FROM notes WHERE (title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%') AND (:category = '' OR category = :category) ORDER BY isPinned DESC, updatedAt DESC")
    fun search(query: String, category: String): LiveData<List<Note>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(note: Note): Long
    @Update suspend fun update(note: Note)
    @Delete suspend fun delete(note: Note)
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC") suspend fun exportAll(): List<Note>
}
