package com.example.notesapp.ui
import android.app.Application
import androidx.lifecycle.*
import com.example.notesapp.data.*
import com.example.notesapp.util.CrashHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
class NotesViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = NoteDatabase.get(app).noteDao()
    val notes = dao.observeAll()
    fun search(q: String, category: String) = dao.search(q, category)
    fun get(id: Long, callback: (Note?) -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        val result = runCatching { dao.getById(id) }.getOrElse { CrashHandler.log(getApplication(), "DB/get", it); null }
        callback(result)
    }
    fun save(note: Note, callback: (Long) -> Unit = {}) = viewModelScope.launch(Dispatchers.IO) {
        val id = runCatching { if (note.id == 0L) dao.insert(note) else { dao.update(note); note.id } }
            .getOrElse { CrashHandler.log(getApplication(), "DB/save", it); -1L }
        callback(id)
    }
    fun delete(note: Note) = viewModelScope.launch(Dispatchers.IO) { runCatching { dao.delete(note) }.onFailure { CrashHandler.log(getApplication(), "DB/delete", it) } }
    suspend fun exportAll() = runCatching { dao.exportAll() }.getOrElse { CrashHandler.log(getApplication(), "DB/export", it); emptyList() }
    suspend fun importAll(list: List<Note>) { list.forEach { runCatching { dao.insert(it.copy(id = 0)) }.onFailure { e -> CrashHandler.log(getApplication(), "DB/import", e) } } }
    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = NotesViewModel(app) as T
    }
}
