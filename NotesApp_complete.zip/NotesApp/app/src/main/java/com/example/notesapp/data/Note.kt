package com.example.notesapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val category: String = "Umum",
    val fontName: String = "sans-serif",
    val backgroundUri: String? = null,
    val imageUrisJson: String = "[]",
    val drawingPath: String? = null,
    val canvasPath: String? = null,
    val isPinned: Boolean = false,
    val isLocked: Boolean = false,
    val pinHash: String? = null,
    val elements: String = "[]",
    val backgroundPath: String? = null
)
