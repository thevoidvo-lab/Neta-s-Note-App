package com.example.notesapp.ui
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import com.example.notesapp.data.NoteElement
import kotlin.math.atan2

class ElementView(context: Context, var element: NoteElement, private val changed: (NoteElement) -> Unit, private val selected: (ElementView) -> Unit) : FrameLayout(context) {
    private val label = TextView(context)
    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { selected(this@ElementView); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (element.type == "text" || element.type == "title") {
                val input = android.widget.EditText(context).apply { setText(element.content); setSelection(text.length) }
                android.app.AlertDialog.Builder(context).setTitle("Edit teks").setView(input).setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
                    element = element.copy(content = input.text.toString()); render(); changed(element)
                }.show()
            }
            return true
        }
        override fun onLongPress(e: MotionEvent) {
            android.app.AlertDialog.Builder(context).setItems(arrayOf("Hapus", "Bawa ke depan", "Kirim ke belakang", "Duplikat")) { _, which ->
                when(which) {
                    0 -> (parent as? FrameLayout)?.removeView(this@ElementView)
                    1 -> bringToFront()
                    2 -> (parent as? FrameLayout)?.let { it.removeView(this@ElementView); it.addView(this@ElementView, 0) }
                    3 -> changed(element.copy(id = java.util.UUID.randomUUID().toString(), x = element.x + 24f, y = element.y + 24f))
                }
            }.show()
        }
    })
    private val scaler = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            element = element.copy(scale = (element.scale * detector.scaleFactor).coerceIn(0.35f, 4f))
            scaleX = element.scale; scaleY = element.scale; changed(element); return true
        }
    })
    private var downX = 0f
    private var downY = 0f
    init { setWillNotDraw(false); addView(label, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)); render() }
    fun render() {
        label.isClickable = false; label.isFocusable = false
        label.text = when(element.type) { "shape" -> element.content.ifBlank { "□" }; "image", "sticker" -> "🖼 ${element.content}"; else -> element.content }
        label.textSize = element.fontSize ?: 22f
        label.typeface = Typeface.create(element.fontFamily ?: "sans-serif", Typeface.NORMAL)
        label.setTextColor(runCatching { Color.parseColor(element.color ?: "#222222") }.getOrDefault(Color.DKGRAY))
        label.setPadding(8,8,8,8)
        background = if (element.type == "shape") android.graphics.drawable.GradientDrawable().apply { setColor(0x223366CC); setStroke(2, 0xFF3366CC.toInt()) } else null
        rotation = element.rotation; scaleX = element.scale; scaleY = element.scale
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        return runCatching {
            gestures.onTouchEvent(event); scaler.onTouchEvent(event)
            when(event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX - x; downY = event.rawY - y; selected(this) }
                MotionEvent.ACTION_MOVE -> if (!scaler.isInProgress && event.pointerCount == 1) {
                    x = event.rawX - downX; y = event.rawY - downY
                    element = element.copy(x = x, y = y); changed(element)
                }
                MotionEvent.ACTION_UP -> performClick()
            }
            true
        }.getOrElse { false }
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
