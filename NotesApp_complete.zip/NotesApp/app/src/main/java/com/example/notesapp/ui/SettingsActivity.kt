package com.example.notesapp.ui
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.notesapp.databinding.ActivitySettingsBinding
import com.example.notesapp.util.PinManager
import com.example.notesapp.util.ThemeManager
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySettingsBinding.inflate(layoutInflater); setContentView(b.root)
        b.themePicker.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ThemeManager.names)
        lifecycleScope.launch { b.themePicker.setSelection(ThemeManager.get(this@SettingsActivity)) }
        b.saveSettings.setOnClickListener { lifecycleScope.launch {
            val idx = b.themePicker.selectedItemPosition
            runCatching { ThemeManager.set(this@SettingsActivity, idx); ThemeManager.apply(idx) }
                .onFailure { ThemeManager.apply(0); Toast.makeText(this@SettingsActivity, "Tema gagal; memakai Light", Toast.LENGTH_SHORT).show() }
            recreate()
        } }
        b.changePin.setOnClickListener { changePin() }
        b.iconPicker.setOnClickListener {
            val labels = arrayOf("Default", "Ocean", "Forest", "Sunset", "Mint")
            AlertDialog.Builder(this).setTitle("Pilih ikon").setItems(labels) { _, which -> setIcon(which) }.show()
        }
        b.exportButton.setOnClickListener { startActivity(android.content.Intent(this, JsonTransferActivity::class.java).putExtra("mode", "export")) }
        b.importButton.setOnClickListener { startActivity(android.content.Intent(this, JsonTransferActivity::class.java).putExtra("mode", "import")) }
    }
    private fun changePin() {
        val input = EditText(this).apply { hint = "PIN baru 4-12 digit"; inputType = 2 }
        AlertDialog.Builder(this).setTitle("Ganti PIN aplikasi").setView(input).setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
            runCatching { PinManager.setGlobalPin(this, input.text.toString()) }
                .onSuccess { Toast.makeText(this, "PIN aplikasi disimpan", Toast.LENGTH_SHORT).show() }
                .onFailure { Toast.makeText(this, "PIN harus 4-12 digit dan penyimpanan aman tersedia", Toast.LENGTH_LONG).show() }
        }.show()
    }
    private fun setIcon(which: Int) {
        val aliases = listOf(".ui.MainActivity", ".IconOcean", ".IconForest", ".IconSunset", ".IconMint")
        runCatching {
            aliases.forEachIndexed { i, name ->
                packageManager.setComponentEnabledSetting(ComponentName(packageName, packageName + name),
                    if (i == which) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP)
            }
            Toast.makeText(this, "Ikon akan diperbarui launcher", Toast.LENGTH_SHORT).show()
        }.onFailure { Toast.makeText(this, "Gagal mengganti ikon", Toast.LENGTH_SHORT).show() }
    }
}
