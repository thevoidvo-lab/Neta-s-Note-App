package com.example.notesapp.util
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.ImageView
import com.bumptech.glide.Glide
import java.io.File
import java.io.FileOutputStream

object ImageHelper {
    fun show(context: Context, uri: Uri, target: ImageView) {
        runCatching { Glide.with(context).load(uri).placeholder(android.R.drawable.ic_menu_gallery).error(android.R.drawable.ic_menu_report_image).centerCrop().into(target) }
            .onFailure { target.setImageResource(android.R.drawable.ic_menu_report_image); CrashHandler.log(context, "ImageHelper", it) }
    }
    fun uriToBase64(context: Context, uri: Uri?): String? {
        if (uri == null) return null
        return runCatching { context.contentResolver.openInputStream(uri)?.use { android.util.Base64.encodeToString(it.readBytes(), android.util.Base64.NO_WRAP) } }.getOrNull()
    }
    fun base64ToFile(context: Context, encoded: String?, name: String): String? {
        if (encoded.isNullOrBlank()) return null
        return runCatching {
            val bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            val dir = File(context.filesDir, "imports").apply { mkdirs() }
            val out = File(dir, name)
            if (bmp != null) FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            else FileOutputStream(out).use { it.write(bytes) }
            out.absolutePath
        }.getOrNull()
    }
}
