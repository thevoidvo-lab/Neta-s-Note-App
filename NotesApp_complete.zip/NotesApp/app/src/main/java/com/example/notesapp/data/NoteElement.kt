package com.example.notesapp.data

data class NoteElement(
    val id: String,
    val type: String,
    val content: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val rotation: Float = 0f,
    val scale: Float = 1f,
    val zIndex: Int = 0,
    val fontFamily: String? = null,
    val fontSize: Float? = null,
    val color: String? = null
)
