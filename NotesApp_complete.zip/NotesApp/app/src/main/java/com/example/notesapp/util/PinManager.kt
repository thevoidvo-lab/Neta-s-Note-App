package com.example.notesapp.util

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

object PinManager {
    private const val PREFS = "secure_pin_prefs"
    private const val KEY = "global_pin_hash"
    private fun prefs(context: Context) = runCatching {
        val master = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(context, PREFS, master, EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV, EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }.getOrElse { throw IllegalStateException("Penyimpanan PIN terenkripsi tidak tersedia", it) }
    fun hash(pin: String): String = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    fun setGlobalPin(context: Context, pin: String) { require(pin.length in 4..12 && pin.all(Char::isDigit)); prefs(context).edit().putString(KEY, hash(pin)).apply() }
    fun hasGlobalPin(context: Context): Boolean = prefs(context).contains(KEY)
    fun verifyGlobalPin(context: Context, pin: String): Boolean {
        val stored = prefs(context).getString(KEY, null) ?: return false
        return MessageDigest.isEqual(stored.toByteArray(), hash(pin).toByteArray())
    }
    fun verifyNotePin(noteHash: String?, pin: String): Boolean = noteHash != null && MessageDigest.isEqual(noteHash.toByteArray(), hash(pin).toByteArray())
}
