package com.example.notesapp.ui
import kotlin.math.roundToInt
object SnapHelper {
    fun snap(value: Float, enabled: Boolean, grid: Float = 20f): Float = if (enabled) (value / grid).roundToInt() * grid else value
}
