package com.example.notesapp.util
import android.content.Context
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

object CrashHandler {
    fun log(context: Context, tag: String, error: Throwable) {
        Log.e(tag, error.message ?: "Unknown error", error)
        runCatching {
            val dir = File(context.filesDir, "logs").apply { mkdirs() }
            File(dir, "errors.log").appendText("${System.currentTimeMillis()} [$tag] ${error.message}\n${error.stackTraceToString()}\n\n")
        }
    }
    fun install(context: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            log(context.applicationContext, "CrashHandler/${thread.name}", error)
            previous?.uncaughtException(thread, error)
        }
    }
}
