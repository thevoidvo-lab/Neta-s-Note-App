package com.example.notesapp.ui
class UndoRedoManager<T>(private val limit: Int = 80) {
    private val undo = ArrayDeque<T>()
    private val redo = ArrayDeque<T>()
    fun push(state: T) { undo.addLast(state); while (undo.size > limit) undo.removeFirst(); redo.clear() }
    fun canUndo() = undo.size > 1
    fun canRedo() = redo.isNotEmpty()
    fun undo(current: T): T? { if (undo.size <= 1) return null; redo.addLast(current); undo.removeLast(); return undo.lastOrNull() }
    fun redo(current: T): T? { val next = redo.removeLastOrNull() ?: return null; undo.addLast(current); undo.addLast(next); return next }
}
