package com.example.notesapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Note::class],
    version = 2,
    exportSchema = false
)
abstract class NoteDatabase : RoomDatabase() {

    abstract fun noteDao(): NoteDao

    companion object {

        @Volatile
        private var INSTANCE: NoteDatabase? = null

        /**
         * Migrasi database versi 1 ke versi 2.
         * Menambahkan kolom yang dibutuhkan tanpa menghapus catatan lama.
         */
        private val MIGRATION_1_2 = object : Migration(1, 2) {

            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `notes` ADD COLUMN `canvasPath` TEXT"
                )

                db.execSQL(
                    "ALTER TABLE `notes` ADD COLUMN `isLocked` INTEGER NOT NULL DEFAULT 0"
                )

                db.execSQL(
                    "ALTER TABLE `notes` ADD COLUMN `elements` TEXT NOT NULL DEFAULT '[]'"
                )

                db.execSQL(
                    "ALTER TABLE `notes` ADD COLUMN `backgroundPath` TEXT"
                )
            }
        }

        fun get(context: Context): NoteDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NoteDatabase::class.java,
                    "notes.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { database ->
                        INSTANCE = database
                    }
            }
        }
    }
}