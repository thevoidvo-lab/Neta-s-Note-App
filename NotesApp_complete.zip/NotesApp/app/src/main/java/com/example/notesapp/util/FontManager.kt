package com.example.notesapp.util
import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat

object FontManager {
    val names = listOf("sans-serif", "serif", "monospace", "casual", "cursive")
    fun resolve(context: Context, name: String): Typeface = runCatching {
        when (name) {
            "serif" -> Typeface.SERIF
            "monospace" -> Typeface.MONOSPACE
            "casual" -> Typeface.create("casual", Typeface.NORMAL)
            "cursive" -> Typeface.create("cursive", Typeface.NORMAL)
            else -> Typeface.SANS_SERIF
        }
    }.getOrDefault(Typeface.DEFAULT)
}
