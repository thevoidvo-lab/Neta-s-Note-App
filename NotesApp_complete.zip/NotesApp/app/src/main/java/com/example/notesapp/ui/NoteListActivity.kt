package com.example.notesapp.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.notesapp.R
import com.example.notesapp.data.Note
import com.example.notesapp.databinding.ActivityNoteListBinding
import com.google.android.material.chip.Chip
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NoteListActivity : AppCompatActivity() {
    private lateinit var b: ActivityNoteListBinding
    private lateinit var vm: NotesViewModel
    private var filter = Filter.ALL
    private var category = ""
    private var allNotes: List<Note> = emptyList()
    private val adapter = NoteAdapter(::openNote, ::showNoteMenu)

    private enum class Filter { ALL, PINNED, LOCKED, CATEGORY }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNoteListBinding.inflate(layoutInflater)
        setContentView(b.root)
        vm = ViewModelProvider(this, NotesViewModel.Factory(application))[NotesViewModel::class.java]
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        b.addNote.setOnClickListener { startActivity(Intent(this, NoteEditActivity::class.java)) }
        b.menuButton.setOnClickListener { view ->
            PopupMenu(this, view).apply {
                menu.add("Pengaturan").setOnMenuItemClickListener { startActivity(Intent(this@NoteListActivity, SettingsActivity::class.java)); true }
                menu.add("Impor / Ekspor JSON").setOnMenuItemClickListener { startActivity(Intent(this@NoteListActivity, JsonTransferActivity::class.java)); true }
                show()
            }
        }
        b.filterChips.setOnCheckedStateChangeListener { group, checkedIds ->
            filter = when (checkedIds.firstOrNull()) {
                R.id.chipPinned -> Filter.PINNED
                R.id.chipLocked -> Filter.LOCKED
                R.id.chipCategory -> Filter.CATEGORY
                else -> Filter.ALL
            }
            if (filter == Filter.CATEGORY) chooseCategory() else { category = ""; refresh() }
        }
        b.searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = refresh()
            override fun afterTextChanged(s: Editable?) = Unit
        })
        b.bottomNavigation.selectedItemId = R.id.nav_notes
        b.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_notes -> true
                R.id.nav_search -> { b.searchBox.requestFocus(); true }
                R.id.nav_settings -> { startActivity(Intent(this, SettingsActivity::class.java)); true }
                R.id.nav_profile -> { Toast.makeText(this, "Neta's Notes · ruang ide pribadi", Toast.LENGTH_SHORT).show(); true }
                else -> false
            }
        }
        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder) = false
            override fun onSwiped(holder: RecyclerView.ViewHolder, direction: Int) {
                val note = adapter.noteAt(holder.bindingAdapterPosition) ?: return
                if (direction == ItemTouchHelper.LEFT) {
                    vm.delete(note); Toast.makeText(this@NoteListActivity, "Catatan dihapus", Toast.LENGTH_SHORT).show()
                } else {
                    vm.save(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
                    Toast.makeText(this@NoteListActivity, if (!note.isPinned) "Catatan disematkan" else "Sematan dilepas", Toast.LENGTH_SHORT).show()
                }
                refresh()
            }
        }).attachToRecyclerView(b.recycler)
        vm.notes.observe(this) { allNotes = it; refresh() }
    }

    private fun openNote(note: Note) {
        startActivity(Intent(this, NoteEditActivity::class.java).putExtra("note_id", note.id))
    }

    private fun chooseCategory() {
        val cats = (listOf("Semua kategori") + allNotes.map { it.category }.filter { it.isNotBlank() }.distinct().sorted()).toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Pilih kategori").setItems(cats) { _, which ->
            category = if (which == 0) "" else cats[which]
            refresh()
        }.setOnCancelListener { b.chipAll.isChecked = true }.show()
    }

    private fun refresh() {
        if (!::b.isInitialized) return
        val q = b.searchBox.text?.toString().orEmpty().trim().lowercase(Locale.getDefault())
        val filtered = allNotes.filter { n ->
            val queryMatch = q.isBlank() || n.title.lowercase(Locale.getDefault()).contains(q) || n.content.lowercase(Locale.getDefault()).contains(q)
            val categoryMatch = category.isBlank() || n.category == category
            val modeMatch = when (filter) { Filter.PINNED -> n.isPinned; Filter.LOCKED -> n.isLocked; else -> true }
            queryMatch && categoryMatch && modeMatch
        }.sortedWith(compareByDescending<Note> { it.isPinned }.thenByDescending { it.updatedAt })
        adapter.submit(filtered)
        b.emptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
        b.recycler.visibility = if (filtered.isEmpty()) View.INVISIBLE else View.VISIBLE
        b.sectionLabel.text = when (filter) { Filter.PINNED -> "CATATAN DISEMATKAN"; Filter.LOCKED -> "CATATAN TERKUNCI"; Filter.CATEGORY -> if (category.isBlank()) "PILIHAN KATEGORI" else category.uppercase(); else -> "TERBARU · ${filtered.size}" }
    }

    private fun showNoteMenu(note: Note, anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(if (note.isPinned) "Lepas sematan" else "Sematkan").setOnMenuItemClickListener { vm.save(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis())); true }
            menu.add(if (note.isLocked) "Buka kunci" else "Kunci catatan").setOnMenuItemClickListener { vm.save(note.copy(isLocked = !note.isLocked, updatedAt = System.currentTimeMillis())); true }
            menu.add("Duplikat").setOnMenuItemClickListener { vm.save(note.copy(id = 0, title = note.title + " (salinan)", isPinned = false, updatedAt = System.currentTimeMillis())); Toast.makeText(this@NoteListActivity, "Catatan diduplikasi", Toast.LENGTH_SHORT).show(); true }
            menu.add("Hapus").setOnMenuItemClickListener { androidx.appcompat.app.AlertDialog.Builder(this@NoteListActivity).setMessage("Hapus catatan ini?").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> vm.delete(note) }.show(); true }
            show()
        }
    }

    private class NoteAdapter(private val click: (Note) -> Unit, private val longClick: (Note, View) -> Unit) : RecyclerView.Adapter<NoteHolder>() {
        private var items: List<Note> = emptyList()
        fun submit(list: List<Note>) { items = list; notifyDataSetChanged() }
        fun noteAt(position: Int): Note? = items.getOrNull(position)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteHolder = NoteHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_note, parent, false), click, longClick)
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: NoteHolder, position: Int) = holder.bind(items[position])
    }

    private class NoteHolder(view: View, private val click: (Note) -> Unit, private val longClick: (Note, View) -> Unit) : RecyclerView.ViewHolder(view) {
        private val title = view.findViewById<TextView>(R.id.itemTitle)
        private val preview = view.findViewById<TextView>(R.id.itemPreview)
        private val date = view.findViewById<TextView>(R.id.itemDate)
        private val pin = view.findViewById<TextView>(R.id.itemPin)
        private val lock = view.findViewById<TextView>(R.id.itemLock)
        private val category = view.findViewById<TextView>(R.id.itemCategory)
        fun bind(note: Note) {
            title.text = note.title.ifBlank { "Catatan tanpa judul" }
            preview.text = if (note.isLocked) "Konten disembunyikan · buka catatan untuk melihat" else note.content.ifBlank { "Mulai tulis ide kamu di sini…" }
            preview.alpha = if (note.isLocked) 0.62f else 1f
            date.text = SimpleDateFormat("dd MMM", Locale("id", "ID")).format(Date(note.updatedAt))
            pin.visibility = if (note.isPinned) View.VISIBLE else View.GONE
            lock.visibility = if (note.isLocked) View.VISIBLE else View.GONE
            category.text = note.category.ifBlank { "UMUM" }.uppercase(Locale.getDefault())
            itemView.setOnClickListener { click(note) }
            itemView.setOnLongClickListener { longClick(note, itemView); true }
        }
    }
}
