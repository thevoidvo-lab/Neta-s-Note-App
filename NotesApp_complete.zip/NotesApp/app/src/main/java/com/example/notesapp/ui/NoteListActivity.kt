package com.example.notesapp.ui
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.notesapp.data.Note
import com.example.notesapp.databinding.ActivityNoteListBinding
class NoteListActivity : AppCompatActivity() {
    private lateinit var b: ActivityNoteListBinding
    private lateinit var vm: NotesViewModel
    private val adapter = NoteAdapter { startActivity(Intent(this, NoteEditActivity::class.java).putExtra("note_id", it.id)) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); b = ActivityNoteListBinding.inflate(layoutInflater); setContentView(b.root)
        vm = ViewModelProvider(this, NotesViewModel.Factory(application))[NotesViewModel::class.java]
        b.recycler.layoutManager = LinearLayoutManager(this); b.recycler.adapter = adapter
        b.categoryFilter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Semua","Umum","Pribadi","Kerja","Ide","Belajar"))
        fun refresh() { val cat = b.categoryFilter.selectedItem?.toString().orEmpty().let { if (it == "Semua") "" else it }; vm.search(b.searchBox.text.toString(), cat).observe(this) { adapter.submit(it) } }
        b.categoryFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        b.searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh() }
            override fun afterTextChanged(s: Editable?) {}
        })
        b.addNote.setOnClickListener { startActivity(Intent(this, NoteEditActivity::class.java)) }
    }
    private class NoteAdapter(val click: (Note) -> Unit) : RecyclerView.Adapter<Holder>() {
        private var data = listOf<Note>()
        fun submit(list: List<Note>) { data = list; notifyDataSetChanged() }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false), click)
        override fun getItemCount() = data.size
        override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(data[position])
    }
    private class Holder(v: View, private val click: (Note) -> Unit) : RecyclerView.ViewHolder(v) {
        fun bind(n: Note) {
            itemView.findViewById<TextView>(android.R.id.text1).text = (if (n.isPinned) "📌 " else "") + (if (n.isLocked) "🔒 " else "") + n.title.ifBlank { "Tanpa judul" }
            itemView.findViewById<TextView>(android.R.id.text2).text = "${n.category} · ${n.content.take(70)}"
            itemView.setOnClickListener { click(n) }
        }
    }
}
