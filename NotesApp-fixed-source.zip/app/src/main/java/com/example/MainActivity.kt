package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.editor.EditorScreen
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.NetasNotesTheme
import com.example.util.CrashHandler
import com.example.util.FontManager
import com.example.util.ThemeManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashHandler.init(applicationContext)
        enableEdgeToEdge()

        setContent {
            MainApp()
        }
    }
}

enum class ScreenTab {
    NOTES, SEARCH, SETTINGS, PROFILE, EDITOR
}

@Composable
fun MainApp() {
    val context = LocalContext.current
    val themeManager = remember { ThemeManager(context) }
    val themeConfig by themeManager.themeFlow.collectAsState(initial = com.example.util.AppThemeConfig.Presets["Dark"]!!)
    val currentFont by FontManager.getSavedFont(context).collectAsState(initial = "Default")
    val fontFamily = FontManager.getFontFamily(currentFont)

    var currentScreen by remember { mutableStateOf(ScreenTab.NOTES) }
    var editingNoteId by remember { mutableLongStateOf(0L) }

    NetasNotesTheme(
        themeConfig = themeConfig,
        fontFamily = fontFamily
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = themeConfig.backgroundColor,
            bottomBar = {
                // Show bottom navigation only when not in full-screen editor
                if (currentScreen != ScreenTab.EDITOR) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                            .background(MaterialTheme.colorScheme.surface)
                    ) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .navigationBarsPadding()
                                .testTag("main_bottom_nav")
                        ) {
                            NavigationBarItem(
                                selected = currentScreen == ScreenTab.NOTES,
                                onClick = { currentScreen = ScreenTab.NOTES },
                                icon = { Icon(Icons.Default.Description, contentDescription = "Notes") },
                                label = { Text("Notes") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag("nav_notes")
                            )

                            NavigationBarItem(
                                selected = currentScreen == ScreenTab.SEARCH,
                                onClick = { currentScreen = ScreenTab.SEARCH },
                                icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                                label = { Text("Search") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag("nav_search")
                            )

                            NavigationBarItem(
                                selected = currentScreen == ScreenTab.SETTINGS,
                                onClick = { currentScreen = ScreenTab.SETTINGS },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag("nav_settings")
                            )

                            NavigationBarItem(
                                selected = currentScreen == ScreenTab.PROFILE,
                                onClick = { currentScreen = ScreenTab.PROFILE },
                                icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                                label = { Text("Profile") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.testTag("nav_profile")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        bottom = if (currentScreen == ScreenTab.EDITOR) 0.dp else innerPadding.calculateBottomPadding()
                    )
            ) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "ScreenTransition"
                ) { screen ->
                    when (screen) {
                        ScreenTab.NOTES, ScreenTab.SEARCH -> {
                            HomeScreen(
                                onOpenNote = { id ->
                                    editingNoteId = id
                                    currentScreen = ScreenTab.EDITOR
                                },
                                onNavigateToSettings = { currentScreen = ScreenTab.SETTINGS },
                                onNavigateToSearch = { currentScreen = ScreenTab.SEARCH },
                                onNavigateToProfile = { currentScreen = ScreenTab.PROFILE }
                            )
                        }
                        ScreenTab.SETTINGS -> {
                            SettingsScreen(
                                onBack = { currentScreen = ScreenTab.NOTES }
                            )
                        }
                        ScreenTab.PROFILE -> {
                            ProfileScreen(
                                onNavigateToSettings = { currentScreen = ScreenTab.SETTINGS }
                            )
                        }
                        ScreenTab.EDITOR -> {
                            EditorScreen(
                                noteId = editingNoteId,
                                onBack = { currentScreen = ScreenTab.NOTES }
                            )
                        }
                    }
                }
            }
        }
    }
}
