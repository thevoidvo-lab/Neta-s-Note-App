package com.example.ui.editor

import com.example.data.CanvasBackground
import com.example.data.NoteElement

data class CanvasSnapshot(
    val elements: List<NoteElement>,
    val background: CanvasBackground
)

class UndoRedoManager(private val maxHistory: Int = 100) {
    private val undoStack = ArrayDeque<CanvasSnapshot>()
    private val redoStack = ArrayDeque<CanvasSnapshot>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun pushState(elements: List<NoteElement>, background: CanvasBackground) {
        val deepCopy = elements.map { it.copy() }
        undoStack.addLast(CanvasSnapshot(deepCopy, background.copy()))
        if (undoStack.size > maxHistory) {
            undoStack.removeFirst()
        }
        redoStack.clear()
    }

    fun undo(currentElements: List<NoteElement>, currentBg: CanvasBackground): CanvasSnapshot? {
        if (undoStack.isEmpty()) return null
        val previous = undoStack.removeLast()
        redoStack.addLast(CanvasSnapshot(currentElements.map { it.copy() }, currentBg.copy()))
        return previous
    }

    fun redo(currentElements: List<NoteElement>, currentBg: CanvasBackground): CanvasSnapshot? {
        if (redoStack.isEmpty()) return null
        val next = redoStack.removeLast()
        undoStack.addLast(CanvasSnapshot(currentElements.map { it.copy() }, currentBg.copy()))
        return next
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }
}
