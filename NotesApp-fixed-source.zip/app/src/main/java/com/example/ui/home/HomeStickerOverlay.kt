package com.example.ui.home

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.util.HomeStickerItem

@Composable
fun HomeStickerOverlay(
    stickers: List<HomeStickerItem>,
    onUpdateSticker: (HomeStickerItem) -> Unit,
    onGestureEnd: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        stickers.forEach { sticker ->
            Box(
                modifier = Modifier
                    .offset { IntOffset(sticker.x.toInt(), sticker.y.toInt()) }
                    .size(sticker.size.dp)
                    .rotate(sticker.rotation)
                    .pointerInput(sticker.id) {
                        var currentX = sticker.x
                        var currentY = sticker.y
                        detectDragGestures(
                            onDragEnd = { onGestureEnd() },
                            onDragCancel = { onGestureEnd() },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                currentX = (currentX + dragAmount.x).coerceAtLeast(0f)
                                currentY = (currentY + dragAmount.y).coerceAtLeast(0f)
                                onUpdateSticker(sticker.copy(x = currentX, y = currentY))
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                if (sticker.keyOrUri.startsWith("content:") || sticker.keyOrUri.startsWith("file:")) {
                    AsyncImage(
                        model = sticker.keyOrUri,
                        contentDescription = "Home sticker image",
                        modifier = Modifier.size(sticker.size.dp)
                    )
                } else {
                    Text(
                        text = sticker.keyOrUri,
                        fontSize = (sticker.size * 0.7f).sp
                    )
                }
            }
        }
    }
}
