package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import com.example.util.AppThemeConfig

@Composable
fun NetasNotesTheme(
    themeConfig: AppThemeConfig = AppThemeConfig.Presets["Dark"]!!,
    fontFamily: FontFamily = FontFamily.Default,
    content: @Composable () -> Unit
) {
    val isLight = themeConfig.preset == "Light"

    val colorScheme = (if (isLight) lightColorScheme() else darkColorScheme()).copy(
        primary = themeConfig.primaryColor,
        onPrimary = if (isLight) Color.White else Color.Black,
        secondary = themeConfig.secondaryColor,
        onSecondary = if (isLight) Color.Black else Color.Black,
        background = themeConfig.backgroundColor,
        onBackground = themeConfig.textColor,
        surface = themeConfig.surfaceColor,
        onSurface = themeConfig.textColor,
        surfaceVariant = themeConfig.surfaceColor,
        onSurfaceVariant = themeConfig.textSecondaryColor
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = getAppTypography(fontFamily),
        content = content
    )
}
