package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NetaDarkBackground = Color(0xFF121212)
val NetaDarkSurface = Color(0xFF1E1E1E)
val NetaDarkPrimary = Color(0xFFBB86FC)
val NetaDarkSecondary = Color(0xFF03DAC6)
val NetaDarkText = Color(0xFFFFFFFF)
val NetaDarkTextSecondary = Color(0xFFB0B0B0)

val NetaLightBackground = Color(0xFFFAFAFA)
val NetaLightSurface = Color(0xFFFFFFFF)
val NetaLightPrimary = Color(0xFF6200EE)
val NetaLightSecondary = Color(0xFF03DAC6)
val NetaLightText = Color(0xFF000000)
val NetaLightTextSecondary = Color(0xFF757575)

val RedSoft = Color(0xFFCF6679)
val CardBorderDark = Color(0xFF2C2C2C)
