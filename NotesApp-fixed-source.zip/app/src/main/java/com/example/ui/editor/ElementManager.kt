package com.example.ui.editor

import com.example.data.NoteElement
import java.util.UUID

class ElementManager {

    fun createTitleElement(text: String = "Title"): NoteElement {
        return NoteElement(
            id = UUID.randomUUID().toString(),
            type = "title",
            text = text,
            x = 80f,
            y = 120f,
            width = 320f,
            height = 80f,
            fontSize = 28f,
            fontColorHex = "#FFFFFF",
            isBold = true
        )
    }

    fun createTextElement(text: String = "Note something down"): NoteElement {
        return NoteElement(
            id = UUID.randomUUID().toString(),
            type = "text",
            text = text,
            x = 80f,
            y = 220f,
            width = 300f,
            height = 100f,
            fontSize = 18f,
            fontColorHex = "#FFFFFF"
        )
    }

    fun createShapeElement(shapeType: String): NoteElement {
        val width = if (shapeType == "line") 240f else 160f
        val height = if (shapeType == "line") 20f else 160f
        return NoteElement(
            id = UUID.randomUUID().toString(),
            type = "shape",
            shapeType = shapeType,
            x = 100f,
            y = 200f,
            width = width,
            height = height,
            fillColorHex = "#BB86FC",
            borderColorHex = "#FFFFFF",
            borderWidth = 2f,
            cornerRadius = if (shapeType == "rect") 16f else 0f
        )
    }

    fun createStickerElement(stickerKey: String): NoteElement {
        return NoteElement(
            id = UUID.randomUUID().toString(),
            type = "sticker",
            stickerKey = stickerKey,
            x = 120f,
            y = 200f,
            width = 120f,
            height = 120f
        )
    }

    fun createImageElement(imageUri: String): NoteElement {
        return NoteElement(
            id = UUID.randomUUID().toString(),
            type = "image",
            contentUri = imageUri,
            x = 80f,
            y = 180f,
            width = 260f,
            height = 260f
        )
    }

    fun duplicate(element: NoteElement): NoteElement {
        return element.copyElement()
    }

    fun bringForward(list: List<NoteElement>, id: String): List<NoteElement> {
        val index = list.indexOfFirst { it.id == id }
        if (index == -1 || index == list.lastIndex) return list
        val mutable = list.toMutableList()
        val item = mutable.removeAt(index)
        mutable.add(index + 1, item)
        updateZIndices(mutable)
        return mutable
    }

    fun sendBackward(list: List<NoteElement>, id: String): List<NoteElement> {
        val index = list.indexOfFirst { it.id == id }
        if (index <= 0) return list
        val mutable = list.toMutableList()
        val item = mutable.removeAt(index)
        mutable.add(index - 1, item)
        updateZIndices(mutable)
        return mutable
    }

    fun bringToFront(list: List<NoteElement>, id: String): List<NoteElement> {
        val index = list.indexOfFirst { it.id == id }
        if (index == -1 || index == list.lastIndex) return list
        val mutable = list.toMutableList()
        val item = mutable.removeAt(index)
        mutable.add(item)
        updateZIndices(mutable)
        return mutable
    }

    fun sendToBack(list: List<NoteElement>, id: String): List<NoteElement> {
        val index = list.indexOfFirst { it.id == id }
        if (index <= 0) return list
        val mutable = list.toMutableList()
        val item = mutable.removeAt(index)
        mutable.add(0, item)
        updateZIndices(mutable)
        return mutable
    }

    private fun updateZIndices(list: MutableList<NoteElement>) {
        list.forEachIndexed { i, elem ->
            elem.zIndex = i
        }
    }
}
