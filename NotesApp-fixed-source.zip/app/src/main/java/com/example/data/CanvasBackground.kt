package com.example.data

import org.json.JSONObject

data class CanvasBackground(
    val type: String = "SOLID", // "SOLID", "GRADIENT", "IMAGE"
    val colorHex: String = "#121212",
    val secondaryColorHex: String = "#1E1E1E",
    val gradientAngle: Float = 0f,
    val imageUri: String = "",
    val blurRadius: Float = 0f,
    val opacity: Float = 1f
) {
    fun toJsonObject(): JSONObject {
        val obj = JSONObject()
        obj.put("type", type)
        obj.put("colorHex", colorHex)
        obj.put("secondaryColorHex", secondaryColorHex)
        obj.put("gradientAngle", gradientAngle.toDouble())
        obj.put("imageUri", imageUri)
        obj.put("blurRadius", blurRadius.toDouble())
        obj.put("opacity", opacity.toDouble())
        return obj
    }

    companion object {
        fun fromJsonObject(obj: JSONObject?): CanvasBackground {
            if (obj == null) return CanvasBackground()
            return CanvasBackground(
                type = obj.optString("type", "SOLID"),
                colorHex = obj.optString("colorHex", "#121212"),
                secondaryColorHex = obj.optString("secondaryColorHex", "#1E1E1E"),
                gradientAngle = obj.optDouble("gradientAngle", 0.0).toFloat(),
                imageUri = obj.optString("imageUri", ""),
                blurRadius = obj.optDouble("blurRadius", 0.0).toFloat(),
                opacity = obj.optDouble("opacity", 1.0).toFloat()
            )
        }

        fun fromJsonString(jsonStr: String): CanvasBackground {
            if (jsonStr.isBlank()) return CanvasBackground()
            return try {
                fromJsonObject(JSONObject(jsonStr))
            } catch (e: Exception) {
                CanvasBackground()
            }
        }
    }
}
