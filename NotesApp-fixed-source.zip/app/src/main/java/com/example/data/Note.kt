package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String = "Untitled Note",
    val contentPreview: String = "",
    val elementsJson: String = "[]",
    val canvasBgJson: String = "{}",
    val isPinned: Boolean = false,
    val isLocked: Boolean = false,
    val category: String = "General",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
