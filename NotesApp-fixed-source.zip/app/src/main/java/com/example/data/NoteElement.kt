package com.example.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Freeform element placed on the Editor canvas.
 */
data class NoteElement(
    val id: String = UUID.randomUUID().toString(),
    val type: String = "text", // "title", "text", "sticker", "image", "shape"
    var x: Float = 100f,
    var y: Float = 100f,
    var width: Float = 200f,
    var height: Float = 100f,
    var rotation: Float = 0f,
    var scale: Float = 1f,
    var zIndex: Int = 0,
    var isLocked: Boolean = false,
    var isHidden: Boolean = false,

    // Text attributes
    var text: String = "",
    var fontFamily: String = "Default",
    var fontSize: Float = 18f,
    var fontColorHex: String = "#FFFFFF",
    var isBold: Boolean = false,
    var isItalic: Boolean = false,
    var isUnderline: Boolean = false,
    var textAlign: String = "LEFT", // "LEFT", "CENTER", "RIGHT"
    var lineSpacing: Float = 1.2f,

    // Shape attributes: "rect", "circle", "line", "arrow", "triangle", "star"
    var shapeType: String = "rect",
    var fillColorHex: String = "#BB86FC",
    var borderColorHex: String = "#FFFFFF",
    var borderWidth: Float = 2f,
    var cornerRadius: Float = 16f,
    var opacity: Float = 1f,

    // Sticker / Image attributes
    var contentUri: String = "",
    var stickerKey: String = ""
) {
    fun copyElement(): NoteElement = this.copy(
        id = UUID.randomUUID().toString(),
        x = x + 24f,
        y = y + 24f
    )

    fun toJsonObject(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("type", type)
        obj.put("x", x.toDouble())
        obj.put("y", y.toDouble())
        obj.put("width", width.toDouble())
        obj.put("height", height.toDouble())
        obj.put("rotation", rotation.toDouble())
        obj.put("scale", scale.toDouble())
        obj.put("zIndex", zIndex)
        obj.put("isLocked", isLocked)
        obj.put("isHidden", isHidden)
        obj.put("text", text)
        obj.put("fontFamily", fontFamily)
        obj.put("fontSize", fontSize.toDouble())
        obj.put("fontColorHex", fontColorHex)
        obj.put("isBold", isBold)
        obj.put("isItalic", isItalic)
        obj.put("isUnderline", isUnderline)
        obj.put("textAlign", textAlign)
        obj.put("lineSpacing", lineSpacing.toDouble())
        obj.put("shapeType", shapeType)
        obj.put("fillColorHex", fillColorHex)
        obj.put("borderColorHex", borderColorHex)
        obj.put("borderWidth", borderWidth.toDouble())
        obj.put("cornerRadius", cornerRadius.toDouble())
        obj.put("opacity", opacity.toDouble())
        obj.put("contentUri", contentUri)
        obj.put("stickerKey", stickerKey)
        return obj
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): NoteElement {
            return NoteElement(
                id = obj.optString("id", UUID.randomUUID().toString()),
                type = obj.optString("type", "text"),
                x = obj.optDouble("x", 100.0).toFloat(),
                y = obj.optDouble("y", 100.0).toFloat(),
                width = obj.optDouble("width", 200.0).toFloat(),
                height = obj.optDouble("height", 100.0).toFloat(),
                rotation = obj.optDouble("rotation", 0.0).toFloat(),
                scale = obj.optDouble("scale", 1.0).toFloat(),
                zIndex = obj.optInt("zIndex", 0),
                isLocked = obj.optBoolean("isLocked", false),
                isHidden = obj.optBoolean("isHidden", false),
                text = obj.optString("text", ""),
                fontFamily = obj.optString("fontFamily", "Default"),
                fontSize = obj.optDouble("fontSize", 18.0).toFloat(),
                fontColorHex = obj.optString("fontColorHex", "#FFFFFF"),
                isBold = obj.optBoolean("isBold", false),
                isItalic = obj.optBoolean("isItalic", false),
                isUnderline = obj.optBoolean("isUnderline", false),
                textAlign = obj.optString("textAlign", "LEFT"),
                lineSpacing = obj.optDouble("lineSpacing", 1.2).toFloat(),
                shapeType = obj.optString("shapeType", "rect"),
                fillColorHex = obj.optString("fillColorHex", "#BB86FC"),
                borderColorHex = obj.optString("borderColorHex", "#FFFFFF"),
                borderWidth = obj.optDouble("borderWidth", 2.0).toFloat(),
                cornerRadius = obj.optDouble("cornerRadius", 16.0).toFloat(),
                opacity = obj.optDouble("opacity", 1.0).toFloat(),
                contentUri = obj.optString("contentUri", ""),
                stickerKey = obj.optString("stickerKey", "")
            )
        }

        fun listToJsonString(elements: List<NoteElement>): String {
            val array = JSONArray()
            for (element in elements) {
                array.put(element.toJsonObject())
            }
            return array.toString()
        }

        fun listFromJsonString(jsonStr: String): List<NoteElement> {
            val list = mutableListOf<NoteElement>()
            if (jsonStr.isBlank()) return list
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(fromJsonObject(obj))
                }
            } catch (e: Exception) {
                // Fallback to empty list on corrupt JSON
            }
            return list
        }
    }
}
