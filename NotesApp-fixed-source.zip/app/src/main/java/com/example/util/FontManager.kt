package com.example.util

import android.content.Context
import androidx.compose.ui.text.font.FontFamily
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.fontDataStore by preferencesDataStore(name = "neta_font_settings")

object FontManager {
    private val FONT_KEY = stringPreferencesKey("home_font")

    val AvailableFonts = listOf(
        "Default" to FontFamily.Default,
        "Sans-Serif" to FontFamily.SansSerif,
        "Serif" to FontFamily.Serif,
        "Monospace" to FontFamily.Monospace,
        "Cursive" to FontFamily.Cursive
    )

    fun getFontFamily(fontName: String): FontFamily {
        return AvailableFonts.find { it.first.equals(fontName, ignoreCase = true) }?.second
            ?: FontFamily.Default
    }

    fun getSavedFont(context: Context): Flow<String> {
        return context.fontDataStore.data.map { prefs ->
            prefs[FONT_KEY] ?: "Default"
        }
    }

    suspend fun saveFont(context: Context, fontName: String) {
        context.fontDataStore.edit { prefs ->
            prefs[FONT_KEY] = fontName
        }
    }
}
