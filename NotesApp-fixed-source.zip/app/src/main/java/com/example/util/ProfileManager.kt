package com.example.util

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Context.profileDataStore by preferencesDataStore(name = "neta_profile_settings")

data class ProfilePost(
    val id: String = UUID.randomUUID().toString(),
    val content: String = "",
    val imageUri: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false
) {
    fun toJsonObject(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("content", content)
        obj.put("imageUri", imageUri)
        obj.put("timestamp", timestamp)
        obj.put("isArchived", isArchived)
        return obj
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): ProfilePost {
            return ProfilePost(
                id = obj.optString("id", UUID.randomUUID().toString()),
                content = obj.optString("content", ""),
                imageUri = obj.optString("imageUri", ""),
                timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                isArchived = obj.optBoolean("isArchived", false)
            )
        }
    }
}

data class ProfileInfo(
    val name: String = "Rurushaa",
    val username: String = "@Amertaaaaaaaa",
    val status: String = "online",
    val avatarUri: String = "",
    val posts: List<ProfilePost> = emptyList()
)

class ProfileManager(private val context: Context) {
    private val KEY_NAME = stringPreferencesKey("profile_name")
    private val KEY_USERNAME = stringPreferencesKey("profile_username")
    private val KEY_STATUS = stringPreferencesKey("profile_status")
    private val KEY_AVATAR = stringPreferencesKey("profile_avatar")
    private val KEY_POSTS = stringPreferencesKey("profile_posts")

    val profileFlow: Flow<ProfileInfo> = context.profileDataStore.data.map { prefs ->
        val name = prefs[KEY_NAME]?.ifBlank { "Rurushaa" } ?: "Rurushaa"
        val username = prefs[KEY_USERNAME]?.ifBlank { "@Amertaaaaaaaa" } ?: "@Amertaaaaaaaa"
        val status = prefs[KEY_STATUS]?.ifBlank { "online" } ?: "online"
        val avatar = prefs[KEY_AVATAR] ?: ""
        val postsJson = prefs[KEY_POSTS]
        val postList = mutableListOf<ProfilePost>()
        if (!postsJson.isNullOrBlank()) {
            try {
                val array = JSONArray(postsJson)
                for (i in 0 until array.length()) {
                    postList.add(ProfilePost.fromJsonObject(array.getJSONObject(i)))
                }
            } catch (e: Exception) {
                // Ignore parse errors
            }
        }
        ProfileInfo(name, username, status, avatar, postList)
    }

    suspend fun updateInfo(name: String, username: String, status: String) {
        context.profileDataStore.edit { prefs ->
            prefs[KEY_NAME] = if (name.isBlank()) "Rurushaa" else name.trim()
            prefs[KEY_USERNAME] = if (username.isBlank()) "@Amertaaaaaaaa" else username.trim()
            prefs[KEY_STATUS] = if (status.isBlank()) "online" else status.trim()
        }
    }

    suspend fun updateAvatar(uri: String) {
        context.profileDataStore.edit { prefs ->
            prefs[KEY_AVATAR] = uri
        }
    }

    suspend fun addPost(content: String, imageUri: String) {
        context.profileDataStore.edit { prefs ->
            val postsJson = prefs[KEY_POSTS]
            val postList = mutableListOf<ProfilePost>()
            if (!postsJson.isNullOrBlank()) {
                try {
                    val array = JSONArray(postsJson)
                    for (i in 0 until array.length()) {
                        postList.add(ProfilePost.fromJsonObject(array.getJSONObject(i)))
                    }
                } catch (e: Exception) { }
            }
            postList.add(0, ProfilePost(content = content, imageUri = imageUri))
            val array = JSONArray()
            postList.forEach { array.put(it.toJsonObject()) }
            prefs[KEY_POSTS] = array.toString()
        }
    }

    suspend fun toggleArchivePost(postId: String) {
        context.profileDataStore.edit { prefs ->
            val postsJson = prefs[KEY_POSTS] ?: return@edit
            val array = JSONArray(postsJson)
            val updated = JSONArray()
            for (i in 0 until array.length()) {
                val post = ProfilePost.fromJsonObject(array.getJSONObject(i))
                if (post.id == postId) {
                    updated.put(post.copy(isArchived = !post.isArchived).toJsonObject())
                } else {
                    updated.put(post.toJsonObject())
                }
            }
            prefs[KEY_POSTS] = updated.toString()
        }
    }
}
