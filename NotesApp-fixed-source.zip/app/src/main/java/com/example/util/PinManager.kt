package com.example.util

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

class PinManager(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("neta_pin_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_FAILED_ATTEMPTS = "pin_failed_attempts"
        const val MAX_ATTEMPTS = 5
    }

    fun isPinSet(): Boolean {
        return prefs.getString(KEY_PIN_HASH, null) != null
    }

    fun setPin(pin: String) {
        val salt = System.currentTimeMillis().toString()
        val hash = hashPin(pin, salt)
        prefs.edit()
            .putString(KEY_PIN_HASH, hash)
            .putString(KEY_PIN_SALT, salt)
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .apply()
    }

    fun removePin() {
        prefs.edit()
            .remove(KEY_PIN_HASH)
            .remove(KEY_PIN_SALT)
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .apply()
    }

    fun verifyPin(enteredPin: String): Boolean {
        val savedHash = prefs.getString(KEY_PIN_HASH, null) ?: return true
        val salt = prefs.getString(KEY_PIN_SALT, "") ?: ""
        val hash = hashPin(enteredPin, salt)
        if (hash == savedHash) {
            resetAttempts()
            return true
        } else {
            incrementAttempts()
            return false
        }
    }

    fun getFailedAttempts(): Int {
        return prefs.getInt(KEY_FAILED_ATTEMPTS, 0)
    }

    fun getRemainingAttempts(): Int {
        return (MAX_ATTEMPTS - getFailedAttempts()).coerceAtLeast(0)
    }

    fun isLockedOut(): Boolean {
        return getFailedAttempts() >= MAX_ATTEMPTS
    }

    private fun incrementAttempts() {
        val current = getFailedAttempts()
        prefs.edit().putInt(KEY_FAILED_ATTEMPTS, current + 1).apply()
    }

    fun resetAttempts() {
        prefs.edit().putInt(KEY_FAILED_ATTEMPTS, 0).apply()
    }

    private fun hashPin(pin: String, salt: String): String {
        val combined = "$pin:$salt:netas_secret_key"
        val bytes = MessageDigest.getInstance("SHA-256").digest(combined.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
