package com.example.util

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.themeDataStore by preferencesDataStore(name = "neta_theme_settings")

data class AppThemeConfig(
    val preset: String = "Dark", // Light, Dark, Ocean, Forest, Sunset, Neon, Minimal, Custom
    val primaryHex: String = "#BB86FC",
    val secondaryHex: String = "#03DAC6",
    val backgroundHex: String = "#121212",
    val surfaceHex: String = "#1E1E1E",
    val textHex: String = "#FFFFFF",
    val textSecondaryHex: String = "#B0B0B0"
) {
    fun toColor(hex: String, fallback: Color): Color {
        return try {
            val cleanHex = hex.removePrefix("#")
            val colorInt = cleanHex.toLong(16)
            if (cleanHex.length == 6) {
                Color(colorInt or 0x00000000FF000000)
            } else {
                Color(colorInt)
            }
        } catch (e: Exception) {
            fallback
        }
    }

    val primaryColor: Color get() = toColor(primaryHex, Color(0xFFBB86FC))
    val secondaryColor: Color get() = toColor(secondaryHex, Color(0xFF03DAC6))
    val backgroundColor: Color get() = toColor(backgroundHex, Color(0xFF121212))
    val surfaceColor: Color get() = toColor(surfaceHex, Color(0xFF1E1E1E))
    val textColor: Color get() = toColor(textHex, Color(0xFFFFFFFF))
    val textSecondaryColor: Color get() = toColor(textSecondaryHex, Color(0xFFB0B0B0))

    fun toJsonString(): String {
        val obj = JSONObject()
        obj.put("preset", preset)
        obj.put("primaryHex", primaryHex)
        obj.put("secondaryHex", secondaryHex)
        obj.put("backgroundHex", backgroundHex)
        obj.put("surfaceHex", surfaceHex)
        obj.put("textHex", textHex)
        obj.put("textSecondaryHex", textSecondaryHex)
        return obj.toString()
    }

    companion object {
        val Presets = mapOf(
            "Dark" to AppThemeConfig(
                preset = "Dark",
                primaryHex = "#BB86FC",
                secondaryHex = "#03DAC6",
                backgroundHex = "#121212",
                surfaceHex = "#1E1E1E",
                textHex = "#FFFFFF",
                textSecondaryHex = "#B0B0B0"
            ),
            "Light" to AppThemeConfig(
                preset = "Light",
                primaryHex = "#6200EE",
                secondaryHex = "#03DAC6",
                backgroundHex = "#FAFAFA",
                surfaceHex = "#FFFFFF",
                textHex = "#000000",
                textSecondaryHex = "#757575"
            ),
            "Ocean" to AppThemeConfig(
                preset = "Ocean",
                primaryHex = "#00B4D8",
                secondaryHex = "#90E0EF",
                backgroundHex = "#03045E",
                surfaceHex = "#0077B6",
                textHex = "#CAF0F8",
                textSecondaryHex = "#90E0EF"
            ),
            "Forest" to AppThemeConfig(
                preset = "Forest",
                primaryHex = "#52B788",
                secondaryHex = "#74C69D",
                backgroundHex = "#081C15",
                surfaceHex = "#1B4332",
                textHex = "#D8F3DC",
                textSecondaryHex = "#95D5B2"
            ),
            "Sunset" to AppThemeConfig(
                preset = "Sunset",
                primaryHex = "#FF7B00",
                secondaryHex = "#FFB703",
                backgroundHex = "#240046",
                surfaceHex = "#3C096C",
                textHex = "#FFE5B4",
                textSecondaryHex = "#FF9E00"
            ),
            "Neon" to AppThemeConfig(
                preset = "Neon",
                primaryHex = "#FF007F",
                secondaryHex = "#00F5D4",
                backgroundHex = "#0D0221",
                surfaceHex = "#190933",
                textHex = "#FFFFFF",
                textSecondaryHex = "#D1B3FF"
            ),
            "Minimal" to AppThemeConfig(
                preset = "Minimal",
                primaryHex = "#E0E0E0",
                secondaryHex = "#9E9E9E",
                backgroundHex = "#181818",
                surfaceHex = "#242424",
                textHex = "#EEEEEE",
                textSecondaryHex = "#888888"
            )
        )

        fun fromJsonString(jsonStr: String?): AppThemeConfig {
            if (jsonStr.isNullOrBlank()) return Presets["Dark"]!!
            return try {
                val obj = JSONObject(jsonStr)
                AppThemeConfig(
                    preset = obj.optString("preset", "Dark"),
                    primaryHex = obj.optString("primaryHex", "#BB86FC"),
                    secondaryHex = obj.optString("secondaryHex", "#03DAC6"),
                    backgroundHex = obj.optString("backgroundHex", "#121212"),
                    surfaceHex = obj.optString("surfaceHex", "#1E1E1E"),
                    textHex = obj.optString("textHex", "#FFFFFF"),
                    textSecondaryHex = obj.optString("textSecondaryHex", "#B0B0B0")
                )
            } catch (e: Exception) {
                Presets["Dark"]!!
            }
        }
    }
}

class ThemeManager(private val context: Context) {
    private val themeKey = stringPreferencesKey("theme")

    val themeFlow: Flow<AppThemeConfig> = context.themeDataStore.data.map { prefs ->
        AppThemeConfig.fromJsonString(prefs[themeKey])
    }

    suspend fun savePreset(presetName: String) {
        val config = AppThemeConfig.Presets[presetName] ?: AppThemeConfig.Presets["Dark"]!!
        context.themeDataStore.edit { prefs ->
            prefs[themeKey] = config.toJsonString()
        }
    }

    suspend fun saveCustomTheme(
        primaryHex: String,
        secondaryHex: String,
        backgroundHex: String,
        surfaceHex: String = "#1E1E1E",
        textHex: String = "#FFFFFF",
        textSecondaryHex: String = "#B0B0B0"
    ) {
        val config = AppThemeConfig(
            preset = "Custom",
            primaryHex = primaryHex,
            secondaryHex = secondaryHex,
            backgroundHex = backgroundHex,
            surfaceHex = surfaceHex,
            textHex = textHex,
            textSecondaryHex = textSecondaryHex
        )
        context.themeDataStore.edit { prefs ->
            prefs[themeKey] = config.toJsonString()
        }
    }
}
