package com.example.util

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.CanvasBackground
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Context.homeCustomDataStore by preferencesDataStore(name = "neta_home_custom")

data class HomeStickerItem(
    val id: String = UUID.randomUUID().toString(),
    val keyOrUri: String = "✨",
    var x: Float = 150f,
    var y: Float = 250f,
    var size: Float = 48f,
    var rotation: Float = 0f
) {
    fun toJsonObject(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("keyOrUri", keyOrUri)
        obj.put("x", x.toDouble())
        obj.put("y", y.toDouble())
        obj.put("size", size.toDouble())
        obj.put("rotation", rotation.toDouble())
        return obj
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): HomeStickerItem {
            return HomeStickerItem(
                id = obj.optString("id", UUID.randomUUID().toString()),
                keyOrUri = obj.optString("keyOrUri", "✨"),
                x = obj.optDouble("x", 150.0).toFloat(),
                y = obj.optDouble("y", 250.0).toFloat(),
                size = obj.optDouble("size", 48.0).toFloat(),
                rotation = obj.optDouble("rotation", 0.0).toFloat()
            )
        }
    }
}

class HomeCustomizer(private val context: Context) {
    private val KEY_HOME_TITLE = stringPreferencesKey("home_title")
    private val KEY_HOME_BG = stringPreferencesKey("home_bg")
    private val KEY_HOME_STICKERS = stringPreferencesKey("home_stickers")

    val homeTitleFlow: Flow<String> = context.homeCustomDataStore.data.map { prefs ->
        val raw = prefs[KEY_HOME_TITLE]
        if (raw.isNullOrBlank()) "Neta's Notes" else raw.take(30)
    }

    val homeBgFlow: Flow<CanvasBackground> = context.homeCustomDataStore.data.map { prefs ->
        val raw = prefs[KEY_HOME_BG]
        if (raw.isNullOrBlank()) {
            CanvasBackground(type = "SOLID", colorHex = "#121212")
        } else {
            CanvasBackground.fromJsonString(raw)
        }
    }

    val homeStickersFlow: Flow<List<HomeStickerItem>> = context.homeCustomDataStore.data.map { prefs ->
        val raw = prefs[KEY_HOME_STICKERS]
        val list = mutableListOf<HomeStickerItem>()
        if (!raw.isNullOrBlank()) {
            try {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    list.add(HomeStickerItem.fromJsonObject(array.getJSONObject(i)))
                }
            } catch (e: Exception) {
                // Ignore corrupt sticker JSON
            }
        }
        list
    }

    suspend fun saveHomeTitle(title: String) {
        val clean = if (title.isBlank()) "Neta's Notes" else title.trim().take(30)
        context.homeCustomDataStore.edit { prefs ->
            prefs[KEY_HOME_TITLE] = clean
        }
    }

    suspend fun saveHomeBg(bg: CanvasBackground) {
        context.homeCustomDataStore.edit { prefs ->
            prefs[KEY_HOME_BG] = bg.toJsonObject().toString()
        }
    }

    suspend fun saveHomeStickers(stickers: List<HomeStickerItem>) {
        val array = JSONArray()
        stickers.forEach { array.put(it.toJsonObject()) }
        context.homeCustomDataStore.edit { prefs ->
            prefs[KEY_HOME_STICKERS] = array.toString()
        }
    }
}
