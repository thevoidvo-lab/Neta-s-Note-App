package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.ui.graphics.Color
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object ImageHelper {
    private val AVATAR_COLORS = listOf(
        Color(0xFFE91E63),
        Color(0xFF9C27B0),
        Color(0xFF673AB7),
        Color(0xFF3F51B5),
        Color(0xFF2196F3),
        Color(0xFF009688),
        Color(0xFF4CAF50),
        Color(0xFFFF9800),
        Color(0xFFFF5722),
        Color(0xFF795548)
    )

    fun getColorForString(input: String): Color {
        if (input.isEmpty()) return AVATAR_COLORS[0]
        val hash = input.hashCode().let { if (it < 0) -it else it }
        return AVATAR_COLORS[hash % AVATAR_COLORS.size]
    }

    fun getInitial(title: String): String {
        val trimmed = title.trim()
        if (trimmed.isEmpty()) return "N"
        return trimmed.take(1).uppercase()
    }

    fun copyUriToInternalStorage(context: Context, uri: Uri): String {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return uri.toString()
            val fileName = "neta_img_${UUID.randomUUID()}.png"
            val file = File(context.filesDir, fileName)
            val outputStream = FileOutputStream(file)
            inputStream.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            Uri.fromFile(file).toString()
        } catch (e: Exception) {
            uri.toString()
        }
    }
}
