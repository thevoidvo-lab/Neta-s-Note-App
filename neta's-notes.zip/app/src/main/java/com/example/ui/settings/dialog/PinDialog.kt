package com.example.ui.settings.dialog

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.PinManager

@Composable
fun PinDialog(
    title: String = "Masukkan PIN",
    pinManager: PinManager,
    isSettingNewPin: Boolean = false,
    onSuccess: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var enteredPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        shape = RoundedCornerShape(24.dp),
        title = {
            Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = enteredPin,
                    onValueChange = {
                        if (it.length <= 6 && it.all { ch -> ch.isDigit() }) {
                            enteredPin = it
                            errorMessage = ""
                        }
                    },
                    label = { Text(if (isSettingNewPin) "PIN Baru (4-6 digit angka)" else "PIN", color = Color.Gray) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFBB86FC),
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (isSettingNewPin) {
                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = {
                            if (it.length <= 6 && it.all { ch -> ch.isDigit() }) {
                                confirmPin = it
                                errorMessage = ""
                            }
                        },
                        label = { Text("Konfirmasi PIN", color = Color.Gray) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFBB86FC),
                            unfocusedBorderColor = Color.Gray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (errorMessage.isNotEmpty()) {
                    Text(text = errorMessage, color = Color(0xFFCF6679), fontSize = 13.sp)
                }

                if (!isSettingNewPin && pinManager.isPinSet()) {
                    val remaining = pinManager.getRemainingAttempts()
                    Text(
                        text = "Sisa percobaan: $remaining / ${PinManager.MAX_ATTEMPTS}",
                        color = Color(0xFFB0B0B0),
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isSettingNewPin) {
                        if (enteredPin.length < 4) {
                            errorMessage = "PIN minimal 4 digit angka!"
                        } else if (enteredPin != confirmPin) {
                            errorMessage = "Konfirmasi PIN tidak cocok!"
                        } else {
                            pinManager.setPin(enteredPin)
                            Toast.makeText(context, "PIN berhasil disimpan!", Toast.LENGTH_SHORT).show()
                            onSuccess()
                        }
                    } else {
                        // Verify PIN
                        if (!pinManager.isPinSet()) {
                            // If no PIN set, allow opening
                            onSuccess()
                        } else {
                            val verified = pinManager.verifyPin(enteredPin)
                            if (verified) {
                                onSuccess()
                            } else {
                                if (pinManager.isLockedOut()) {
                                    Toast.makeText(context, "PIN salah 5x! Aplikasi ditutup demi keamanan.", Toast.LENGTH_LONG).show()
                                    (context as? Activity)?.finishAffinity()
                                } else {
                                    errorMessage = "PIN salah! Sisa percobaan: ${pinManager.getRemainingAttempts()}"
                                }
                            }
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
            ) {
                Text(if (isSettingNewPin) "Simpan PIN" else "Buka", color = Color.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal", color = Color.Gray)
            }
        }
    )
}
