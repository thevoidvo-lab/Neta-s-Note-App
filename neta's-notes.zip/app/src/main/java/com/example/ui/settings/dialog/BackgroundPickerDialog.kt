package com.example.ui.settings.dialog

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CanvasBackground
import com.example.ui.editor.parseHexColor
import com.example.util.ImageHelper

@Composable
fun BackgroundPickerDialog(
    currentBg: CanvasBackground,
    onSaveBg: (CanvasBackground) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedType by remember { mutableStateOf(currentBg.type) }
    var selectedColor by remember { mutableStateOf(currentBg.colorHex) }
    var selectedSecondaryColor by remember { mutableStateOf(currentBg.secondaryColorHex) }
    var selectedImageUri by remember { mutableStateOf(currentBg.imageUri) }
    var blurRadius by remember { mutableFloatStateOf(currentBg.blurRadius) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val saved = ImageHelper.copyUriToInternalStorage(context, it)
            selectedImageUri = saved
            selectedType = "IMAGE"
        }
    }

    val solidPresets = listOf("#121212", "#1E1E1E", "#1A1A2E", "#0F3460", "#1B4332", "#240046", "#03045E")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        shape = RoundedCornerShape(24.dp),
        title = {
            Text("Kustomisasi Background Home", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Warna Solid:", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(solidPresets) { hex ->
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(parseHexColor(hex, Color.Black))
                                .border(
                                    width = if (selectedColor == hex && selectedType == "SOLID") 2.dp else 1.dp,
                                    color = if (selectedColor == hex && selectedType == "SOLID") Color(0xFFBB86FC) else Color.Gray,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    selectedColor = hex
                                    selectedType = "SOLID"
                                }
                        )
                    }
                }

                Text("Gradien:", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            selectedType = "GRADIENT"
                            selectedColor = "#121212"
                            selectedSecondaryColor = "#3C096C"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2C))
                    ) {
                        Text("Dark Purple", color = Color.White)
                    }

                    Button(
                        onClick = {
                            selectedType = "GRADIENT"
                            selectedColor = "#03045E"
                            selectedSecondaryColor = "#0077B6"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2C))
                    ) {
                        Text("Ocean Deep", color = Color.White)
                    }
                }

                Text("Gambar Galeri:", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                ) {
                    Text(if (selectedImageUri.isNotBlank()) "Ganti Foto Background" else "Pilih Foto dari Galeri", color = Color.Black)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Efek Blur: ${blurRadius.toInt()}dp", color = Color.White, fontSize = 13.sp)
                    Spacer(modifier = Modifier.size(8.dp))
                    Slider(
                        value = blurRadius,
                        onValueChange = { blurRadius = it },
                        valueRange = 0f..25f,
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = Color(0xFFBB86FC), activeTrackColor = Color(0xFFBB86FC))
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = CanvasBackground(
                        type = selectedType,
                        colorHex = selectedColor,
                        secondaryColorHex = selectedSecondaryColor,
                        imageUri = selectedImageUri,
                        blurRadius = blurRadius
                    )
                    onSaveBg(updated)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
            ) {
                Text("Simpan", color = Color.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal", color = Color.Gray)
            }
        }
    )
}
