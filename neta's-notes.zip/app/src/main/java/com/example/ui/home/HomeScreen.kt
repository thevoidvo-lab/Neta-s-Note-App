package com.example.ui.home

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Note
import com.example.data.NoteDatabase
import com.example.ui.editor.CanvasBackgroundLayer
import com.example.ui.settings.dialog.PinDialog
import com.example.util.HomeCustomizer
import com.example.util.PinManager
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    onOpenNote: (Long) -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToSearch: () -> Unit,
    onNavigateToProfile: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val noteDao = remember { NoteDatabase.getDatabase(context).noteDao() }
    val homeCustomizer = remember { HomeCustomizer(context) }
    val pinManager = remember { PinManager(context) }

    val homeTitle by homeCustomizer.homeTitleFlow.collectAsState(initial = "Neta's Notes")
    val homeBg by homeCustomizer.homeBgFlow.collectAsState(initial = com.example.data.CanvasBackground())
    val homeStickers by homeCustomizer.homeStickersFlow.collectAsState(initial = emptyList())
    val notesList by noteDao.getAllNotes().collectAsState(initial = emptyList())

    var searchQuery by remember { mutableStateOf("") }
    var showSearchBar by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("Semua") } // "Semua", "Pinned", "Locked", "Kategori"
    var showMenuDropdown by remember { mutableStateOf(false) }

    // Dialog state for locked note PIN verification
    var noteToUnlock by remember { mutableStateOf<Note?>(null) }
    var showUnlockPinDialog by remember { mutableStateOf(false) }

    // Dialog state for long press action on note
    var selectedNoteForAction by remember { mutableStateOf<Note?>(null) }
    var showActionMenuDialog by remember { mutableStateOf(false) }

    val filteredNotes = notesList.filter { note ->
        val matchesSearch = if (searchQuery.isBlank()) true else {
            note.title.contains(searchQuery, ignoreCase = true) ||
                    note.contentPreview.contains(searchQuery, ignoreCase = true)
        }
        val matchesFilter = when (selectedFilter) {
            "Pinned" -> note.isPinned
            "Locked" -> note.isLocked
            "Kategori" -> true
            else -> true
        }
        matchesSearch && matchesFilter
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        // Custom background layer
        CanvasBackgroundLayer(background = homeBg)

        // Custom stickers overlay on home
        HomeStickerOverlay(
            stickers = homeStickers,
            onUpdateSticker = { updated ->
                scope.launch {
                    val updatedList = homeStickers.map { if (it.id == updated.id) updated else it }
                    homeCustomizer.saveHomeStickers(updatedList)
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // HEADER
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = homeTitle,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { showSearchBar = !showSearchBar },
                        modifier = Modifier.testTag("home_search_toggle")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search Notes",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Box {
                        IconButton(
                            onClick = { showMenuDropdown = true },
                            modifier = Modifier.testTag("home_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Menu",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenuDropdown,
                            onDismissRequest = { showMenuDropdown = false },
                            modifier = Modifier.background(Color(0xFF1E1E1E))
                        ) {
                            DropdownMenuItem(
                                text = { Text("Catatan Baru", color = Color.White) },
                                onClick = {
                                    showMenuDropdown = false
                                    onOpenNote(0L)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Pengaturan", color = Color.White) },
                                onClick = {
                                    showMenuDropdown = false
                                    onNavigateToSettings()
                                }
                            )
                        }
                    }
                }
            }

            // SEARCH BAR
            if (showSearchBar) {
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Cari catatan...", color = Color(0xFFB0B0B0)) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.Gray)
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF1E1E1E),
                            unfocusedContainerColor = Color(0xFF1E1E1E),
                            focusedBorderColor = Color(0xFFBB86FC),
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_search_input")
                    )
                }
            }

            // FILTER CHIPS
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf("Semua", "Pinned", "Locked", "Kategori")
                items(filters) { filter ->
                    val isSelected = selectedFilter == filter
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) Color(0xFFBB86FC) else Color(0xFF1E1E1E))
                            .clickable { selectedFilter = filter }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("filter_chip_$filter"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = filter,
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // NOTES LIST OR EMPTY STATE
            if (filteredNotes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = "Empty Notes",
                            tint = Color(0xFFB0B0B0),
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = "Belum ada catatan. Tap + buat mulai",
                            color = Color(0xFFB0B0B0),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredNotes, key = { it.id }) { note ->
                        NoteItem(
                            note = note,
                            onClick = {
                                if (note.isLocked) {
                                    noteToUnlock = note
                                    showUnlockPinDialog = true
                                } else {
                                    onOpenNote(note.id)
                                }
                            },
                            onLongClick = {
                                selectedNoteForAction = note
                                showActionMenuDialog = true
                            }
                        )
                    }
                }
            }
        }

        // FAB (+)
        FloatingActionButton(
            onClick = { onOpenNote(0L) },
            containerColor = Color(0xFFBB86FC),
            contentColor = Color.Black,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 80.dp, end = 20.dp)
                .testTag("add_note_fab")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Buat Catatan Baru",
                modifier = Modifier.size(28.dp)
            )
        }

        // UNLOCK PIN DIALOG
        if (showUnlockPinDialog && noteToUnlock != null) {
            PinDialog(
                title = "Masukkan PIN untuk Membuka Catatan",
                pinManager = pinManager,
                onSuccess = {
                    val noteId = noteToUnlock?.id ?: 0L
                    showUnlockPinDialog = false
                    noteToUnlock = null
                    onOpenNote(noteId)
                },
                onDismiss = {
                    showUnlockPinDialog = false
                    noteToUnlock = null
                }
            )
        }

        // ACTION MENU DIALOG (Long press on note)
        if (showActionMenuDialog && selectedNoteForAction != null) {
            val note = selectedNoteForAction!!
            AlertDialog(
                onDismissRequest = { showActionMenuDialog = false },
                containerColor = Color(0xFF1E1E1E),
                title = { Text(note.title, color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = {
                                scope.launch {
                                    noteDao.updateNote(note.copy(isPinned = !note.isPinned))
                                    showActionMenuDialog = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PushPin, contentDescription = null, tint = Color(0xFFBB86FC))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(if (note.isPinned) "Lepas Sematan (Unpin)" else "Sematkan (Pin)", color = Color.White)
                            }
                        }

                        TextButton(
                            onClick = {
                                scope.launch {
                                    noteDao.updateNote(note.copy(isLocked = !note.isLocked))
                                    showActionMenuDialog = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (note.isLocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = Color(0xFF03DAC6)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(if (note.isLocked) "Buka Kunci (Unlock)" else "Kunci Catatan (Lock)", color = Color.White)
                            }
                        }

                        TextButton(
                            onClick = {
                                scope.launch {
                                    val dup = note.copy(
                                        id = 0,
                                        title = "${note.title} (Salinan)",
                                        createdAt = System.currentTimeMillis(),
                                        updatedAt = System.currentTimeMillis()
                                    )
                                    noteDao.insertNote(dup)
                                    showActionMenuDialog = false
                                    Toast.makeText(context, "Catatan diduplikat", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Description, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Duplikat Catatan", color = Color.White)
                            }
                        }

                        TextButton(
                            onClick = {
                                scope.launch {
                                    noteDao.deleteNote(note)
                                    showActionMenuDialog = false
                                    Toast.makeText(context, "Catatan dihapus", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFCF6679))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Hapus Catatan", color = Color(0xFFCF6679))
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showActionMenuDialog = false }) {
                        Text("Tutup", color = Color.Gray)
                    }
                }
            )
        }
    }
}
