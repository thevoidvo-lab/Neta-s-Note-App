package com.example.ui.settings.dialog

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.editor.parseHexColor
import com.example.util.AppThemeConfig

@Composable
fun ThemePickerDialog(
    currentPreset: String,
    onSelectPreset: (String) -> Unit,
    onSaveCustom: (primary: String, secondary: String, bg: String, text: String) -> Unit,
    onDismiss: () -> Unit
) {
    var isCustomMode by remember { mutableStateOf(false) }
    var customPrimary by remember { mutableStateOf("#BB86FC") }
    var customSecondary by remember { mutableStateOf("#03DAC6") }
    var customBg by remember { mutableStateOf("#121212") }
    var customText by remember { mutableStateOf("#FFFFFF") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        shape = RoundedCornerShape(24.dp),
        title = {
            Text("Pilih Tema", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!isCustomMode) {
                    val presets = listOf("Light", "Dark", "Ocean", "Forest", "Sunset", "Neon", "Minimal")
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(presets) { preset ->
                            val config = AppThemeConfig.Presets[preset]!!
                            val isSel = currentPreset.equals(preset, ignoreCase = true)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSel) Color(0xFF332940) else Color(0xFF2C2C2C))
                                    .border(
                                        width = if (isSel) 2.dp else 0.dp,
                                        color = if (isSel) Color(0xFFBB86FC) else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { onSelectPreset(preset) }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(preset, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(parseHexColor(config.primaryHex, Color.Magenta))
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(parseHexColor(config.backgroundHex, Color.Black))
                                    )
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { isCustomMode = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2C))
                    ) {
                        Text("Buat Tema Kustom Sendiri", color = Color(0xFFBB86FC))
                    }
                } else {
                    // Custom theme builder
                    Text("Pilih Warna Kustom (Format Hex):", color = Color.White, fontSize = 14.sp)

                    HexColorInput(label = "Primary", value = customPrimary, onValueChange = { customPrimary = it })
                    HexColorInput(label = "Secondary", value = customSecondary, onValueChange = { customSecondary = it })
                    HexColorInput(label = "Background", value = customBg, onValueChange = { customBg = it })
                    HexColorInput(label = "Text", value = customText, onValueChange = { customText = it })

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { isCustomMode = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2C))
                        ) {
                            Text("Kembali", color = Color.Gray)
                        }

                        Button(
                            onClick = {
                                onSaveCustom(customPrimary, customSecondary, customBg, customText)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                        ) {
                            Text("Terapkan", color = Color.Black)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!isCustomMode) {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                ) {
                    Text("Tutup", color = Color.Black)
                }
            }
        },
        dismissButton = {}
    )
}

@Composable
fun HexColorInput(label: String, value: String, onValueChange: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(parseHexColor(value, Color.White))
                .border(1.dp, Color.Gray, CircleShape)
        )
        Spacer(modifier = Modifier.width(12.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label, color = Color.Gray) },
            singleLine = true,
            modifier = Modifier.weight(1f),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFFBB86FC),
                unfocusedBorderColor = Color.Gray
            )
        )
    }
}
