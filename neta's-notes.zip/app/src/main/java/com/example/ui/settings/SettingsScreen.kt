package com.example.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Note
import com.example.data.NoteDatabase
import com.example.ui.settings.dialog.BackgroundPickerDialog
import com.example.ui.settings.dialog.FontPickerDialog
import com.example.ui.settings.dialog.IconPickerDialog
import com.example.ui.settings.dialog.PinDialog
import com.example.ui.settings.dialog.ProfileEditorDialog
import com.example.ui.settings.dialog.StickerPickerDialog
import com.example.ui.settings.dialog.ThemePickerDialog
import com.example.util.FontManager
import com.example.util.HomeCustomizer
import com.example.util.ImageHelper
import com.example.util.PinManager
import com.example.util.ProfileManager
import com.example.util.ThemeManager
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun SettingsScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val themeManager = remember { ThemeManager(context) }
    val homeCustomizer = remember { HomeCustomizer(context) }
    val profileManager = remember { ProfileManager(context) }
    val pinManager = remember { PinManager(context) }
    val noteDao = remember { NoteDatabase.getDatabase(context).noteDao() }

    val themeConfig by themeManager.themeFlow.collectAsState(initial = com.example.util.AppThemeConfig.Presets["Dark"]!!)
    val homeTitle by homeCustomizer.homeTitleFlow.collectAsState(initial = "Neta's Notes")
    val homeBg by homeCustomizer.homeBgFlow.collectAsState(initial = com.example.data.CanvasBackground())
    val homeFont by FontManager.getSavedFont(context).collectAsState(initial = "Default")
    val profileInfo by profileManager.profileFlow.collectAsState(initial = com.example.util.ProfileInfo())
    val notesList by noteDao.getAllNotes().collectAsState(initial = emptyList())

    // Dialog flags
    var showThemeDialog by remember { mutableStateOf(false) }
    var showTitleDialog by remember { mutableStateOf(false) }
    var newTitleValue by remember { mutableStateOf(homeTitle) }
    var showFontDialog by remember { mutableStateOf(false) }
    var showBgDialog by remember { mutableStateOf(false) }
    var showStickerDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showIconDialog by remember { mutableStateOf(false) }
    var currentIconId by remember { mutableStateOf("default") }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportJsonText by remember { mutableStateOf("") }
    var showImportDialog by remember { mutableStateOf(false) }
    var importJsonText by remember { mutableStateOf("") }

    val profilePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val saved = ImageHelper.copyUriToInternalStorage(context, it)
            scope.launch { profileManager.updateAvatar(saved) }
            Toast.makeText(context, "Foto profil diperbarui!", Toast.LENGTH_SHORT).show()
        }
    }

    BackHandler { onBack() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .statusBarsPadding()
    ) {
        // HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("settings_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Pengaturan",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // SECTION TAMPILAN
            item { SectionHeader("TAMPILAN") }
            item {
                SettingsCard(
                    title = "Tema",
                    description = "Gaya: ${themeConfig.preset}",
                    icon = Icons.Default.ColorLens,
                    onClick = { showThemeDialog = true }
                )
            }
            item {
                SettingsCard(
                    title = "Judul Home",
                    description = homeTitle,
                    icon = Icons.Default.Title,
                    onClick = {
                        newTitleValue = homeTitle
                        showTitleDialog = true
                    }
                )
            }
            item {
                SettingsCard(
                    title = "Font Home",
                    description = homeFont,
                    icon = Icons.Default.FontDownload,
                    onClick = { showFontDialog = true }
                )
            }
            item {
                SettingsCard(
                    title = "Background Home",
                    description = "Tipe: ${homeBg.type}",
                    icon = Icons.Default.Wallpaper,
                    onClick = { showBgDialog = true }
                )
            }
            item {
                SettingsCard(
                    title = "Sticker Home",
                    description = "Kelola sticker dan stiker PNG",
                    icon = Icons.Default.Mood,
                    onClick = { showStickerDialog = true }
                )
            }

            // SECTION PROFILE
            item { SectionHeader("PROFILE") }
            item {
                SettingsCard(
                    title = "Nama Profile",
                    description = profileInfo.name,
                    icon = Icons.Default.Person,
                    onClick = { showProfileDialog = true }
                )
            }
            item {
                SettingsCard(
                    title = "Username",
                    description = profileInfo.username,
                    icon = Icons.Default.Person,
                    onClick = { showProfileDialog = true }
                )
            }
            item {
                SettingsCard(
                    title = "Status",
                    description = profileInfo.status,
                    icon = Icons.Default.Info,
                    onClick = { showProfileDialog = true }
                )
            }
            item {
                SettingsCard(
                    title = "Foto Profile",
                    description = if (profileInfo.avatarUri.isNotBlank()) "Kustom terpasang" else "Default avatar",
                    icon = Icons.Default.PhotoCamera,
                    onClick = {
                        profilePhotoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                )
            }

            // SECTION KEAMANAN
            item { SectionHeader("KEAMANAN") }
            item {
                SettingsCard(
                    title = "Ganti PIN",
                    description = if (pinManager.isPinSet()) "PIN aktif (4-6 digit)" else "Belum diatur",
                    icon = Icons.Default.Lock,
                    onClick = { showPinDialog = true }
                )
            }
            item {
                SettingsCard(
                    title = "Pilih Ikon",
                    description = "Gaya ikon aplikasi: $currentIconId",
                    icon = Icons.Default.Widgets,
                    onClick = { showIconDialog = true }
                )
            }

            // SECTION DATA
            item { SectionHeader("DATA") }
            item {
                SettingsCard(
                    title = "Ekspor JSON",
                    description = "Salin cadangan catatan (${notesList.size} catatan)",
                    icon = Icons.Default.FileUpload,
                    onClick = {
                        val arr = JSONArray()
                        notesList.forEach { n ->
                            val obj = JSONObject()
                            obj.put("id", n.id)
                            obj.put("title", n.title)
                            obj.put("contentPreview", n.contentPreview)
                            obj.put("elementsJson", n.elementsJson)
                            obj.put("canvasBgJson", n.canvasBgJson)
                            obj.put("isPinned", n.isPinned)
                            obj.put("isLocked", n.isLocked)
                            obj.put("category", n.category)
                            obj.put("createdAt", n.createdAt)
                            obj.put("updatedAt", n.updatedAt)
                            arr.put(obj)
                        }
                        exportJsonText = arr.toString(2)
                        showExportDialog = true
                    }
                )
            }
            item {
                SettingsCard(
                    title = "Impor JSON",
                    description = "Pulihkan catatan dari teks JSON",
                    icon = Icons.Default.FileDownload,
                    onClick = {
                        importJsonText = ""
                        showImportDialog = true
                    }
                )
            }

            // SECTION TENTANG
            item { SectionHeader("TENTANG") }
            item {
                SettingsCard(
                    title = "Versi",
                    description = "1.0.0 (Build 2026)",
                    icon = Icons.Default.Info,
                    onClick = {
                        Toast.makeText(context, "Neta's Notes v1.0.0 siap pakai!", Toast.LENGTH_SHORT).show()
                    }
                )
            }
            item {
                SettingsCard(
                    title = "Developer",
                    description = "Neta Studio",
                    icon = Icons.Default.Code,
                    onClick = {
                        Toast.makeText(context, "Dibuat dengan penuh cinta untuk Neta", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }

    // THEME PICKER DIALOG
    if (showThemeDialog) {
        ThemePickerDialog(
            currentPreset = themeConfig.preset,
            onSelectPreset = { preset ->
                scope.launch { themeManager.savePreset(preset) }
                showThemeDialog = false
            },
            onSaveCustom = { p, s, b, t ->
                scope.launch { themeManager.saveCustomTheme(primaryHex = p, secondaryHex = s, backgroundHex = b, textHex = t) }
                showThemeDialog = false
            },
            onDismiss = { showThemeDialog = false }
        )
    }

    // HOME TITLE DIALOG
    if (showTitleDialog) {
        AlertDialog(
            onDismissRequest = { showTitleDialog = false },
            containerColor = Color(0xFF1E1E1E),
            shape = RoundedCornerShape(24.dp),
            title = { Text("Ubah Judul Home", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newTitleValue,
                    onValueChange = { if (it.length <= 30) newTitleValue = it },
                    label = { Text("Judul (Maks 30 karakter)", color = Color.Gray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFBB86FC),
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch { homeCustomizer.saveHomeTitle(newTitleValue) }
                        showTitleDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                ) {
                    Text("Simpan", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTitleDialog = false }) {
                    Text("Batal", color = Color.Gray)
                }
            }
        )
    }

    // FONT PICKER DIALOG
    if (showFontDialog) {
        FontPickerDialog(
            currentFont = homeFont,
            onSelectFont = { font ->
                scope.launch { FontManager.saveFont(context, font) }
                showFontDialog = false
            },
            onDismiss = { showFontDialog = false }
        )
    }

    // BG PICKER DIALOG
    if (showBgDialog) {
        BackgroundPickerDialog(
            currentBg = homeBg,
            onSaveBg = { bg ->
                scope.launch { homeCustomizer.saveHomeBg(bg) }
            },
            onDismiss = { showBgDialog = false }
        )
    }

    // STICKER PICKER DIALOG
    if (showStickerDialog) {
        StickerPickerDialog(
            onAddSticker = { sticker ->
                scope.launch {
                    val currentList = homeCustomizer.homeStickersFlow
                    // Read once and add
                    scope.launch {
                        val list = mutableListOf<com.example.util.HomeStickerItem>()
                        list.add(sticker)
                        homeCustomizer.saveHomeStickers(list)
                    }
                }
            },
            onClearAllStickers = {
                scope.launch { homeCustomizer.saveHomeStickers(emptyList()) }
            },
            onDismiss = { showStickerDialog = false }
        )
    }

    // PROFILE EDITOR DIALOG
    if (showProfileDialog) {
        ProfileEditorDialog(
            initialName = profileInfo.name,
            initialUsername = profileInfo.username,
            initialStatus = profileInfo.status,
            onSave = { name, username, status ->
                scope.launch { profileManager.updateInfo(name, username, status) }
            },
            onDismiss = { showProfileDialog = false }
        )
    }

    // PIN DIALOG (Change / Set PIN)
    if (showPinDialog) {
        PinDialog(
            title = "Atur PIN Baru",
            pinManager = pinManager,
            isSettingNewPin = true,
            onSuccess = { showPinDialog = false },
            onDismiss = { showPinDialog = false }
        )
    }

    // ICON PICKER DIALOG
    if (showIconDialog) {
        IconPickerDialog(
            currentIcon = currentIconId,
            onSelectIcon = { currentIconId = it },
            onDismiss = { showIconDialog = false }
        )
    }

    // EXPORT JSON DIALOG
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = Color(0xFF1E1E1E),
            shape = RoundedCornerShape(24.dp),
            title = { Text("Ekspor Data JSON", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Salin data JSON berikut untuk mencadangkan catatan kamu:", color = Color(0xFFB0B0B0), fontSize = 13.sp)
                    OutlinedTextField(
                        value = exportJsonText,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFBB86FC),
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("NetasNotes_Backup", exportJsonText))
                        Toast.makeText(context, "Data JSON disalin ke clipboard!", Toast.LENGTH_SHORT).show()
                        showExportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                ) {
                    Text("Salin ke Clipboard", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Tutup", color = Color.Gray)
                }
            }
        )
    }

    // IMPORT JSON DIALOG
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = Color(0xFF1E1E1E),
            shape = RoundedCornerShape(24.dp),
            title = { Text("Impor Catatan dari JSON", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Tempel (paste) kode JSON cadangan kamu di sini:", color = Color(0xFFB0B0B0), fontSize = 13.sp)
                    OutlinedTextField(
                        value = importJsonText,
                        onValueChange = { importJsonText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFBB86FC),
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importJsonText.isBlank()) {
                            Toast.makeText(context, "JSON kosong!", Toast.LENGTH_SHORT).show()
                        } else {
                            try {
                                val arr = JSONArray(importJsonText)
                                scope.launch {
                                    var count = 0
                                    for (i in 0 until arr.length()) {
                                        val obj = arr.getJSONObject(i)
                                        val note = Note(
                                            id = 0,
                                            title = obj.optString("title", "Untitled Note"),
                                            contentPreview = obj.optString("contentPreview", ""),
                                            elementsJson = obj.optString("elementsJson", "[]"),
                                            canvasBgJson = obj.optString("canvasBgJson", "{}"),
                                            isPinned = obj.optBoolean("isPinned", false),
                                            isLocked = obj.optBoolean("isLocked", false),
                                            category = obj.optString("category", "General"),
                                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                                            updatedAt = System.currentTimeMillis()
                                        )
                                        noteDao.insertNote(note)
                                        count++
                                    }
                                    Toast.makeText(context, "$count catatan berhasil diimpor!", Toast.LENGTH_SHORT).show()
                                    showImportDialog = false
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "Format JSON salah atau korup!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                ) {
                    Text("Impor Sekarang", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Batal", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        text = title,
        color = Color(0xFFB0B0B0),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp, start = 4.dp)
    )
}

@Composable
fun SettingsCard(
    title: String,
    description: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color(0xFFBB86FC),
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    color = Color(0xFFB0B0B0),
                    fontSize = 12.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Open",
                tint = Color.Gray,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
