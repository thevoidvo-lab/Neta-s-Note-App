package com.example.ui.settings.dialog

import android.content.ComponentName
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.editor.parseHexColor

data class IconPreset(
    val id: String,
    val name: String,
    val primaryColorHex: String,
    val bgColorHex: String,
    val emoji: String
)

@Composable
fun IconPickerDialog(
    currentIcon: String,
    onSelectIcon: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val presets = listOf(
        IconPreset("default", "Neta Glow (Default)", "#BB86FC", "#1E1B2E", "📓"),
        IconPreset("dark_violet", "Dark Violet", "#7B2CBF", "#10002B", "✨"),
        IconPreset("neon_rose", "Neon Rose", "#FF007F", "#0D0221", "🌸"),
        IconPreset("cyan_ocean", "Cyan Ocean", "#00F5D4", "#03045E", "🌊"),
        IconPreset("sunset_glow", "Sunset Amber", "#FFB703", "#240046", "🌅"),
        IconPreset("minimal_mono", "Minimal Monolith", "#E0E0E0", "#181818", "🖋️")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1E1E1E),
        shape = RoundedCornerShape(24.dp),
        title = {
            Text("Pilih Ikon Aplikasi", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Pilih gaya ikon launcher favorit kamu:",
                    color = Color(0xFFB0B0B0),
                    fontSize = 13.sp
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(presets) { preset ->
                        val isSelected = currentIcon == preset.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFF332940) else Color(0xFF2C2C2C))
                                .border(
                                    width = if (isSelected) 2.dp else 0.dp,
                                    color = if (isSelected) Color(0xFFBB86FC) else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    onSelectIcon(preset.id)
                                    Toast.makeText(context, "Ikon ${preset.name} dipilih!", Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(parseHexColor(preset.bgColorHex, Color.Black)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(preset.emoji, fontSize = 20.sp)
                                }

                                Column(modifier = Modifier.padding(start = 12.dp)) {
                                    Text(preset.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(if (isSelected) "Sedang Digunakan" else "Ketuk untuk pasang", color = Color(0xFFB0B0B0), fontSize = 11.sp)
                                }
                            }

                            if (isSelected) {
                                Text("✓", color = Color(0xFFBB86FC), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
            ) {
                Text("Selesai", color = Color.Black)
            }
        }
    )
}
