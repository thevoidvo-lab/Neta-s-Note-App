package com.example.ui.editor

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CanvasBackground
import com.example.data.Note
import com.example.data.NoteDatabase
import com.example.data.NoteElement
import com.example.util.FontManager
import com.example.util.ImageHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    noteId: Long,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val noteDao = remember { NoteDatabase.getDatabase(context).noteDao() }
    val elementManager = remember { ElementManager() }
    val undoRedoManager = remember { UndoRedoManager(100) }

    var currentNote by remember { mutableStateOf<Note?>(null) }
    var noteTitle by remember { mutableStateOf("Untitled Note") }
    val elements = remember { mutableStateListOf<NoteElement>() }
    var canvasBackground by remember { mutableStateOf(CanvasBackground(type = "SOLID", colorHex = "#121212")) }
    var selectedElementId by remember { mutableStateOf<String?>(null) }

    var showGrid by remember { mutableStateOf(false) }
    var snapToGrid by remember { mutableStateOf(false) }
    var canvasPanX by remember { mutableFloatStateOf(0f) }
    var canvasPanY by remember { mutableFloatStateOf(0f) }
    var canvasZoom by remember { mutableFloatStateOf(1f) }

    // Bottom sheet & dialogs
    var isBottomSheetOpen by remember { mutableStateOf(false) }
    var activeToolTab by remember { mutableStateOf("+ Element") } // "+ Element", "Font", "Color", "Background", "Sticker", "Layer"
    var showTextEditDialog by remember { mutableStateOf(false) }
    var editingTextValue by remember { mutableStateOf("") }
    var showLongPressMenu by remember { mutableStateOf(false) }
    var showCanvasSettingsDialog by remember { mutableStateOf(false) }

    // Photo pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val savedUri = ImageHelper.copyUriToInternalStorage(context, it)
            val newImg = elementManager.createImageElement(savedUri)
            elements.add(newImg)
            selectedElementId = newImg.id
            undoRedoManager.pushState(elements, canvasBackground)
        }
    }

    val stickerPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val savedUri = ImageHelper.copyUriToInternalStorage(context, it)
            val newSticker = NoteElement(
                type = "sticker",
                contentUri = savedUri,
                x = 120f,
                y = 200f,
                width = 120f,
                height = 120f
            )
            elements.add(newSticker)
            selectedElementId = newSticker.id
            undoRedoManager.pushState(elements, canvasBackground)
        }
    }

    val bgImagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val savedUri = ImageHelper.copyUriToInternalStorage(context, it)
            canvasBackground = canvasBackground.copy(type = "IMAGE", imageUri = savedUri)
            undoRedoManager.pushState(elements, canvasBackground)
        }
    }

    // Load Note
    LaunchedEffect(noteId) {
        if (noteId > 0) {
            val note = noteDao.getNoteByIdSuspend(noteId)
            if (note != null) {
                currentNote = note
                noteTitle = note.title
                elements.clear()
                elements.addAll(NoteElement.listFromJsonString(note.elementsJson))
                canvasBackground = CanvasBackground.fromJsonString(note.canvasBgJson)
                undoRedoManager.clear()
                undoRedoManager.pushState(elements, canvasBackground)
            }
        } else {
            // New Note: default elements
            elements.clear()
            val defaultTitle = elementManager.createTitleElement("Title")
            val defaultBody = elementManager.createTextElement("Note something down")
            elements.add(defaultTitle)
            elements.add(defaultBody)
            undoRedoManager.clear()
            undoRedoManager.pushState(elements, canvasBackground)
        }
    }

    fun saveCurrentNote(showToast: Boolean = false) {
        scope.launch {
            val firstTitleElem = elements.firstOrNull { it.type == "title" }?.text?.trim()
            val firstTextElem = elements.firstOrNull { it.type == "text" }?.text?.trim()
            val derivedTitle = when {
                noteTitle.isNotBlank() && noteTitle != "Untitled Note" -> noteTitle
                !firstTitleElem.isNullOrBlank() -> firstTitleElem
                !firstTextElem.isNullOrBlank() -> firstTextElem.take(24)
                else -> "Untitled Note"
            }
            val preview = elements.filter { it.type == "text" || it.type == "title" }
                .joinToString(" ") { it.text }.take(120)

            val elementsJson = NoteElement.listToJsonString(elements)
            val bgJson = canvasBackground.toJsonObject().toString()

            val toSave = Note(
                id = currentNote?.id ?: if (noteId > 0) noteId else 0,
                title = derivedTitle,
                contentPreview = preview,
                elementsJson = elementsJson,
                canvasBgJson = bgJson,
                isPinned = currentNote?.isPinned ?: false,
                isLocked = currentNote?.isLocked ?: false,
                category = currentNote?.category ?: "General",
                createdAt = currentNote?.createdAt ?: System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val insertedId = noteDao.insertNote(toSave)
            if (currentNote == null) {
                currentNote = toSave.copy(id = insertedId)
            }
            if (showToast) {
                Toast.makeText(context, "Catatan tersimpan!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Auto-save every 5 seconds
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000L)
            saveCurrentNote(showToast = false)
        }
    }

    BackHandler {
        saveCurrentNote(showToast = false)
        onBack()
    }

    val selectedElement = elements.find { it.id == selectedElementId }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // TOP TOOLBAR
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back button
                IconButton(
                    onClick = {
                        saveCurrentNote(showToast = false)
                        onBack()
                    },
                    modifier = Modifier.testTag("editor_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Undo
                    IconButton(
                        onClick = {
                            val prev = undoRedoManager.undo(elements, canvasBackground)
                            if (prev != null) {
                                elements.clear()
                                elements.addAll(prev.elements)
                                canvasBackground = prev.background
                            }
                        },
                        enabled = undoRedoManager.canUndo,
                        modifier = Modifier.testTag("editor_undo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (undoRedoManager.canUndo) Color.White else Color.Gray
                        )
                    }

                    // Redo
                    IconButton(
                        onClick = {
                            val next = undoRedoManager.redo(elements, canvasBackground)
                            if (next != null) {
                                elements.clear()
                                elements.addAll(next.elements)
                                canvasBackground = next.background
                            }
                        },
                        enabled = undoRedoManager.canRedo,
                        modifier = Modifier.testTag("editor_redo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (undoRedoManager.canRedo) Color.White else Color.Gray
                        )
                    }

                    // Canvas Settings
                    IconButton(
                        onClick = { showCanvasSettingsDialog = true },
                        modifier = Modifier.testTag("editor_canvas_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings Canvas",
                            tint = Color.White
                        )
                    }

                    // Save
                    IconButton(
                        onClick = { saveCurrentNote(showToast = true) },
                        modifier = Modifier.testTag("editor_save_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Save Note",
                            tint = Color.White
                        )
                    }
                }
            }

            // CANVAS AREA
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                CanvasView(
                    elements = elements,
                    background = canvasBackground,
                    selectedElementId = selectedElementId,
                    showGrid = showGrid,
                    snapToGrid = snapToGrid,
                    canvasPanX = canvasPanX,
                    canvasPanY = canvasPanY,
                    canvasZoom = canvasZoom,
                    onCanvasTransform = { px, py, z ->
                        canvasPanX += px
                        canvasPanY += py
                        canvasZoom = (canvasZoom * z).coerceIn(0.5f, 3f)
                    },
                    onSelectElement = { id -> selectedElementId = id },
                    onEditElementText = { elem ->
                        if (elem.type == "text" || elem.type == "title") {
                            editingTextValue = elem.text
                            showTextEditDialog = true
                        }
                    },
                    onLongPressElement = { elem ->
                        selectedElementId = elem.id
                        showLongPressMenu = true
                    },
                    onMoveElement = { id, dx, dy ->
                        val index = elements.indexOfFirst { it.id == id }
                        if (index != -1) {
                            val elem = elements[index]
                            elements[index] = elem.copy(x = elem.x + dx, y = elem.y + dy)
                        }
                    },
                    onTransformElement = { id, scaleDelta, rotDelta ->
                        val index = elements.indexOfFirst { it.id == id }
                        if (index != -1) {
                            val elem = elements[index]
                            elements[index] = elem.copy(
                                scale = (elem.scale * scaleDelta).coerceIn(0.2f, 5f),
                                rotation = (elem.rotation + rotDelta) % 360f
                            )
                        }
                    },
                    onGestureEnd = {
                        undoRedoManager.pushState(elements, canvasBackground)
                        saveCurrentNote(showToast = false)
                    }
                )

                // Quick Floating controls when an element is selected
                if (selectedElement != null) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 12.dp)
                            .background(Color(0xFF1E1E1E), RoundedCornerShape(20.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                if (selectedElement.type == "text" || selectedElement.type == "title") {
                                    editingTextValue = selectedElement.text
                                    showTextEditDialog = true
                                } else {
                                    activeToolTab = if (selectedElement.type == "shape") "Color" else "+ Element"
                                    isBottomSheetOpen = true
                                }
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.TextFields, contentDescription = "Edit", tint = Color.White, modifier = Modifier.size(18.dp))
                        }

                        IconButton(
                            onClick = {
                                val dup = elementManager.duplicate(selectedElement)
                                elements.add(dup)
                                selectedElementId = dup.id
                                undoRedoManager.pushState(elements, canvasBackground)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = Color.White, modifier = Modifier.size(18.dp))
                        }

                        IconButton(
                            onClick = {
                                val idx = elements.indexOfFirst { it.id == selectedElement.id }
                                if (idx != -1) {
                                    elements[idx] = selectedElement.copy(isLocked = !selectedElement.isLocked)
                                }
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                if (selectedElement.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = "Lock",
                                tint = if (selectedElement.isLocked) Color(0xFFBB86FC) else Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = {
                                elements.removeIf { it.id == selectedElement.id }
                                selectedElementId = null
                                undoRedoManager.pushState(elements, canvasBackground)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFCF6679), modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // BOTTOM TOOLBAR (Matches user reference screenshot)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .background(Color(0xFF1E1E1E), RoundedCornerShape(32.dp))
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Camera (add image)
                    IconButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.testTag("toolbar_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Add image",
                            tint = Color.White
                        )
                    }

                    // Brush / Tools
                    IconButton(
                        onClick = {
                            activeToolTab = "+ Element"
                            isBottomSheetOpen = true
                        },
                        modifier = Modifier.testTag("toolbar_brush_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Brush,
                            contentDescription = "Tools and Drawing",
                            tint = Color.White
                        )
                    }

                    // Save / Check
                    IconButton(
                        onClick = {
                            saveCurrentNote(showToast = true)
                        },
                        modifier = Modifier.testTag("toolbar_check_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Save and Check",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // BOTTOM SHEET TOOLS
        if (isBottomSheetOpen) {
            ModalBottomSheet(
                onDismissRequest = { isBottomSheetOpen = false },
                containerColor = Color(0xFF1E1E1E),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    // Tabs
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val tabs = listOf("+ Element", "Font", "Color", "Background", "Sticker", "Layer")
                        items(tabs) { tab ->
                            val isSelected = activeToolTab == tab
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isSelected) Color(0xFFBB86FC) else Color(0xFF2C2C2C))
                                    .clickable { activeToolTab = tab }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = tab,
                                    color = if (isSelected) Color.Black else Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // TAB CONTENT
                    when (activeToolTab) {
                        "+ Element" -> {
                            ElementTabContent(
                                onAddTitle = {
                                    val t = elementManager.createTitleElement()
                                    elements.add(t)
                                    selectedElementId = t.id
                                    undoRedoManager.pushState(elements, canvasBackground)
                                    isBottomSheetOpen = false
                                },
                                onAddText = {
                                    val t = elementManager.createTextElement()
                                    elements.add(t)
                                    selectedElementId = t.id
                                    undoRedoManager.pushState(elements, canvasBackground)
                                    isBottomSheetOpen = false
                                },
                                onAddShape = { shape ->
                                    val s = elementManager.createShapeElement(shape)
                                    elements.add(s)
                                    selectedElementId = s.id
                                    undoRedoManager.pushState(elements, canvasBackground)
                                    isBottomSheetOpen = false
                                },
                                onAddSticker = {
                                    activeToolTab = "Sticker"
                                },
                                onAddImage = {
                                    isBottomSheetOpen = false
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            )
                        }
                        "Font" -> {
                            FontTabContent(
                                selectedElement = selectedElement,
                                onUpdateFont = { font ->
                                    selectedElement?.let {
                                        val idx = elements.indexOfFirst { e -> e.id == it.id }
                                        if (idx != -1) elements[idx] = it.copy(fontFamily = font)
                                    }
                                },
                                onUpdateSize = { size ->
                                    selectedElement?.let {
                                        val idx = elements.indexOfFirst { e -> e.id == it.id }
                                        if (idx != -1) elements[idx] = it.copy(fontSize = size)
                                    }
                                },
                                onToggleBold = {
                                    selectedElement?.let {
                                        val idx = elements.indexOfFirst { e -> e.id == it.id }
                                        if (idx != -1) elements[idx] = it.copy(isBold = !it.isBold)
                                    }
                                },
                                onToggleItalic = {
                                    selectedElement?.let {
                                        val idx = elements.indexOfFirst { e -> e.id == it.id }
                                        if (idx != -1) elements[idx] = it.copy(isItalic = !it.isItalic)
                                    }
                                },
                                onToggleUnderline = {
                                    selectedElement?.let {
                                        val idx = elements.indexOfFirst { e -> e.id == it.id }
                                        if (idx != -1) elements[idx] = it.copy(isUnderline = !it.isUnderline)
                                    }
                                },
                                onSetAlignment = { align ->
                                    selectedElement?.let {
                                        val idx = elements.indexOfFirst { e -> e.id == it.id }
                                        if (idx != -1) elements[idx] = it.copy(textAlign = align)
                                    }
                                }
                            )
                        }
                        "Color" -> {
                            ColorTabContent(
                                selectedElement = selectedElement,
                                onColorSelected = { hex ->
                                    selectedElement?.let {
                                        val idx = elements.indexOfFirst { e -> e.id == it.id }
                                        if (idx != -1) {
                                            if (it.type == "shape") {
                                                elements[idx] = it.copy(fillColorHex = hex)
                                            } else {
                                                elements[idx] = it.copy(fontColorHex = hex)
                                            }
                                        }
                                    }
                                },
                                onBorderColorSelected = { hex ->
                                    selectedElement?.let {
                                        val idx = elements.indexOfFirst { e -> e.id == it.id }
                                        if (idx != -1) elements[idx] = it.copy(borderColorHex = hex)
                                    }
                                }
                            )
                        }
                        "Background" -> {
                            BackgroundTabContent(
                                currentBg = canvasBackground,
                                onColorSelect = { hex ->
                                    canvasBackground = canvasBackground.copy(type = "SOLID", colorHex = hex)
                                    undoRedoManager.pushState(elements, canvasBackground)
                                },
                                onGradientSelect = { c1, c2 ->
                                    canvasBackground = canvasBackground.copy(type = "GRADIENT", colorHex = c1, secondaryColorHex = c2)
                                    undoRedoManager.pushState(elements, canvasBackground)
                                },
                                onPickImage = {
                                    isBottomSheetOpen = false
                                    bgImagePickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                onBlurChange = { blur ->
                                    canvasBackground = canvasBackground.copy(blurRadius = blur)
                                }
                            )
                        }
                        "Sticker" -> {
                            StickerTabContent(
                                onSelectEmojiSticker = { emoji ->
                                    val s = elementManager.createStickerElement(emoji)
                                    elements.add(s)
                                    selectedElementId = s.id
                                    undoRedoManager.pushState(elements, canvasBackground)
                                    isBottomSheetOpen = false
                                },
                                onUploadSticker = {
                                    isBottomSheetOpen = false
                                    stickerPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            )
                        }
                        "Layer" -> {
                            LayerTabContent(
                                elements = elements,
                                selectedId = selectedElementId,
                                onSelect = { selectedElementId = it },
                                onBringForward = { id -> elements.clear(); elements.addAll(elementManager.bringForward(elements, id)) },
                                onSendBackward = { id -> elements.clear(); elements.addAll(elementManager.sendBackward(elements, id)) },
                                onToggleLock = { id ->
                                    val idx = elements.indexOfFirst { it.id == id }
                                    if (idx != -1) elements[idx] = elements[idx].copy(isLocked = !elements[idx].isLocked)
                                },
                                onToggleHide = { id ->
                                    val idx = elements.indexOfFirst { it.id == id }
                                    if (idx != -1) elements[idx] = elements[idx].copy(isHidden = !elements[idx].isHidden)
                                },
                                onDelete = { id ->
                                    elements.removeIf { it.id == id }
                                    if (selectedElementId == id) selectedElementId = null
                                }
                            )
                        }
                    }
                }
            }
        }

        // TEXT EDIT DIALOG
        if (showTextEditDialog) {
            AlertDialog(
                onDismissRequest = { showTextEditDialog = false },
                containerColor = Color(0xFF1E1E1E),
                title = { Text("Edit Teks", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = editingTextValue,
                        onValueChange = { editingTextValue = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFBB86FC),
                            unfocusedBorderColor = Color.Gray
                        )
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            selectedElement?.let { elem ->
                                val idx = elements.indexOfFirst { it.id == elem.id }
                                if (idx != -1) {
                                    elements[idx] = elem.copy(text = editingTextValue)
                                    undoRedoManager.pushState(elements, canvasBackground)
                                }
                            }
                            showTextEditDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                    ) {
                        Text("Simpan", color = Color.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showTextEditDialog = false }) {
                        Text("Batal", color = Color.Gray)
                    }
                }
            )
        }

        // LONG PRESS CONTEXT MENU
        if (showLongPressMenu && selectedElement != null) {
            AlertDialog(
                onDismissRequest = { showLongPressMenu = false },
                containerColor = Color(0xFF1E1E1E),
                title = { Text("Aksi Elemen", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = {
                                val dup = elementManager.duplicate(selectedElement)
                                elements.add(dup)
                                selectedElementId = dup.id
                                undoRedoManager.pushState(elements, canvasBackground)
                                showLongPressMenu = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Duplikat Elemen", color = Color.White)
                        }

                        TextButton(
                            onClick = {
                                val idx = elements.indexOfFirst { it.id == selectedElement.id }
                                if (idx != -1) {
                                    elements[idx] = selectedElement.copy(isLocked = !selectedElement.isLocked)
                                }
                                showLongPressMenu = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (selectedElement.isLocked) "Buka Kunci (Unlock)" else "Kunci (Lock)", color = Color.White)
                        }

                        TextButton(
                            onClick = {
                                elements.clear()
                                elements.addAll(elementManager.bringToFront(elements, selectedElement.id))
                                showLongPressMenu = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Bawa ke Paling Depan", color = Color.White)
                        }

                        TextButton(
                            onClick = {
                                elements.clear()
                                elements.addAll(elementManager.sendToBack(elements, selectedElement.id))
                                showLongPressMenu = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Kirim ke Paling Belakang", color = Color.White)
                        }

                        TextButton(
                            onClick = {
                                elements.removeIf { it.id == selectedElement.id }
                                selectedElementId = null
                                undoRedoManager.pushState(elements, canvasBackground)
                                showLongPressMenu = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Hapus Elemen", color = Color(0xFFCF6679))
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showLongPressMenu = false }) {
                        Text("Tutup", color = Color.Gray)
                    }
                }
            )
        }

        // CANVAS SETTINGS DIALOG
        if (showCanvasSettingsDialog) {
            AlertDialog(
                onDismissRequest = { showCanvasSettingsDialog = false },
                containerColor = Color(0xFF1E1E1E),
                title = { Text("Pengaturan Canvas", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Tampilkan Grid", color = Color.White, fontSize = 16.sp)
                            Switch(
                                checked = showGrid,
                                onCheckedChange = { showGrid = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFBB86FC))
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Snap ke Grid", color = Color.White, fontSize = 16.sp)
                            Switch(
                                checked = snapToGrid,
                                onCheckedChange = { snapToGrid = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFBB86FC))
                            )
                        }

                        TextButton(
                            onClick = {
                                canvasPanX = 0f
                                canvasPanY = 0f
                                canvasZoom = 1f
                            }
                        ) {
                            Text("Reset Zoom & Posisi Canvas", color = Color(0xFFBB86FC))
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showCanvasSettingsDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                    ) {
                        Text("Selesai", color = Color.Black)
                    }
                }
            )
        }
    }
}

@Composable
fun ElementTabContent(
    onAddTitle: () -> Unit,
    onAddText: () -> Unit,
    onAddShape: (String) -> Unit,
    onAddSticker: () -> Unit,
    onAddImage: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ToolButton(label = "Title", icon = Icons.Default.TextFields, modifier = Modifier.weight(1f), onClick = onAddTitle)
            ToolButton(label = "Text", icon = Icons.Default.TextFields, modifier = Modifier.weight(1f), onClick = onAddText)
            ToolButton(label = "Sticker", icon = Icons.Default.AutoAwesome, modifier = Modifier.weight(1f), onClick = onAddSticker)
            ToolButton(label = "Image", icon = Icons.Default.Photo, modifier = Modifier.weight(1f), onClick = onAddImage)
        }

        Text("Pilih Bentuk (Shapes):", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ShapeButton(label = "Kotak", onClick = { onAddShape("rect") }, modifier = Modifier.weight(1f))
            ShapeButton(label = "Lingkaran", onClick = { onAddShape("circle") }, modifier = Modifier.weight(1f))
            ShapeButton(label = "Garis", onClick = { onAddShape("line") }, modifier = Modifier.weight(1f))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ShapeButton(label = "Panah", onClick = { onAddShape("arrow") }, modifier = Modifier.weight(1f))
            ShapeButton(label = "Segitiga", onClick = { onAddShape("triangle") }, modifier = Modifier.weight(1f))
            ShapeButton(label = "Bintang", onClick = { onAddShape("star") }, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun ShapeButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF2C2C2C))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun ToolButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF2C2C2C))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = Color(0xFFBB86FC), modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
fun FontTabContent(
    selectedElement: NoteElement?,
    onUpdateFont: (String) -> Unit,
    onUpdateSize: (Float) -> Unit,
    onToggleBold: () -> Unit,
    onToggleItalic: () -> Unit,
    onToggleUnderline: () -> Unit,
    onSetAlignment: (String) -> Unit
) {
    if (selectedElement == null || (selectedElement.type != "text" && selectedElement.type != "title")) {
        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("Pilih elemen teks terlebih dahulu", color = Color.Gray)
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Pilih Font:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val fonts = listOf("Default", "Sans-Serif", "Serif", "Monospace", "Cursive")
            items(fonts) { f ->
                val isSel = selectedElement.fontFamily.equals(f, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSel) Color(0xFFBB86FC) else Color(0xFF2C2C2C))
                        .clickable { onUpdateFont(f) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(f, color = if (isSel) Color.Black else Color.White, fontSize = 13.sp)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ukuran: ${selectedElement.fontSize.toInt()}sp", color = Color.White, fontSize = 14.sp)
            Spacer(modifier = Modifier.width(8.dp))
            Slider(
                value = selectedElement.fontSize,
                onValueChange = onUpdateSize,
                valueRange = 10f..60f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = Color(0xFFBB86FC), activeTrackColor = Color(0xFFBB86FC))
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FormatToggle(label = "B", isSelected = selectedElement.isBold, onClick = onToggleBold, modifier = Modifier.weight(1f))
            FormatToggle(label = "I", isSelected = selectedElement.isItalic, onClick = onToggleItalic, modifier = Modifier.weight(1f))
            FormatToggle(label = "U", isSelected = selectedElement.isUnderline, onClick = onToggleUnderline, modifier = Modifier.weight(1f))
            FormatToggle(label = "Left", isSelected = selectedElement.textAlign == "LEFT", onClick = { onSetAlignment("LEFT") }, modifier = Modifier.weight(1f))
            FormatToggle(label = "Center", isSelected = selectedElement.textAlign == "CENTER", onClick = { onSetAlignment("CENTER") }, modifier = Modifier.weight(1f))
            FormatToggle(label = "Right", isSelected = selectedElement.textAlign == "RIGHT", onClick = { onSetAlignment("RIGHT") }, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun FormatToggle(label: String, isSelected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) Color(0xFFBB86FC) else Color(0xFF2C2C2C))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (isSelected) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun ColorTabContent(
    selectedElement: NoteElement?,
    onColorSelected: (String) -> Unit,
    onBorderColorSelected: (String) -> Unit
) {
    val presetColors = listOf(
        "#FFFFFF", "#BB86FC", "#03DAC6", "#CF6679",
        "#FFB703", "#FB8500", "#52B788", "#00B4D8",
        "#F72585", "#7209B7", "#4CC9F0", "#FFE5B4"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Warna Utama / Teks:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(presetColors) { hex ->
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(parseHexColor(hex, Color.White))
                        .border(1.dp, Color.Gray, CircleShape)
                        .clickable { onColorSelected(hex) }
                )
            }
        }

        if (selectedElement?.type == "shape") {
            Text("Warna Border:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(presetColors) { hex ->
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(parseHexColor(hex, Color.White))
                            .border(1.dp, Color.Gray, CircleShape)
                            .clickable { onBorderColorSelected(hex) }
                    )
                }
            }
        }
    }
}

@Composable
fun BackgroundTabContent(
    currentBg: CanvasBackground,
    onColorSelect: (String) -> Unit,
    onGradientSelect: (String, String) -> Unit,
    onPickImage: () -> Unit,
    onBlurChange: (Float) -> Unit
) {
    val bgColors = listOf(
        "#121212", "#1A1A2E", "#16213E", "#0F3460",
        "#1B4332", "#240046", "#3C096C", "#212529"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Warna Solid Canvas:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(bgColors) { hex ->
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(parseHexColor(hex, Color.Black))
                        .border(1.dp, Color.Gray, RoundedCornerShape(8.dp))
                        .clickable { onColorSelect(hex) }
                )
            }
        }

        Text("Gradien Populer:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onGradientSelect("#121212", "#3C096C") },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2C))
            ) { Text("Dark Purple", color = Color.White) }

            Button(
                onClick = { onGradientSelect("#03045E", "#0077B6") },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2C2C))
            ) { Text("Deep Ocean", color = Color.White) }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onPickImage,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
            ) {
                Text("Unggah Gambar Background", color = Color.Black)
            }
        }
    }
}

@Composable
fun StickerTabContent(
    onSelectEmojiSticker: (String) -> Unit,
    onUploadSticker: () -> Unit
) {
    val emojis = listOf(
        "✨", "💖", "🌸", "⭐", "🐱", "🎀", "🧸", "🌙",
        "☕", "🦋", "🍰", "🥑", "🔮", "🌷", "🍓", "🍀"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Koleksi Sticker Cute & Aesthetic:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(emojis) { emoji ->
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF2C2C2C))
                        .clickable { onSelectEmojiSticker(emoji) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(emoji, fontSize = 24.sp)
                }
            }
        }

        Button(
            onClick = onUploadSticker,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
        ) {
            Text("Unggah Sticker PNG dari Galeri", color = Color.Black)
        }
    }
}

@Composable
fun LayerTabContent(
    elements: List<NoteElement>,
    selectedId: String?,
    onSelect: (String) -> Unit,
    onBringForward: (String) -> Unit,
    onSendBackward: (String) -> Unit,
    onToggleLock: (String) -> Unit,
    onToggleHide: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    if (elements.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("Belum ada elemen di canvas", color = Color.Gray)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(elements.reversed()) { elem ->
            val isSel = elem.id == selectedId
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSel) Color(0xFF332940) else Color(0xFF2C2C2C))
                    .clickable { onSelect(elem.id) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = when (elem.type) {
                            "title" -> "Judul: ${elem.text.ifEmpty { "Title" }}"
                            "text" -> "Teks: ${elem.text.ifEmpty { "Note..." }}"
                            "shape" -> "Bentuk: ${elem.shapeType}"
                            "sticker" -> "Sticker: ${elem.stickerKey.ifEmpty { "PNG" }}"
                            "image" -> "Foto / Gambar"
                            else -> elem.type
                        },
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onToggleLock(elem.id) }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            if (elem.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = "Lock",
                            tint = if (elem.isLocked) Color(0xFFBB86FC) else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(onClick = { onToggleHide(elem.id) }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            if (elem.isHidden) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Hide",
                            tint = if (elem.isHidden) Color.Red else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(onClick = { onDelete(elem.id) }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFCF6679), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
