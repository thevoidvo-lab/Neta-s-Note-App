package com.example.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.NoteElement
import com.example.util.FontManager
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ElementView(
    element: NoteElement,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onDoubleTap: () -> Unit,
    onLongPress: () -> Unit,
    onMove: (dx: Float, dy: Float) -> Unit,
    onTransform: (scaleDelta: Float, rotationDelta: Float) -> Unit,
    onGestureEnd: () -> Unit
) {
    if (element.isHidden) return

    val densityMultiplier = 1f

    val elementModifier = Modifier
        .offset {
            IntOffset(element.x.toInt(), element.y.toInt())
        }
        .size(
            width = (element.width * element.scale).coerceAtLeast(40f).dp,
            height = (element.height * element.scale).coerceAtLeast(24f).dp
        )
        .rotate(element.rotation)
        .alpha(element.opacity)
        .then(
            if (isSelected) {
                Modifier.border(
                    width = 2.dp,
                    color = Color(0xFFBB86FC),
                    shape = RoundedCornerShape(8.dp)
                )
            } else Modifier
        )
        .pointerInput(element.id, element.isLocked) {
            detectTapGestures(
                onTap = { onSelect() },
                onDoubleTap = { onDoubleTap() },
                onLongPress = { onLongPress() }
            )
        }
        .then(
            if (!element.isLocked) {
                Modifier
                    .pointerInput(element.id) {
                        detectTransformGestures { _, pan, zoom, rotation ->
                            if (pan != Offset.Zero) {
                                onMove(pan.x, pan.y)
                            }
                            if (zoom != 1f || rotation != 0f) {
                                onTransform(zoom, rotation)
                            }
                        }
                    }
            } else Modifier
        )

    Box(
        modifier = elementModifier,
        contentAlignment = Alignment.Center
    ) {
        when (element.type) {
            "title", "text" -> {
                val align = when (element.textAlign) {
                    "CENTER" -> TextAlign.Center
                    "RIGHT" -> TextAlign.Right
                    else -> TextAlign.Left
                }
                val decors = mutableListOf<TextDecoration>()
                if (element.isUnderline) decors.add(TextDecoration.Underline)

                Text(
                    text = if (element.text.isEmpty()) {
                        if (element.type == "title") "Title" else "Note..."
                    } else element.text,
                    fontFamily = FontManager.getFontFamily(element.fontFamily),
                    fontSize = (element.fontSize * element.scale).sp,
                    fontWeight = if (element.isBold) FontWeight.Bold else FontWeight.Normal,
                    fontStyle = if (element.isItalic) FontStyle.Italic else FontStyle.Normal,
                    textDecoration = if (decors.isNotEmpty()) TextDecoration.combine(decors) else TextDecoration.None,
                    textAlign = align,
                    color = parseHexColor(element.fontColorHex, Color.White),
                    modifier = Modifier.padding(4.dp)
                )
            }
            "image" -> {
                if (element.contentUri.isNotBlank()) {
                    AsyncImage(
                        model = element.contentUri,
                        contentDescription = "Image element",
                        modifier = Modifier.size((element.width).dp, (element.height).dp)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(element.width.dp, element.height.dp)
                            .border(1.dp, Color.Gray, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Photo Placeholder", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
            "sticker" -> {
                if (element.contentUri.isNotBlank()) {
                    AsyncImage(
                        model = element.contentUri,
                        contentDescription = "Sticker image",
                        modifier = Modifier.size(element.width.dp, element.height.dp)
                    )
                } else {
                    Text(
                        text = if (element.stickerKey.isNotBlank()) element.stickerKey else "✨",
                        fontSize = (element.fontSize.coerceAtLeast(36f) * element.scale).sp
                    )
                }
            }
            "shape" -> {
                ShapeRenderer(element = element)
            }
        }
    }
}

@Composable
fun ShapeRenderer(element: NoteElement) {
    val fillColor = parseHexColor(element.fillColorHex, Color(0xFFBB86FC))
    val strokeColor = parseHexColor(element.borderColorHex, Color.White)
    val strokeWidth = element.borderWidth.dp

    Canvas(modifier = Modifier.size(element.width.dp, element.height.dp)) {
        val w = size.width
        val h = size.height

        when (element.shapeType) {
            "rect" -> {
                val cr = CornerRadius(element.cornerRadius, element.cornerRadius)
                drawRoundRect(color = fillColor, cornerRadius = cr)
                if (element.borderWidth > 0f) {
                    drawRoundRect(
                        color = strokeColor,
                        cornerRadius = cr,
                        style = Stroke(width = strokeWidth.toPx())
                    )
                }
            }
            "circle" -> {
                drawOval(color = fillColor)
                if (element.borderWidth > 0f) {
                    drawOval(
                        color = strokeColor,
                        style = Stroke(width = strokeWidth.toPx())
                    )
                }
            }
            "line" -> {
                drawLine(
                    color = strokeColor,
                    start = Offset(0f, h / 2),
                    end = Offset(w, h / 2),
                    strokeWidth = strokeWidth.toPx().coerceAtLeast(4f)
                )
            }
            "arrow" -> {
                val arrowHeadSize = 24f
                drawLine(
                    color = strokeColor,
                    start = Offset(0f, h / 2),
                    end = Offset(w - arrowHeadSize, h / 2),
                    strokeWidth = strokeWidth.toPx().coerceAtLeast(4f)
                )
                val path = Path().apply {
                    moveTo(w, h / 2)
                    lineTo(w - arrowHeadSize, h / 2 - arrowHeadSize / 2)
                    lineTo(w - arrowHeadSize, h / 2 + arrowHeadSize / 2)
                    close()
                }
                drawPath(path = path, color = strokeColor, style = Fill)
            }
            "triangle" -> {
                val path = Path().apply {
                    moveTo(w / 2, 0f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                drawPath(path = path, color = fillColor, style = Fill)
                if (element.borderWidth > 0f) {
                    drawPath(path = path, color = strokeColor, style = Stroke(width = strokeWidth.toPx()))
                }
            }
            "star" -> {
                val path = Path()
                val cx = w / 2
                val cy = h / 2
                val outerRadius = (w.coerceAtMost(h)) / 2
                val innerRadius = outerRadius * 0.45f
                val points = 5
                var angle = -PI / 2
                val step = PI / points

                for (i in 0 until (points * 2)) {
                    val r = if (i % 2 == 0) outerRadius else innerRadius
                    val x = cx + (r * cos(angle)).toFloat()
                    val y = cy + (r * sin(angle)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    angle += step
                }
                path.close()
                drawPath(path = path, color = fillColor, style = Fill)
                if (element.borderWidth > 0f) {
                    drawPath(path = path, color = strokeColor, style = Stroke(width = strokeWidth.toPx()))
                }
            }
        }
    }
}

fun parseHexColor(hex: String, fallback: Color): Color {
    return try {
        val clean = hex.removePrefix("#")
        val colorInt = clean.toLong(16)
        if (clean.length == 6) {
            Color(colorInt or 0x00000000FF000000)
        } else {
            Color(colorInt)
        }
    } catch (e: Exception) {
        fallback
    }
}
